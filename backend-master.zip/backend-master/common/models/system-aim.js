'use strict';

module.exports = function(Systemaim) {

};
