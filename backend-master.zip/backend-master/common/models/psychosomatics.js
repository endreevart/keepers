'use strict';

module.exports = function(Psychosomatics) {

};
