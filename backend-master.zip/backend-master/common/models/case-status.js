'use strict';

module.exports = function (CaseStatus) {
}