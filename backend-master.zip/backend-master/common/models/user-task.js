'use strict';
var moment = require('moment');
const pushNotification = require('../../helpers/pushNotification');
const checkUser = require('./master-users');

module.exports = function (Usertask) {
    Usertask.observe('before save', async function (ctx, next) {
        if (ctx.isNewInstance) {
            //next()
        } else {
            if (ctx.data?.status && ctx.currentInstance && ctx.currentInstance?.status != ctx.data.status) {
                ctx.data.endDate = new Date()
                ctx.currentInstance.task(function (err, task) {
                    Usertask.app.models.MasterUsers.checkUser(ctx.currentInstance.userId, task.masterId, ctx.currentInstance.id, undefined)
                })
            }
            //при завершении задачи создается событие
            if (ctx.data.status == "completed" && ctx.currentInstance?.status != ctx.data.status) {
                try {
                    //так же пользователю добавляется опыт
                    const task = await Usertask.app.models.Task.findById(ctx.currentInstance.taskId)//ctx.currentInstance.task()
                    await Usertask.app.models.user.addLevelPoints(ctx.currentInstance.userId, task.bonus)

                    await ctx.currentInstance.events.create({ name: `завершено задание ${task.name || ""}`, description: "вы завершили выполнение задания",eventTypeId: 'task', dateComplete: new Date(),//eventcreate
                    userId: ctx.currentInstance.userId, masterId: task.masterId ,})                    
                } catch (e) {
                    throw e
                }
            } else {
                //next()
            }
        }
    })

    Usertask.observe('after save', async function (ctx, next) {
        if (ctx.isNewInstance) {
            try {
                const task = await Usertask.app.models.Task.findById(ctx.instance.taskId)
                await ctx.instance.events.create([//eventcreate
                    // событие, которое еще не завершено. тут необходимо:
                    // name: задание...
                    // описание: task.description
                    {
                        eventTypeId: 'task',
                        status: 'created',
                        //дате завершения выполнения задания 
                        //(дата назначения задания на игрока + необходимое количество времени на выполнение задания)
                        dateComplete: ctx.instance.endDate,
                        pushDate: ctx.instance.endDate ? moment(ctx.instance.endDate).subtract(1, 'hour').toDate() : undefined,
                        userId: ctx.instance.userId,
                        name: `задание ${task.name || ""}`,
                        description: 'выполнение задания'
                        // description: task.description
                    },
                    // событие, которое сразу отправляется в имторию, так как уже имеет статус completed. тут необходимо:
                    // name: создано новое задание...
                    // описание: task.description
                    {
                        name: `создано новое задание ${task.name || ""}`,
                        description: task.description,
                        eventTypeId: 'task',
                        status: 'completed',
                        dateComplete: new Date(),
                        userId: ctx.instance.userId,
                    }
                ])
                //тк при создании задания через обязательство нет мастера
                if (task.masterId)
                    await Usertask.app.models.MasterUsers.upsertWithWhere(
                        { userId: ctx.instance.userId, masterId: task.masterId }, { userId: ctx.instance.userId, masterId: task.masterId, active: true }
                    )
            } catch (err) {
                throw err;
            }

            // pushNotification.sendPush([
            //     "cRkGcQZ8QUi2JTL7S9S8tZ:APA91bGahr-S51sDJ3RYBoBIViswJe-tnzY0a_mBtN4zlTYcAUSsDYBW8PSb-4nZajDU-2o-DU5bFQNHE-VrKENlSNLZyYiGMF_ootLWlB02g4waS8IbhLRJE6BK1rRM30x19TVIs-hS-",
            //     "cRkGcQZ8QUi2JTL7S9S8tZ:APA91bGahr-S51sDJ3RYBoBIViswJe-tnzY0a_mBtN4zlTYcAUSsDYBW8PSb-4nZajDU-2o-DU5bFQNHE-VrKENlSNLZyYiGMF_ootLWlB02g4waS8IbhLRJE6BK1rRM30x19TVIs-hS",
            // "cRkGcQZ8QUi2JTL7S9S8tZ:APA91bGahr-S51sDJ3RYBoBIViswJe-tnzY0a_mBtN4zlTYcAUSsDYBW8PSb-4nZajDU-2o-DU5bFQNHE-VrKENlSNLZyYiGMF_ootLWlB02g4waS8IbhLRJE6BK1rRM30x19TVIs-hS-|"], { 'title': 'Создано новое задание.' })
            //pushNotification.sendPushToUser(ctx.instance.userId, { 'title': 'Создано новое задание.' }).then(res => {}, e => {console.log('e', e)})

        }
    })


    /**
     * Returns user tasks with filtering by rubrics
     * @param {string[]} rubrics названия рубрик
     * @param {string} search по названию и описанию userTAsk
     * @param {boolean} draft статус task
     * @param {object} filter фильтр usertask
     * @param {*} cb 
     */
    Usertask.getByRubrics = function (rubrics, search, draft, filter, cb) {
        let searchFilter
        if (search) {
            searchFilter = {
                or: [
                    { name: { like: new RegExp(search, "i") } },
                    { description: { like: new RegExp(search, "i") } }]
            }
        }
        const rubricFilter = {
            include: {
                relation: 'tasks', scope: {
                    include: {
                        relation: 'userTasks', scope: filter
                    }, where: searchFilter
                }
            }
        }

        if (draft !== undefined && draft !== null) rubricFilter.include.scope.where = { draft }
        if (rubrics.length > 0) rubricFilter.where = { name: { inq: rubrics } }

        Usertask.app.models.Rubric.find(rubricFilter, function (err, rubrics) {
            if (err) throw err
            rubrics = JSON.parse(JSON.stringify(rubrics))
            let userTasks = []
            rubrics.forEach(rubric => {
                rubric.tasks.forEach(task => {
                    task.rubric = { ...rubric, tasks: undefined }
                    task.userTasks.forEach(userTask => {
                        userTask.task = { ...task, userTasks: undefined }
                        userTasks.push(userTask)
                    })
                    //userTasks = userTasks.concat(task.userTasks)
                });
            });
            userTasks.sort((a, b) => new Date(a.endDate).getTime() - new Date(b.endDate).getTime());
            cb(null, userTasks)
        })
    }

    Usertask.remoteMethod('getByRubrics',
        {
            description: 'Returns user tasks with filtering by rubrics',
            accepts: [
                {
                    arg: 'rubrics',
                    type: 'array',
                    required: true
                },
                {
                    arg: 'search',
                    type: 'string',
                    description: "поиск по названию и описанию",
                    required: false
                },
                {
                    arg: 'draft',
                    type: 'boolean',
                    required: false
                },
                {
                    arg: 'filter',
                    type: 'object',
                    required: false
                }
            ],
            returns: {
                arg: 'userTasks',
                type: 'array',
                root: true
            },
            http: {
                verb: 'get'
            }
        }
    );


    /**Returns user tasks with filtering
     * 
     * @param {string[]} userIds - список игроков (id. Пустой массив = все игроки мастера. не пустой - только те что в массиве)
     * @param {date} start - период - userTask у которых startDate находятся в выбранном периоде
     * @param {date} end - период - userTask у которых startDate находятся в выбранном периоде
     * @param {string} status - статус. не может быть null, так как всегда имеется указанный статус. смотреть у userTask.
     * @param {string} name - поиск по названию task
     * @param {object} include - 
     * @param {*} cb 
     */
    Usertask.getByFilters = async function (userIds, start, end, status, name, include, options, cb) {
        //console.log('userIds, start, end, status, name, filter', userIds, start, end, status, name, include)
        try {
            const user = await Usertask.app.models.user.findById(options.accessToken.userId)
            let searchFilter = {
                status
            }
            if (start && end) {
                searchFilter.startDate = { between: [start, end] }
            } else if (start) {
                searchFilter.startDate = { gte: start }
            } else if (start) {
                searchFilter.startDate = { lte: end }
            }
            if (userIds.length > 0) {
                searchFilter.userId = { inq: userIds }
            }
            if (name || user.isMaster) {
                let tasks = await Usertask.app.models.Task.find({
                    where: { 
                        name: name ? { like: new RegExp(name, "i")} : undefined,
                        masterId: user.isMaster ? user.id : undefined
                }, include: {
                        relation: 'userTasks', scope: {
                            include: include, where: searchFilter
                        }
                    }
                })
                let userTasks = []
                tasks = JSON.parse(JSON.stringify(tasks))
                tasks.forEach(task => {
                    if (task.userTasks.length > 0)
                        userTasks = userTasks.concat(task.userTasks)
                })
                return userTasks
                
            } else {
                let userTasks = await Usertask.find({
                    include: include, where: searchFilter
                })
                return userTasks                
            }
        } catch (e) {
            throw e
        }
    }

    Usertask.remoteMethod('getByFilters',
        {
            description: 'Returns user tasks with filtering',
            accepts: [
                {
                    arg: 'userIds',
                    type: 'array',
                    description: "список игроков (id. Пустой массив = все игроки мастера. не пустой - только те что в массиве)",
                    required: true
                },
                {
                    arg: 'start',
                    type: 'date',
                    description: "период",
                    required: false
                },
                {
                    arg: 'end',
                    type: 'date',
                    description: "период",
                    required: false
                },
                {
                    arg: 'status',
                    type: 'string',
                    description: "статус. не может быть null, так как всегда имеется указанный статус. смотреть у userTask.",
                    required: true
                },
                {
                    arg: 'name',
                    type: 'string',
                    description: "поиск по названию task",
                    required: false
                },
                {
                    arg: 'include',
                    type: 'array',
                    required: false
                },
                {
                    arg: "options",
                    type: "object",
                    http: "optionsFromRequest"
                }
            ],
            returns: {
                arg: 'userTasks',
                type: 'array',
                root: true
            },
            http: {
                verb: 'get'
            }
        }
    );


    /**
     * Returns user tasks with filtering by status
     * @param {string} status 
     * @param {string} search 
     * @param {array} include 
     * @param {*} options 
     * @param {*} cb 
     */
    Usertask.getByStatus = function (status, search, include, options, cb) {
        if (include) {
            if (include.filter(item => (item == "task" || item.relation == "task")).length == 0)
            include.push("task")
        } else {
            include = ["task"]
        }
        Usertask.find({where: {status, userId: options.accessToken.userId  }, include}, function(err, userTasks) {
            if (err) throw err
            if (search) {
                const regex = new RegExp(search, "i")
                userTasks = JSON.parse(JSON.stringify(userTasks))
                userTasks = userTasks.filter(userTask => (regex.test(userTask.task?.name) || regex.test(userTask.task?.description)))
            }
            cb(null, userTasks)
        })
    }

    Usertask.remoteMethod('getByStatus',
        {
            description: 'Returns user tasks with filtering by status',
            accepts: [
                {
                    arg: 'status',
                    type: 'string',
                    required: false
                },
                {
                    arg: 'search',
                    type: 'string',
                    description: "поиск по названию и описанию",
                    required: false
                },
                {
                    arg: 'include',
                    type: 'array',
                    required: false
                },
                {
                  arg: "options",
                  type: "object",
                  http: "optionsFromRequest"
                }
            ],
            returns: {
                arg: 'userTasks',
                type: 'array',
                root: true
            },
            http: {
                verb: 'get'
            }
        }
    );

    Usertask.getByFiltersForUser = async function (status, start, end, name,skip, limit, order = 1, options, cb) {
        try {
            let searchFilter = {userId: options.accessToken.userId, status}
            if (start && end) {
                searchFilter.endDate = { between: [start, end] }
            } else if (start) {
                searchFilter.endDate = { gte: start }
            } else if (start) {
                searchFilter.endDate = { lte: end }
            }
            let userTasks = []
            if (name) {
                let tasks = await Usertask.app.models.Task.find({
                    where: name ? {
                        or: [{name: { like: new RegExp(name, "i")}}, {aim: { like: new RegExp(name, "i")}}, {description: { like: new RegExp(name, "i")}}]
                    } : undefined,
                    include: [{ relation: 'userTasks', scope: {
                            include: [{relation: 'task', scope: {include: 'images'}},
                            {relation: 'user', scope: {include: 'image'}}], 
                            where: searchFilter
                        }}, 'images']                    
                })
                tasks = JSON.parse(JSON.stringify(tasks))
                iter: for (let i = 0; i < tasks.length; i++) {
                    for (let j = 0; j < tasks[i].userTasks.length; j++) {
                        if (skip > 0) {
                            skip--
                        } else {
                            if (limit !== 0 || limit > 0)
                                userTasks.push({...tasks[i].userTasks[j], task: {...tasks[i], userTasks: undefined}})
                            else 
                                break iter
                            if (limit) limit--
                        }
                    }
                }  
                userTasks.sort((a, b) => {
                    const res = new Date(b.endDate).getTime() - new Date(a.endDate).getTime() 
                    //NaN выдает рандомный результат в sort
                    return (isFinite(res) ? res : (isFinite(new Date(a.endDate).getTime()) ? -1 : 1)) * order * (-1)
                });
            } else {
                userTasks = await Usertask.find({
                    /*include: include,*/ where: searchFilter, skip, limit, order: `endDate ${(order > 0) ? "ASC" : "DESC"}`,
                    include: [{relation: 'task', scope: {include: 'images'}},
                    {relation: 'user', scope: {include: 'image'}}]
                })               
            }
            return userTasks
        } catch (e) {
            throw e
        }
    }

    Usertask.remoteMethod('getByFiltersForUser',
        {
            description: 'Returns user tasks with filtering (for user)',
            accepts: [
                {
                    arg: 'status',
                    type: 'string',
                    required: false
                },
                {
                    arg: 'start',
                    type: 'date',
                    description: "период",
                    required: false
                },
                {
                    arg: 'end',
                    type: 'date',
                    description: "период",
                    required: false
                },
                {
                    arg: 'name',
                    type: 'string',
                    description: "поиск по названию task",
                    required: false
                },
                {
                    arg: 'skip',
                    type: 'number',
                    required: false
                },
                {
                    arg: 'limit',
                    type: 'number',
                    required: false
                },
                {
                    arg: 'order',
                    type: 'number',
                    description: "сортировка по полю endDate",
                    required: false
                },
                {
                    arg: "options",
                    type: "object",
                    http: "optionsFromRequest"
                }
            ],
            returns: {
                arg: 'userTasks',
                type: 'array',
                root: true
            },
            http: {
                verb: 'get'
            }
        }
    );
};
