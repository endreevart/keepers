'use strict';

module.exports = function (Material) {
    /**
     * фильтр материалов
     * @param {boolean} isMaster (required) - мастер или игрок
     * @param {string} name - название материала
     * @param {string[]} rubrics (required) - рубрика (0, 1 или много)
     * @param {boolean} draft - черновик/не черновик
     * @param {string} section - выбранный раздел
     * @param {string} order (required) - order по дате создания (возрастнае, убывание) или по количеству просмотров (только по убыванию)
     * @param {number} skip - 
     * @param {number} limit - 
     * @param {*} options
     * @param {*} cb
     */
    Material.getByRubrics = async function (isMaster, name, rubrics, draft, section, type, order, skip = 0, limit, options, cb) {

        let searchFilter = { masterId: options.accessToken.userId, type }
        if (!isMaster) {
            const masters = await Material.app.models.MasterUsers.find({ where: { userId: options.accessToken.userId, active: true } })
            const masterIds = masters.map(master => master.masterId) || []
            searchFilter.masterId = { inq: masterIds }
        }
        if (name) searchFilter.name = { like: new RegExp(name, "i") }

        let include = ["cover", "audio", 
        {relation: "video", scope: {include: "thumbnail"}}, 
        "textFile", 
        {relation: "master", scope: {fields: ["firstname", "lastname"]}},

        // {relation: "librarySections", scope: {where: {"userId": options.accessToken.userId}, 
        //     include: [{relation: "materialSection", scope: {where: {name: "Избранное"}}}]}}
    ]

        if (draft !== undefined && draft !== null) searchFilter.draft = draft
        //if (rubrics.length > 0) include.push({ relation: 'rubrics', scope: { where: { name: { inq: rubrics } } } })
        include.push({ relation: 'rubrics', scope: { fields: ['name'] } })
        if (section) include.push({ relation: 'librarySections', scope: { //where: { materialSectionId: section },
            include: [{relation: "materialSection", scope: {where: {or: [{name: "Избранное"},{id: section}]}}}] } })
        else include.push({relation: "librarySections", scope: {where: {"userId": options.accessToken.userId}, 
            include: [{relation: "materialSection", scope: {where: {name: "Избранное"}}}]}})

        let filterOrder = "created ASC"
        if (order == "dateDesc") filterOrder = "created DESC"
        else if (order == "views") filterOrder = "views DESC"//по количеству просмотров (только по убыванию)

        let items = await Material.find({
            where: searchFilter,
            include: include,
            order: filterOrder,
            skip: (skip && (rubrics.length == 0) && !section) ? skip : undefined,
            limit: (limit && (rubrics.length == 0) && !section) ? limit : undefined,
        })
        items = JSON.parse(JSON.stringify(items))

        items.forEach(item => {
            item.rubricNames = item.rubrics.map(item => item.name) || []
        });
        if (rubrics.length > 0 || section) {
            let filteredItems = []
            let skipCount = 0
            for (let item of items) {
                if ((!(rubrics.length > 0) || (rubrics.length > 0 && rubrics.some(rubric => item.rubricNames.includes(rubric))/*item.rubrics?.length > 0*/))
                    && (!section || (section && item.librarySections?.some(libSection => libSection.materialSectionId == section)))) {
                    if (skipCount >= skip)
                        filteredItems.push(item)
                    else
                        skipCount++
                }
                if (limit && filteredItems.length == limit) {
                    break
                }
            }
            items = filteredItems
        }
        items.forEach(item => { 
            delete item.rubrics 
            item.isFavourite = item.librarySections.some(section => (section.userId == options.accessToken.userId && section.materialSection?.name == "Избранное"))
            ? true : false
            delete item.librarySections
        });

        return items
    }

    Material.remoteMethod('getByRubrics',
        {
            description: 'Returns materials with filtering by rubrics',
            accepts: [
                {
                    arg: 'isMaster',
                    type: 'boolean',
                    description: "мастер или игрок",
                    required: true
                },
                {
                    arg: 'name',
                    type: 'string',
                    description: "поиск по названию",
                    required: false
                },
                {
                    arg: 'rubrics',
                    type: 'array',
                    required: true
                },
                {
                    arg: 'draft',
                    type: 'boolean',
                    required: false
                },
                {
                    arg: 'section',
                    type: 'string',
                    required: false
                },
                {
                    arg: 'type',
                    type: 'string',
                    required: false
                },
                {
                    arg: 'order',
                    type: 'string',
                    description: "сортировка по полю dateAsc/dateDesc/views",
                    required: true
                },
                {
                    arg: 'skip',
                    type: 'number',
                    required: false
                },
                {
                    arg: 'limit',
                    type: 'number',
                    required: false
                },
                {
                    arg: "options",
                    type: "object",
                    http: "optionsFromRequest"
                }
            ],
            returns: {
                arg: 'materials',
                type: 'array',
                root: true
            },
            http: {
                verb: 'get'
            }
        }
    );

    Material.increaseViews = function (id, cb) {
        Material.findById(id, function (err, material) { 
            if (err) throw err
            if (!material) {
                var err = new Error("not_found");
                err.statusCode = 404;
                cb(err)
            } else
            material.updateAttribute("views", material.views + 1, function(err, material) {
                if (err) throw err
                cb(null, material)
            })
        })
    }

    Material.remoteMethod('increaseViews',
        {
            description: 'Increase views of material',
            accepts: [
                {arg: 'id', type: 'string', required: true}
            ],
            returns: {
                arg: 'material',
                type: 'object',
                root: true
            },
            http: {path: '/:id/increaseViews', verb: 'post'}
        }
    );

    /**
     * Метод для массового изменения списка связи разделов для материала
     * @param {*} id 
     * @param {*} sectionIds 
     * @param {*} options 
     * @param {*} cb 
     */
    Material.changeSections = function (id, sectionIds, options, cb) {
        Material.findById(id, function (err, material) { 
            if (err) throw err
            if (!material) {
                var err = new Error("not_found");
                err.statusCode = 404;
                cb(err)
            } else {
                //удаление всех непопавших в список
                Material.app.models.LibrarySection.deleteAll({
                    materialId: id, 
                    userId: options.accessToken.userId,
                    materialSectionId: {nin: sectionIds}, 
                }, function(err, res) {
                    if (err) throw err
                    const promises = []
                    sectionIds.forEach(sectionId => {
                        promises.push(
                            Material.app.models.LibrarySection.findOrCreate({
                                materialId: id, 
                                userId: options.accessToken.userId,
                                materialSectionId: sectionId, 
                            })
                        )
                    })
                    Promise.all(promises).then(res => {
                        cb(null)
                    }, err => {throw err;})
                })
            }
        })
    }

    Material.remoteMethod('changeSections',
        {
            description: 'Change sections of material',
            accepts: [
                {arg: 'id', type: 'string', required: true},
                {arg: 'sectionIds', type: 'array', required: true},
                {
                    arg: "options",
                    type: "object",
                    http: "optionsFromRequest"
                }
            ],
            returns: {
                arg: 'material',
                type: 'object',
                root: true
            },
            http: {path: '/:id/changeSections', verb: 'post'}
        }
    );


    /**
     * Метод для массового изменения списка связи рекомендаций для материала
     * @param {*} id 
     * @param {*} recommendationIds 
     * @param {*} options 
     * @param {*} cb 
     */
    Material.changeRecommendations = function (id, recommendationIds, options, cb) {
        Material.findById(id, function (err, material) { 
            if (err) throw err
            if (!material) {
                var err = new Error("not_found");
                err.statusCode = 404;
                cb(err)
            } else {
                //удаление всех непопавших в список
                material.recommendations.destroyAll({recommendationId: {nin:recommendationIds}}, function(err, res) {
                    if (err) throw err
                    const promises = []
                    recommendationIds.forEach(recommendationId => {
                        promises.push(
                            material.recommendations.add(recommendationId)
                        )
                    })
                    Promise.all(promises).then(res => {
                        cb(null)
                    }, err => {throw err;})
                })
            }
        })
    }

    Material.remoteMethod('changeRecommendations',
        {
            description: 'Change sections of material',
            accepts: [
                {arg: 'id', type: 'string', required: true},
                {arg: 'recommendationIds', type: 'array', required: true},
                {
                    arg: "options",
                    type: "object",
                    http: "optionsFromRequest"
                }
            ],
            returns: {
                arg: 'material',
                type: 'object',
                root: true
            },
            http: {path: '/:id/changeRecommendations', verb: 'post'}
        }
    );

    Material.recommendationsIsFavourite = function (id, filter = {}, options, cb) {

        if (!filter?.include) {
            filter.include = [{
                relation: "librarySections", scope: {
                    where: { "userId": options.accessToken.userId },
                    include: [{ relation: "materialSection", scope: { where: { name: "Избранное" } } }]
                }
            }]
        } else {
            filter.include.push({
                relation: "librarySections", scope: {
                    where: { "userId": options.accessToken.userId },
                    include: [{ relation: "materialSection", scope: { where: { name: "Избранное" } } }]
                }
            },
            )
        }
        //в выдаче только опубликованные материалы
        if (filter.where?.draft === undefined || filter.where?.draft === null) {
            if (filter.where) filter.where.draft = false
            else filter.where = { draft: false }
        }
        Material.findById(id, { include: { relation: "recommendations", scope: { ...filter } } }, function (err, material) {
            if (err) throw err
            if (!material) {
                var err = new Error("material_not_found");
                err.statusCode = 404;
                cb(err)
            } else {
                // material.recommendations.find({...filter}, function(err, materials){
                //    if (err) throw err 
                // materials = JSON.parse(JSON.stringify(materials))
                let materials = JSON.parse(JSON.stringify(material)).recommendations

                materials.forEach(item => {
                    item.isFavourite = item.librarySections.some(section => (section.userId == options.accessToken.userId && section.materialSection?.name == "Избранное"))
                        ? true : false
                    if (!filter.include.includes("librarySections") && !filter.include.find(include => ((include?.relation == "librarySections") && !include?.scope?.where?.userId)))
                        delete item.librarySections
                });
                cb(null, materials)
                //})
            }
        })
    }

    Material.remoteMethod('recommendationsIsFavourite',
        {
            description: 'Find out if recomendations belongs to favourite section of user',
            accepts: [
                { arg: 'id', type: 'string', required: true },
                { arg: 'filter', type: 'object', required: false },
                {
                    arg: "options",
                    type: "object",
                    http: "optionsFromRequest"
                }
            ],
            returns: {
                arg: 'recommendations',
                type: 'array',
                root: true
            },
            http: { path: '/:id/recommendations/isFavourite', verb: 'get' }
        }
    );
};
