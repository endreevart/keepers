'use strict';

module.exports = function (StressState) {
}