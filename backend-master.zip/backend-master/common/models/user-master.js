'use strict';

module.exports = function (Usermaster) {
    Usermaster.observe('after save', async function (ctx, next) {
        if (ctx.isNewInstance) {
            try {
                await Usermaster.app.models.MasterUsers.upsertWithWhere(
                    { userId: ctx.instance.userId, masterId: ctx.instance.masterId }, { userId: ctx.instance.userId, masterId: ctx.instance.masterId, active: true }
                )
                //next()
            } catch (e) {
                throw e
            }
        } else {
            //next()
        }
    })
    Usermaster.observe('after delete', async function (ctx, next) {
        if (ctx.where.userId && ctx.where.masterId)
            Usermaster.app.models.MasterUsers.checkUser(ctx.where.userId, ctx.where.masterId, undefined, undefined)
    })
};
