'use strict';

module.exports = function(Feeling) {

};
