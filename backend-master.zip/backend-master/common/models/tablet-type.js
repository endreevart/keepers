'use strict';

module.exports = function(Tablettype) {

};
