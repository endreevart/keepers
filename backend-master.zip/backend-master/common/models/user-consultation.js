'use strict';
const pushNotification = require('../../helpers/pushNotification');
var moment = require('moment');
const agora = require("../../helpers/agora.js")

module.exports = function (Userconsultation) {

    /**создание транзакции оплаты при покупке консультации */
    async function createPayment(instance, beforeCreate) {
        return new Promise(async (resolve, reject) => {
            try {
                const consultation = await Userconsultation.app.models.Consultation.findById(instance.consultationId)
                let duration = consultation.maxDuration
                if (consultation.maxDuration == -1) {//расчет идет по занимаемым слотам
                    duration = (instance.duration || 0) / (60 * 1000)
                }
                const masterWallet = await Userconsultation.app.models.Wallet.findOne({ where: { userId: consultation.masterId } })

                if ((consultation.cost != consultation.costUnit)
                    && (!duration || !consultation.costUnit)) {
                    var err = new Error("maxDuration and costUnit are required");
                    err.statusCode = 422;
                    throw err
                } else {
                    let fullCost = 0

                    //costUnit == -1 - полная стоимость равна cost
                    if (consultation.costUnit == -1) {
                        fullCost = consultation.cost
                    } else
                        fullCost = (consultation.cost == consultation.costUnit) ? consultation.cost :
                            (duration / consultation.costUnit) * consultation.cost
                    const wallet = await Userconsultation.app.models.Wallet.findOne({ where: { userId: instance.userId } })
                    if (!wallet || wallet.balance < fullCost) {
                        var err = new Error("insufficient_balance");
                        err.statusCode = 400;
                        throw err
                    } else {
                        await wallet.updateAttribute("balance", wallet.balance - fullCost)
                        await wallet.transactions.create({
                            "sum": fullCost,
                            "type": "withdrawal",
                            "date": new Date(),
                            "userConsultationId": instance.id,
                        })
                        await masterWallet.updateAttribute("balance", masterWallet.balance + fullCost)
                        await masterWallet.transactions.create({
                            "sum": fullCost,
                            "type": "adding",
                            "date": new Date(),
                            "userConsultationId": instance.id,
                        })
                        resolve()
                    }
                }
                
            } catch (e) {
                reject(e)
            }
        })
    }
    /**создание транзакции возврата при отмене консультации */
    async function refundPayment(ctx) {
        return new Promise(async (resolve, reject) => {
            try {
                const transactions = await ctx.currentInstance.transactions.find({ include: 'wallet' })
                for (let i = 0; i < transactions?.length; i++) {
                    const wal = transactions[i].wallet()
                    const transaction = JSON.parse(JSON.stringify(transactions[i]))
                    if (transaction.type == "withdrawal" || transaction.type == "adding") {
                        await Userconsultation.app.models.Transaction.create({
                            "sum": transaction.sum,
                            "type": "refund",
                            "walletId": transaction.walletId,
                            "userConsultationId": transaction.userConsultationId
                        })
                        await wal.updateAttribute("balance",
                            (transaction.type == "withdrawal") ? transaction.wallet.balance + transaction.sum : transaction.wallet.balance - transaction.sum)
                    }
                }
                resolve()
            } catch (e) {
                reject(e)
            }
        })
    }

    Userconsultation.observe('before save', function (ctx, next) {

        if (ctx.isNewInstance) {
            createPayment(ctx.instance, true).then(() => {
                ctx.instance.unsetAttribute('duration');
                next()
            }, e => {
                next(e)
            })
        } else {
            //при смене статуса создается событие
            if (ctx.data && ctx.currentInstance && ctx.data.status != "started" && ctx.currentInstance.status != ctx.data.status) {
                let rusStatus = {
                    created: "Создана",
                    started: "начата",
                    completed: "завершена",
                    cancelled: "отменена"
                }

                //при смене консультации - возврат средств
                if (ctx.data.status == "cancelled") {
                    refundPayment(ctx).then(() => {
                        ctx.currentInstance.consultation(function (err, consultation) {
                            if (err) throw err

                            Userconsultation.app.models.Event.deleteAll({
                                userConsultationId: ctx.currentInstance.id, status: "created"}, function (err, res) {
                                if (err) throw err
                                ctx.currentInstance.events.create({//eventcreate
                                    name:"консультация " + consultation.name,
                                    description: 'Смена статуса на: ' + rusStatus[ctx.data.status], 
                                    dateComplete: new Date(),
                                    eventTypeId: "consultation", 
                                    userId: ctx.currentInstance.userId, masterId: consultation.masterId
                                }, function (err, res) {
                                    if (err) throw err                            
                                    Userconsultation.app.models.MasterUsers.checkUser(ctx.currentInstance.userId, consultation.masterId, undefined, ctx.currentInstance.id)
                                    next()
                                })
                            })
                        })

                    }, e => {
                        next(e)
                    })
                } else {
                    ctx.currentInstance.consultation(function (err, consultation) {
                        if (err) throw err
                        ctx.currentInstance.events.create({//eventcreate
                            name:"консультация " + consultation.name,
                            description: 'Смена статуса на: ' + rusStatus[ctx.data.status], 
                            dateComplete: new Date(),
                            eventTypeId: "consultation", 
                            userId: ctx.currentInstance.userId, masterId: consultation.masterId
                        }, function (err, res) {
                            if (err) throw err
                            if (ctx.data.status == "completed") {
                                Userconsultation.app.models.Event.deleteAll({
                                    userConsultationId: ctx.currentInstance.id, status: "created"}, function (err, res) {
                                    if (err) throw err
                                    createTasks().then(()=> {
                                        Userconsultation.app.models.MasterUsers.checkUser(ctx.currentInstance.userId, consultation.masterId, undefined, ctx.currentInstance.id)
                                        next()
                                    })
                                })
                            } else if (ctx.data.status != "created") {
                                Userconsultation.app.models.MasterUsers.checkUser(ctx.currentInstance.userId, consultation.masterId, undefined, ctx.currentInstance.id)
                                next()
                            }
                        })
                    })
                }
            } else {
                next()
            }
        }
        //добавление пользователю задач, связанных с консультацией
        function createTasks() {

            return new Promise((resolve, reject)=>{
                Userconsultation.app.models.Consultation.findById(ctx?.currentInstance.consultationId,
                { include: "tasks" }, function (err, consultation) {
                    if (err) reject(err)
                    consultation = JSON.parse(JSON.stringify(consultation))
                    let promises = []
                    consultation.tasks.forEach(task => {
                        promises.push(Userconsultation.app.models.Task.createUserTask(ctx.currentInstance.userId, task.id, undefined, undefined, ctx?.currentInstance.id))
                    })
                    Promise.all(promises).then(()=> {
                        resolve()
                    })
                })
            })
        }
    })

    Userconsultation.observe('after save', async function (ctx, next) {
        if (ctx.isNewInstance) {
            try {
                //await createPayment(ctx.instance, false)
                //await createTasks()

                pushNotification.sendPushToUser(
                    ctx.instance.userId, 
                    { 'title': 'КОНСУЛЬТАЦИИ', 'body': 'Поздравляем, Вы успешно записались на консультацию!'},
                    {"type": "userConsultation", "action":"create", "itemId": ctx.instance.id}
                    ).then(res => { }, e => { console.log('e', e) })
                const consultation = await Userconsultation.app.models.Consultation.findById(ctx.instance.consultationId)//ctx.instance.consultation()
                if (consultation.masterId){
                    await Userconsultation.app.models.MasterUsers.upsertWithWhere(
                        { userId: ctx.instance.userId, masterId: consultation.masterId }, { userId: ctx.instance.userId, masterId: consultation.masterId, active: true }
                    )
                }
                const workSlots = await Userconsultation.app.models.WorkSlot.find({where: {userConsultationId: ctx.instance.id}, order: "startDate ASC", limit: 1})//workslotfind
                await ctx.instance.events.create([//eventcreate
                    {
                        eventTypeId: 'consultation',
                        status: 'created',
                        //дате завершения выполнения задания 
                        //(дата назначения задания на игрока + необходимое количество времени на выполнение задания)
                        pushDate: ctx.instance.endDate ? moment(ctx.instance.endDate).subtract(5, 'minute').toDate() : undefined,
                        dateComplete: (workSlots?.length > 0) ? workSlots[0].startDate : ctx.instance.startDate,
                        userId: ctx.instance.userId,
                        masterId: consultation.masterId,
                        description: consultation.name,
                        name: "Запись на консультацию",
                    },
                    {
                        name:"Вы записались на консультацию " + consultation.name,
                        description: consultation.shortDescription,
                        eventTypeId: 'consultation',
                        status: 'completed',
                        dateComplete: new Date(),
                        userId: ctx.instance.userId,
                        masterId: consultation.masterId,
                    }
                ])
                

                //next()
            } catch (e) {
                throw e
            }

        } else {
            //next()
        }

        //добавление пользователю задач, связанных с консультацией
        function createTasks() {

            return Userconsultation.app.models.Consultation.findById(ctx?.instance.consultationId,
                { include: "tasks" }, function (err, consultation) {
                    if (err) throw err
                    consultation = JSON.parse(JSON.stringify(consultation))
                    let promises = []
                    consultation.tasks.forEach(task => {
                        promises.push(Userconsultation.app.models.Task.createUserTask(ctx.instance.userId, task.id, undefined, undefined, ctx?.instance.id))
                    })
                    return Promise.all(promises)
                })
        }
    })


    Userconsultation.cancel = function (consultationIds, cancellationReason, cb) {

        Userconsultation.find(//userconsultationfind
            { where: { id: { inq: consultationIds } } }
            , function (err, userConsultations) {
            if (err) throw err;

            const promises = []
            userConsultations.forEach(item => promises.push(item.updateAttributes({ status: 'cancelled', cancellationReason })))//userconsultationupdate

            Promise.all(promises).then(res => {
                Userconsultation.app.models.WorkSlot.updateAll(//workslotupdate
                    { userConsultationId: { inq: consultationIds } }, { userConsultationId: null },
                    function (err, workSlots) {
                        if (err) throw err;
                        cb(null, "ok")
                    })
            }, err => { throw err })
        })
    }

    Userconsultation.remoteMethod('cancel',
        {
          description: 'запрос на отмену UserConsultation, принимающий массив id',
          accepts: [
            {
              arg: 'consultationIds',
              type: 'array',
              required: true
            },
            {
              arg: 'cancellationReason',
              type: 'string',
              required: false
            }
          ],
          returns: {
            arg: 'result',
            type: 'obj',
            root: true
          },
          http: {
            verb: 'post'
          }
        }
      );

    Userconsultation.getVideocallToken = function (id, role, options, cb) {
        const uid = options.accessToken.userId
        Userconsultation.findById(id, { include: { relation: 'consultation', scope: { fields: ['masterId'] } } }, function (err, userConsultation) {//userconsultationfind
            if (err) throw err
            if (!userConsultation) {
                var err = new Error("not_found");
                err.statusCode = 404;
                cb(err)
            } else {
                userConsultation = JSON.parse(JSON.stringify(userConsultation))
                // if ((role == "publisher" && userConsultation.consultation.masterId == uid)
                //     || (role != "publisher" && userConsultation.userId == uid)) {
                if ((userConsultation.consultation.masterId == uid) || (userConsultation.userId == uid)) {
                    const token = agora.generateAccessToken(
                        id,
                        options.accessToken.userId,
                        role,
                        undefined
                    )
                    cb(null, {token, appId: agora.appId})
                } else {
                    let err = new Error("Error: permission denied")
                    err.statusCode = 403
                    cb(err)
                }
            }
        })
        //cb()
    }
    // remote method after hook
    Userconsultation.afterRemote('getVideocallToken', function (context, remoteMethodOutput, next) {
        agora.nocache(context.req, context.res, next())
        //next();
    });

    Userconsultation.remoteMethod(
        'getVideocallToken',
        {
            description: 'get token for videocall for user consultation',
            accepts: [
                { arg: 'id', type: 'string', required: true },
                {
                    arg: 'role',
                    type: 'string',
                    required: true
                },
                {
                    arg: "options",
                    type: "object",
                    http: "optionsFromRequest"
                },
            ],
            returns: {
                arg: 'token', type: 'object', description: "{token, appId}", root: true
            },
            http: { path: '/:id/getVideocallToken', verb: 'get' }
        },
    )

        /**
         * Get user consultations with filter
         * @param {*} startDate 
         * @param {*} endDate 
         * @param {*} status 
         * @param {*} skip 
         * @param {*} limit 
         * @param {*} options 
         * @param {*} cb 
         * @returns 
         */
    Userconsultation.getUserConsultations = async function (startDate, endDate, status = "created", skip, limit, options, cb) {
        try {
            const user = await Userconsultation.app.models.user.findById(options.accessToken.userId)
            let consultationIds = []
            let userConsultations = []
            if (!user.isMaster) {
                if (startDate || endDate) {
                    const filterArr = [{ $eq: ["$$userConsultationId", "$userConsultationId"] }]
                    if (startDate) filterArr.push({ $lte: [startDate, "$startDate"] })
                    if (endDate) filterArr.push({ $gte: [endDate, "$endDate"] })

                    let aggr = [
                        {
                            $match: {
                                userId: options.accessToken.userId
                            },
                        },
                        {
                            $lookup: {
                                from: "WorkSlot",
                                let: { userConsultationId: "$_id" },
                                pipeline: [
                                    { $match: { $expr: { $and: filterArr } } },
                                    { "$limit": 1 },
                                ],
                                as: "workSlot"
                            }
                        },
                        { $unwind: { path: "$workSlot", preserveNullAndEmptyArrays: false } },
                        {
                            $match: {
                                workSlot: { $exists: true },//длина?
                            },
                        },
                    ]
                    if (skip) aggr.push({ $skip: skip })
                    if (limit) aggr.push({ $limit: limit })

                    let mongoConnector = Userconsultation.app.dataSources.mongodb.connector;
                    consultationIds = await mongoConnector.collection("UserConsultation").aggregate(aggr).map(x => x._id).toArray();//userconsultationfind

                }
                userConsultations = await Userconsultation.find({//userconsultationfind
                    where: (startDate || endDate) ? { id: { inq: consultationIds } } : { userId: options.accessToken.userId, status },
                    skip: (startDate || endDate) ? undefined : skip,
                    limit: (startDate || endDate) ? undefined : limit,
                    include: [{ "relation": "workSlots" }, { "relation": "consultation", "scope": { "include": [{ "relation": "master", "scope": { "include": ["image"] } }] } }],
                })
            } else if (user.isMaster) {
                if (startDate || endDate) {

                    let workSlots = await Userconsultation.app.models.WorkSlot.find({//workslotfind
                        where: {
                            masterId: options.accessToken.userId,
                            userConsultationId: { neq: [null, undefined, ""] },
                            startDate: { lte: endDate }, endDate: { gte: startDate }
                        }
                    })

                    const userConsultationIds = workSlots.map(slot => slot.userConsultationId)
                    userConsultations = await Userconsultation.find({//userconsultationfind
                        where: { id: { inq: userConsultationIds }, status },
                        skip, limit, status,
                        include: [{ "relation": "workSlots" },
                        { "relation": "consultation", "scope": { "include": [{ "relation": "master", "scope": { "include": ["image"] } }] } },
                        { "relation": "user", "scope": { "include": ["image"] } }
                        ],
                    })

                } else {

                    let consultations = await Userconsultation.app.models.Consultation.find({
                        where: { masterId: options.accessToken.userId },
                        include: {
                            relation: 'userConsultations', scope: {
                                where: { status },
                                include: [{ "relation": "workSlots" }, {
                                    "relation": "consultation", "scope": {
                                        "include": [{ "relation": "master", "scope": { "include": ["image"] } }]
                                    }
                                },
                                { "relation": "user", "scope": { "include": ["image"] } }]
                            }
                        }
                    })
                    consultations = JSON.parse(JSON.stringify(consultations))
                    iter: for (let i = 0; i < consultations.length; i++) {
                        for (let j = 0; j < consultations[i].userConsultations.length; j++) {
                            if (skip > 0) {
                                skip--
                            } else {
                                if (limit !== 0 || limit > 0)
                                userConsultations.push(consultations[i].userConsultations[j])
                                else 
                                    break iter
                                if (limit) limit--
                            }
                        }
                    }
                }
            }
            //Если даты не указаны, то все "order":"ASC" по startDate workSlot-ов
            if (!startDate && !endDate) {
                userConsultations = JSON.parse(JSON.stringify(userConsultations))
                userConsultations.sort((a, b) => {
                    const res = new Date(b.workSlots?.[0]?.startDate).getTime()
                        - new Date(a.workSlots?.[0]?.startDate).getTime()
                    //NaN выдает рандомный результат в sort
                    return isFinite(res) ? res : (isFinite(new Date(a.workSlots?.[0]?.startDate).getTime()) ? -1 : 1)
                });
            }
            return userConsultations
        } catch (e) {
            throw e
        }
    }

    Userconsultation.remoteMethod('getUserConsultations',
        {
            description: 'Get user consultations with filter',
            accepts: [
                { arg: 'startDate', type: 'date', required: false },
                { arg: 'endDate', type: 'date', required: false },
                { arg: 'status', type: 'string', required: false },
                { arg: 'skip', type: 'number', required: false },
                { arg: 'limit', type: 'number', required: false },
                {
                    arg: "options",
                    type: "object",
                    http: "optionsFromRequest"
                }
            ],
            returns: {
                arg: 'user consultations',
                type: 'array',
                root: true
            },
            http: { path: '/getUserConsultations', verb: 'get' }
        }
    );


    Userconsultation.getClosest = function (userId, masterId, cb) {
        const now = new moment()
        Userconsultation.app.models.WorkSlot.find({//workslotfind
            where: {
                masterId,
                //startDate: { between: [now, now.add(5, minutes)] },
                startDate: { gte: now },
                userConsultationId: { nin: [null, undefined, ""] },
            },
            sort: "startDate DESC",
            //limit: 1,
            include: {
                relation: "userConsultation", scope: {
                    include: "consultation",
                    where: { userId }
                }
            }
        }, function (err, workSlots) {
            if (err) throw err;
            workSlots = JSON.parse(JSON.stringify(workSlots))

            if (!workSlots || workSlots.length == 0) {
                var err = new Error("not_found");
                err.statusCode = 404;
                cb(err)
            } else {
                let closest
                for (let i = 0; i < workSlots.length; i++) {
                    if (workSlots[i].userConsultation) {
                        closest = i;
                        break
                    }
                }
                if (closest !== undefined) {
                    const diff = moment(workSlots[closest].startDate).diff(now)
                    cb(null, {
                        time: diff,
                        fiveMin: !!(diff < 5 * 60 * 1000),
                        userConsultation: workSlots[closest].userConsultation
                    })
                } else {
                    var err = new Error("not_found");
                    err.statusCode = 404;
                    cb(err)
                }
            }
        })
    }

    Userconsultation.remoteMethod('getClosest',
    {
        description: 'Get user consultations with filter',
        accepts: [
            { arg: 'userId', type: 'string', required: true },
            { arg: 'masterId', type: 'string', required: true },
        ],
        returns: {
            arg: 'user consultations',
            type: 'object',
            root: true
        },
        http: { path: '/getClosest', verb: 'get' }
    }
);

    Userconsultation.agoraCB = function (ctx, req, res, body, query,options, cb) {
        //const optionsRemote = { accessToken: options.accessToken };
        console.log('req', req)
        console.log('res',  res)
        console.log('body', body)
        console.log('query', query)
        //res.status(201)
        cb(null, 'ok')
    }

    Userconsultation.remoteMethod('agoraCB',
        {
            description: 'agora callback endpoint',
            accepts: [
                {
                    arg: 'ctx',
                    type: 'object',
                    http: {
                        source: 'context'
                    }
                },
                {
                    arg: 'req',
                    type: 'object',
                    'http': {
                        source: 'req'
                    }
                },
                {
                    arg: 'res',
                    type: 'object',
                    http: {
                        source: 'res'
                    }
                },
                {
                    "arg": "body",
                    "type": "object",
                    "http": {
                        "source": "body"
                    },
                    "required": false
                },
                {
                  description: 'e.g. {where: ..., include: ...}',
                  arg: 'query',
                  type: 'object',
                  required: false
                },
                {
                    arg: "options",
                    type: "object",
                    http: "optionsFromRequest"
                }
            ],
            returns: {
                arg: 'object',
                type: 'object',
                root: true
            },
            http: {
                verb: 'post'
            }
        }
    );

};
