'use strict';

module.exports = function(Mycommunication) {

};
