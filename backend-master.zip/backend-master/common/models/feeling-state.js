'use strict';
var moment = require('moment');

module.exports = function(Feelingstate) {

    /**
   * Create feeling state with user time
   * 
   * @param {string} userId
   * @param {number} value
   * @param {number} year
   * @param {number} month - where january is 0
   * @param {number} day
   * @param {number} hours
   * @param {number} minutes
   * @param {number} seconds
   * @param {*} cb 
   */
  //создает запись feelingState с пользовательским временем
  Feelingstate.createWithTime = function (userId, value, year, month, day, hours, minutes, seconds, cb) {
    Feelingstate.create({userId, value, date: new Date(year, month, day, hours, minutes, seconds)}, function(err, result) {
        if (err) throw err;
        cb(null, result)
    })
  }
    
  Feelingstate.remoteMethod('createWithTime',
    {
      description: 'Create feeling state with user time',
      accepts: [
        {
          arg: 'userId',
          type: 'string',
          required: true
        },
        {
          arg: 'value',
          type: 'number',
          required: true
        },
        {
          arg: 'year',
          type: 'number',
          required: true
        },
        {
          arg: 'month',
          description: 'january is 0',
          type: 'number',
          required: true
        },
        {
          arg: 'day',
          type: 'number',
          required: true
        },
        {
          arg: 'hours',
          type: 'number',
          required: true
        },
        {
          arg: 'minutes',
          type: 'number',
          required: true
        },
        {
          arg: 'seconds',
          type: 'number',
          required: true
        }
      ],
      returns: {
          arg: 'feelingStateObject',
          type: 'object',
          root: true
      },
      http: {
          verb: 'post'
      }
    }
  );

    /**
     * Return percent of feelings from array of feelings
     * @param {array} stateArray - array of feelingState objects
     * 
     * @returns {object} - object of feeling with percent, e.g. {1: 20, 3: 80}
     */
    function getPercent(stateArray) {
        let answer = {};
        //кол-во каждого чувства
        stateArray.map(state => {
            answer[state.value] ? answer[state.value]++ : (answer[state.value] = 1);
        })
        //процентовка каждого чувства
        for (let key in answer) {
            answer[key] = (answer[key] * 100) / stateArray.length;
        }
        return answer;
    }

  /**
   * Returns all feelings for a day in percent
   * 
   * @param {string} userId
   * @param {number} year
   * @param {number} month - where january is 0
   * @param {number} day
   * @param {*} cb 
   */
  //по следующим параметрам возвращает объект со всеми чувствами и их процентным соотношением за день
  Feelingstate.getDay = function (userId, year, month, day, cb) {
    Feelingstate.find({where: {
        userId: userId, 
        date: {between: [new Date(year, month, day),
        new Date(year, month, day, 23, 59, 59)]}
    }}, function(err, result) {
        if (err) throw err;
        /*let answer = {};
        //кол-во каждого чувства
        result.map(state => {
            answer[state.value] ? answer[state.value]++ : (answer[state.value] = 1);
        })
        //процентовка каждого чувства
        for (let key in answer) {
            answer[key] = (answer[key] * 100) / result.length;
        }*/
        cb(null, getPercent(result))
    })
  }
    
  Feelingstate.remoteMethod('getDay',
    {
      description: 'Returns all feelings for a day in percent',
      accepts: [
        {
          arg: 'userId',
          type: 'string',
          required: true
        },
        {
          arg: 'year',
          type: 'number',
          required: true
        },
        {
          arg: 'month',
          description: 'january is 0',
          type: 'number',
          required: true
        },
        {
          arg: 'day',
          type: 'number',
          required: true
        }
      ],
      returns: {
          arg: 'percentObjects',
          description: 'object of feeling percents, e.g. {1: 20, 3:80}',
          type: 'object',
          root: true
      },
      http: {
          verb: 'post'
      }
    }
  );

  /**
   * Returns all feelings for a current week in percent
   * 
   * @param {string} userId
   * @param {number} year
   * @param {number} month - where january is 0
   * @param {number} day
   * @param {*} cb 
   */
  //по следующим параметрам возвращает объект со всеми чувствами и их процентным соотношением за текущую неделю
  Feelingstate.getWeek = function (userId, year, month, day, cb) {
    const currentDate = new Date(year, month, day);
    const start = moment(currentDate).startOf('isoWeek').toDate();//day(1).toDate();//понедельник
    const end = moment(currentDate).endOf('isoWeek').toDate();//day(7).endOf("day").toDate();//воскресенье
    Feelingstate.find({where: {
        userId: userId, 
        date: {between: [start, end]}
    }}, function(err, result) {
        if (err) throw err;
        cb(null, getPercent(result))
    })
  }
    
  Feelingstate.remoteMethod('getWeek',
    {
      description: 'Returns all feelings for a current week in percent',
      accepts: [
        {
          arg: 'userId',
          type: 'string',
          required: true
        },
        {
          arg: 'year',
          type: 'number',
          required: true
        },
        {
          arg: 'month',
          description: 'january is 0',
          type: 'number',
          required: true
        },
        {
          arg: 'day',
          type: 'number',
          required: true
        }
      ],
      returns: {
          arg: 'percentObjects',
          description: 'object of feeling percents, e.g. {1: 20, 3:80}',
          type: 'object',
          root: true
      },
      http: {
          verb: 'post'
      }
    }
  );

    /**
   * Returns all feelings for a current month in percent
   * 
   * @param {string} userId
   * @param {number} year
   * @param {number} month - where january is 0
   * @param {*} cb 
   */
  //по следующим параметрам возвращает объект со всеми чувствами и их процентным соотношением за текущий месяц
  Feelingstate.getMonth = function (userId, year, month, cb) {
    const start = new Date(year, month);
    const end = moment(start).endOf('month').toDate();
    Feelingstate.find({where: {
        userId: userId, 
        date: {between: [start, end]}
    }}, function(err, result) {
        if (err) throw err;
        cb(null, getPercent(result))
    })
  }
    
  Feelingstate.remoteMethod('getMonth',
    {
      description: 'Returns all feelings for a current month in percent',
      accepts: [
        {
          arg: 'userId',
          type: 'string',
          required: true
        },
        {
          arg: 'year',
          type: 'number',
          required: true
        },
        {
          arg: 'month',
          description: 'january is 0',
          type: 'number',
          required: true
        }
      ],
      returns: {
          arg: 'percentObjects',
          description: 'object of feeling percents, e.g. {1: 20, 3:80}',
          type: 'object',
          root: true
      },
      http: {
          verb: 'post'
      }
    }
  );

   /**
   * Returns all feelings for a current year in percent
   * 
   * @param {string} userId
   * @param {number} year
   * @param {*} cb 
   */
  //по следующим параметрам возвращает объект со всеми чувствами и их процентным соотношением за текущий год
  Feelingstate.getYear = function (userId, year, cb) {
    const start = new Date(year, 0);
    const end = moment(start).endOf('year').toDate();
    Feelingstate.find({where: {
        userId: userId, 
        date: {between: [start, end]}
    }}, function(err, result) {
        if (err) throw err;
        cb(null, getPercent(result))
    })
  }
    
  Feelingstate.remoteMethod('getYear',
    {
      description: 'Returns all feelings for a current year in percent',
      accepts: [
        {
          arg: 'userId',
          type: 'string',
          required: true
        },
        {
          arg: 'year',
          type: 'number',
          required: true
        }
      ],
      returns: {
          arg: 'percentObjects',
          description: 'object of feeling percents, e.g. {1: 20, 3:80}',
          type: 'object',
          root: true
      },
      http: {
          verb: 'post'
      }
    }
  );
};
