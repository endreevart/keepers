'use strict';
const path = require('path');

module.exports = function(Aim) {
    Aim.observe('after save', async function (ctx, next) {
        if (ctx.isNewInstance) {
            //для первой добавленной цели - +500 баллов пользователю
            const userAim = await Aim.findOne({where: {userId: ctx.instance.userId, id: {neq: ctx.instance.id}}}) 
            if (!userAim) {
                const user = await Aim.app.models.user.findById(ctx.instance.userId)
                await user.updateAttribute("level_points", user.level_points + 500)
            }
        }
    })

    Aim.createByName = function (userId, names, req, cb) {
        // names = names.map(name => {return {userId, name}});
        // return Aim.create(names)
        try {
            const promises = [];
            (names || []).forEach(name => {
                promises.push(
                    new Promise(async function (resolve, reject) {
                        try {
                            let res = await Aim.create({ userId, name })

                            if (req?.files?.[0])
                                await Aim.app.models.image.uploadWithCompression("aim", res.id, null, null, null, req, cb)
                            else {
                                const logopath = path.join(Aim.app.get("rootStatic"), 'images/icon_app_1024_black.svg')
                                await Aim.app.models.image.copy("aim", res.id, null, null, null, null, logopath, cb)
                            }
                            resolve(res)

                        } catch (error) {
                            reject(error)
                        }
                    })
                )
            });

            return Promise.all(promises)
        } catch (e) {
            throw e
        }
    }

    Aim.remoteMethod('createByName',
    {
        description: 'create user aims by array of names',
        accepts: [
            { arg: 'userId', type: 'string', required: true },
            { arg: 'names', type: 'array', required: true },
            {//for image
                arg: 'req',
                type: 'object',
                'http': {
                    source: 'req'
                }
            },
        ],
        returns: {
            arg: 'aims',
            type: 'object',
            root: true
        },
        http: { path: '/createByName', verb: 'post' }
    })

    Aim.createBySystemAims = async function (userId, aimIds, req, cb) {
        try {
            let systAims = await Aim.app.models.SystemAim.find({ where: { id: { inq: aimIds } }/*, include: ["sphereOfLife"]*/ })
            const promises = []
                (systAims || []).forEach(systAim => {
                    promises.push(
                        new Promise(async function (resolve, reject) {
                            try {
                                let res = await Aim.create({ userId: userId, name: systAim.name })

                                if (systAim.sphereOfLifeId) {
                                    await res.sphereOfLife.add(systAim.sphereOfLifeId)
                                }

                                if (req?.files?.[0])
                                    await Aim.app.models.image.uploadWithCompression("aim", res.id, null, null, null, req, cb)
                                else {
                                    const logopath = path.join(Aim.app.get("rootStatic"), 'images/icon_app_1024_black.svg')
                                    await Aim.app.models.image.copy("aim", res.id, null, null, null, null, logopath, cb)
                                }

                                resolve(res)

                            } catch (error) {
                                reject(error)
                            }
                        })
                    )
                });

            const res = await Promise.all(promises)
            return res
        } catch (e) {
            throw e
        }
    }

    Aim.remoteMethod('createBySystemAims',
    {
        description: 'create user aims by array of names',
        accepts: [
            { arg: 'userId', type: 'string', required: true },
            { arg: 'aimIds', type: 'array', required: true },
            {//for image
                arg: 'req',
                type: 'object',
                'http': {
                    source: 'req'
                }
            },
        ],
        returns: {
            arg: 'aims',
            type: 'object',
            root: true
        },
        http: { path: '/createBySystemAims', verb: 'post' }
    })
};
