'use strict';

module.exports = function(Tabletnotification) {
    Tabletnotification.observe('before save', async function (ctx, next) {
        // console.log('Tabletnotification ctx.instance', ctx.instance)
		// console.log('Tabletnotification ctx.data', ctx.data)
		// console.log('Tabletnotification ctx.isNewInstance', ctx.isNewInstance)
		// console.log('Tabletnotification ctx.currentInstance', ctx.currentInstance)
        if (ctx.isNewInstance) {
            ctx.instance.date = new Date(2020, 0, 1, new Date(ctx.instance.date).getHours(), new Date(ctx.instance.date).getMinutes())
        } else {
            ctx.data.date = new Date(2020, 0, 1, new Date(ctx.data.date).getHours(), new Date(ctx.data.date).getMinutes())
        }
    })

    /**delete own notification
     * 
     * @param {string} notificationId 
     * @param {*} options 
     * @param {*} cb 
     */
    Tabletnotification.delete = function (notificationId, options, cb) {
        if (options.accessToken && options.accessToken.userId) {
            Tabletnotification.findById(notificationId, function (err, notif) {
                if (err) throw err;
                if (!notif) {
                    let err = new Error("Error: notification not found")
                    err.statusCode = 401
                    cb(err)
                } else {
                    if (notif.userId == options.accessToken.userId && notif.tabletTypeId != 'morning' && notif.tabletTypeId != 'evening') {
                        Tabletnotification.deleteById(notificationId, function (err, notif) {
                            if (err) throw err;
                            cb(null)
                        })
                    } else {
                        let err = new Error("Error: permission denied")
                        err.statusCode = 403
                        cb(err)
                    }
                }
            })
        } else {
            let err = new Error("Error: no access token")
			err.statusCode = 401
			cb(err)
        }
    };


    Tabletnotification.remoteMethod('delete',
        {
            description: 'Deletes own notification.',
            accepts: [
                {
                    arg: 'notificationId',
                    type: 'string',
                    required: true
                },
                {
					arg: "options",
					type: "object",
					http: "optionsFromRequest"
				}
            ],
            returns: {
                arg: 'fileObject',
                type: 'object',
                root: true
            },
            http: {
                //path: '/files/:file',
                verb: 'delete'
            }
        }
    );
};
