'use strict';

module.exports = function (Case) {
}