'use strict';

module.exports = function(Sphereoflife) {

};
