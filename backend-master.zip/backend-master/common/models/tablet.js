'use strict';
var moment = require('moment');
const modelOperations = require('../../helpers/modelOperations.js');
const modelOperationsModule = require("../../helpers/modelOperations.js")

module.exports = function (tablet) {

  tablet.observe('after save', async function (ctx, next) {
    if (ctx.isNewInstance) {
      const user = await tablet.app.models.user.findById(ctx.instance.userId)
      //каждая скрижаль - +50 очков пользователю
      await user.updateAttribute("level_points", user.level_points + 50)
    } else {
      if (!ctx.data?.totalTabletId && ctx.instance?.totalTabletId) {
        try {
          await tablet.createTotalTablet(
            null, 
            null, 
            ctx.instance.start || new moment(ctx.instance.created).subtract(1, 'day'), 
            ctx.instance.end || ctx.instance.created, 
            ctx.instance.totalTabletId
          )
        } catch (e) {
          console.log('e', e)
        }
      }
    }
  })

  /**
     * Create tablet with user time
     * 
     * @param {string} userId
     * @param {string} feelingStateId
     * @param {string} energyStateId
     * @param {string} message
     * @param {string} image
     * @param {string} feelingValue
     * @param {number} energyValue
     * @param {number} level
     * @param {number} level_points
     * @param {number} reward
     * @param {number} year
     * @param {number} month - where january is 0
     * @param {number} day
     * @param {number} hours
     * @param {number} minutes
     * @param {number} seconds
     * @param {*} cb 
     */
  //создает запись tablet с пользовательским временем

  tablet.createWithTime = function (userId, feelingStateId, energyStateId, message, image, feelingValue, energyValue, level, level_points, reward, year, month, day, hours, minutes, seconds, cb) {
    tablet.create({ userId, feelingStateId, energyStateId, message, image, feelingValue, energyValue, level, level_points, reward, date: new Date(year, month, day, hours, minutes, seconds) }, function (err, result) {
      if (err) throw err;
      cb(null, result)
    });
  }
  tablet.remoteMethod('createWithTime',
    {
      description: 'Create tablet with user time',
      accepts: [
        {
          arg: 'userId',
          type: 'string',
          required: true
        },
        {
          arg: 'feelingStateId',
          type: 'string'
        },
        {
          arg: 'energyStateId',
          type: 'string'
        },
        {
          arg: 'message',
          type: 'string'
        },
        {
          arg: 'image',
          type: 'string'
        },
        {
          arg: 'feelingValue',
          type: 'string'
        },
        {
          arg: 'energyValue',
          type: 'number'
        },
        {
          arg: 'level',
          type: 'number',
          required: true
        },
        {
          arg: 'level_points',
          type: 'number',
          required: true
        },
        {
          arg: 'reward',
          type: 'number',
          required: true
        },
        {
          arg: 'year',
          type: 'number',
          required: true
        },
        {
          arg: 'month',
          description: 'january is 0',
          type: 'number',
          required: true
        },
        {
          arg: 'day',
          type: 'number',
          required: true
        },
        {
          arg: 'hours',
          type: 'number',
          required: true
        },
        {
          arg: 'minutes',
          type: 'number',
          required: true
        },
        {
          arg: 'seconds',
          type: 'number',
          required: true
        }
      ],
      returns: {
        arg: 'tabletObject',
        type: 'object',
        root: true
      },
      http: {
        verb: 'post'
      }
    }
  );

  /**
     * за день
     * 
     * @param {string} userId
     * @param {number} year
     * @param {number} month - where january is 0
     * @param {number} day
     * @param {*} cb 
     */
  //по следующим параметрам возвращает массив объектов tablet за день
  tablet.getDay = function (userId, year, month, day, cb) {
    const start = new Date(year, month, day);
    const end = moment(start).endOf('day').toDate(); //console.log('start', start, end)
    tablet.find({
      where: {
        userId: userId,
        date: { between: [start, end] }
      }
    }, function (err, result) {
      if (err) throw err;
      cb(null, result)
    })
  }

  tablet.remoteMethod('getDay',
    {
      description: 'Получить комментарии и изображения замеров за день',
      accepts: [
        {
          arg: 'userId',
          type: 'string',
          required: true
        },
        {
          arg: 'year',
          type: 'number',
          required: true
        },
        {
          arg: 'month',
          description: 'january is 0',
          type: 'number',
          required: true
        },
        {
          arg: 'day',
          type: 'number',
          required: true
        }
      ],
      returns: {
        arg: 'tabletObjects',
        description: 'array of all tablet for a day',
        type: 'object',
        root: true
      },
      http: {
        verb: 'post'
      }
    }
  );

  //   /**
  //    * Returns object of average energy state for each day for a week
  //    * 
  //    * @param {string} userId
  //    * @param {number} year
  //    * @param {number} month - where january is 0
  //    * @param {number} day
  //    * @param {*} cb 
  //    */
  //   //по следующим параметрам возвращает среднее значение энергетического баланса за каждый день в течении недели
  //   Energystate.getWeek = function (userId, year, month, day, cb) {
  //     const currentDate = new Date(year, month, day);
  //     const start = moment(currentDate).startOf('isoWeek').toDate();//понедельник
  //     const end = moment(currentDate).endOf('isoWeek').toDate();//воскресенье
  //     Energystate.find({where: {
  //         userId: userId, 
  //         date: {between: [start, end]}
  //     }}, function(err, result) {
  //         if (err) throw err;
  //         let answer = {};
  //         //для каждой даты
  //         result.map(state => {
  //             const datestring = new Date(state.date).getDay();
  //             answer[datestring] ? (answer[datestring].num++, answer[datestring].sum += state.value) : (answer[datestring] = {num: 1, sum: state.value});
  //         })
  //         //среднее каждого энергетического баланса за день недели
  //         for (let key in answer) {
  //             answer[key] = answer[key].sum / answer[key].num;
  //         }
  //         cb(null, answer)
  //     })
  //   }

  //   Energystate.remoteMethod('getWeek',
  //     {
  //       description: 'Returns object of average energy state for each day for a week',
  //       accepts: [
  //         {
  //           arg: 'userId',
  //           type: 'string',
  //           required: true
  //         },
  //         {
  //           arg: 'year',
  //           type: 'number',
  //           required: true
  //         },
  //         {
  //           arg: 'month',
  //           description: 'january is 0',
  //           type: 'number',
  //           required: true
  //         },
  //         {
  //           arg: 'day',
  //           type: 'number',
  //           required: true
  //         }
  //       ],
  //       returns: {
  //           arg: 'energyStates',
  //           description: 'object of all energy states for a week, e.g. {1: 1.5, 4: 5}, there monday is 1, sunday is 0',
  //           type: 'object',
  //           root: true
  //       },
  //       http: {
  //           verb: 'post'
  //       }
  //     }
  //   );

  //   /**
  //    * Returns object of average energy state for each day for a month
  //    * 
  //    * @param {string} userId
  //    * @param {number} year
  //    * @param {number} month - where january is 0
  //    * @param {*} cb 
  //    */
  //   //по следующим параметрам возвращает среднее значение энергетического баланса за каждый день в течении месяца
  //   Energystate.getMonth = function (userId, year, month, cb) {
  //     const start = new Date(year, month);
  //     const end = moment(start).endOf('month').toDate();
  //     Energystate.find({where: {
  //         userId: userId, 
  //         date: {between: [start, end]}
  //     }}, function(err, result) {
  //         if (err) throw err;
  //         let answer = {};
  //         //для каждого дня расчет суммы и кол-ва оценок
  //         result.map(state => {
  //             const datestring = new Date(state.date).getDate();
  //             answer[datestring] ? (answer[datestring].num++, answer[datestring].sum += state.value) : (answer[datestring] = {num: 1, sum: state.value});
  //         })
  //         //среднее энергетического баланса за день месяца
  //         for (let key in answer) {
  //             answer[key] = answer[key].sum / answer[key].num;
  //         }
  //         cb(null, answer)
  //     })
  //   }

  //   Energystate.remoteMethod('getMonth',
  //     {
  //       description: 'Returns object of average energy state for each day for a month',
  //       accepts: [
  //         {
  //           arg: 'userId',
  //           type: 'string',
  //           required: true
  //         },
  //         {
  //           arg: 'year',
  //           type: 'number',
  //           required: true
  //         },
  //         {
  //           arg: 'month',
  //           description: 'january is 0',
  //           type: 'number',
  //           required: true
  //         }
  //       ],
  //       returns: {
  //           arg: 'energyStates',
  //           description: 'object of all energy states for a month, e.g. {1: 1.5, 4: 5}',
  //           type: 'object',
  //           root: true
  //       },
  //       http: {
  //           verb: 'post'
  //       }
  //     }
  //   );

  //   /**
  //    * Returns object of average energy state for each month for a year
  //    * 
  //    * @param {string} userId
  //    * @param {number} year
  //    * @param {*} cb 
  //    */
  //   //по следующим параметрам возвращает среднее значение энергетического баланса за каждый месяц в течении года
  //   Energystate.getYear = function (userId, year, cb) {
  //     const start = new Date(year, 0);
  //     const end = moment(start).endOf('year').toDate();
  //     Energystate.find({where: {
  //         userId: userId, 
  //         date: {between: [start, end]}
  //     }}, function(err, result) {
  //         if (err) throw err;
  //         let answer = {};
  //         //для каждого месяца расчет суммы и кол-ва оценок
  //         result.map(state => {
  //             const datestring = new Date(state.date).getMonth();
  //             answer[datestring] ? (answer[datestring].num++, answer[datestring].sum += state.value) : (answer[datestring] = {num: 1, sum: state.value});
  //         })
  //         //среднее энергетического баланса за месяц
  //         for (let key in answer) {
  //             answer[key] = answer[key].sum / answer[key].num;
  //         }
  //         cb(null, answer)
  //     })
  //   }

  //   Energystate.remoteMethod('getYear',
  //     {
  //       description: 'Returns object of average energy state for each month for a year',
  //       accepts: [
  //         {
  //           arg: 'userId',
  //           type: 'string',
  //           required: true
  //         },
  //         {
  //           arg: 'year',
  //           type: 'number',
  //           required: true
  //         }
  //       ],
  //       returns: {
  //           arg: 'energyStates',
  //           description: 'object of all energy states for a year, there january is 0, e.g. {1: 1.5, 4: 5}',
  //           type: 'object',
  //           root: true
  //       },
  //       http: {
  //           verb: 'post'
  //       }
  //     }
  //   );

  tablet.edit = async function (id, attributes, options, cb) {
    try {
      const tabletInst = await tablet.findById(id)
      await tabletInst.updateAttributes(attributes)

      if (!tabletInst) {
        var err = new Error("not_found");
        err.statusCode = 404;
        throw err
      } else {
        if (tabletInst.totalTabletId) {
          //await tablet.createTotalTablet(null, null, tabletInst.start || new moment(tabletInst.created).subtract(1, 'day'), tabletInst.end || tabletInst.created, tabletInst.totalTabletId)
          return tabletInst
        } else {
          return tabletInst
        }
      }

    } catch (e) {
      cb(e)
    }
  }

  tablet.remoteMethod('edit',
    {
      description: 'edit tablet',
      accepts: [
        { arg: 'id', type: 'string', required: true },
        { arg: 'attributes', type: 'object', required: true, http: { source: 'body' } },
        {
          arg: "options",
          type: "object",
          http: "optionsFromRequest"
        }
      ],
      returns: {
        arg: 'edited tablet',
        type: 'object',
        root: true
      },
      http: { path: '/:id/edit', verb: 'post' }
    }
  );


  tablet.createTotalTablet = async function (startDate, endDate, start2, end2, totalTabletId) {
    try {
      let mongoConnector = tablet.app.dataSources.mongodb.connector;
      let aggr = [{ $sort: { date: 1 } },]
      if (totalTabletId)
        aggr = aggr.concat([
          { $match: { totalTabletId: totalTabletId } },
        ])
      else
        aggr = aggr.concat([
          {
            $lookup:
            {
              from: "TabletNotification",
              let: { userId: "$userId" },
              pipeline: [
                { $match: { "$expr": { $and: [{ "$gte": ["$date", startDate] }, { "$lt": ["$date", endDate] }, { "$eq": ["$userId", "$$userId"] }, { "$eq": ["$tabletTypeId", "morning"] }] } } },
                { $project: { _id: 1, id: "$_id", date: 1, userId: 1 } }
              ],
              as: "tabletNotification"
            }
          },
          { $unwind: { path: "$tabletNotification", preserveNullAndEmptyArrays: true } },
          { $match: { $expr: { $eq: ["$userId", "$tabletNotification.userId"] }, date: { $gte: start2, $lt: end2 } } },
        ])
      let a = await mongoConnector.collection("tablet").aggregate(aggr.concat([

        //мои эгосостояния
        {
          $lookup: {
            from: "MySelfStatetablet",
            let: { tabletId: "$_id" },
            pipeline: [
              { $match: { $expr: { $eq: ["$$tabletId", "$tabletId"] } } },
              {
                $lookup: {
                  from: "MySelfState",
                  let: { mySelfStateId: "$mySelfStateId" },
                  pipeline: [{ $match: { $expr: { $eq: ["$$mySelfStateId", "$_id"] } } },
                  { $project: { name: 1, _id: 1, type: 1 } }],
                  as: "mySelfState"
                }
              },
              { $unwind: { path: "$mySelfState", preserveNullAndEmptyArrays: true } },
              { $project: { mySelfState: 1, mySelfStateId: 1, _id: 1, count: { $sum: 1 } } },



            ],
            as: "mySelfStates"
          }
        },

        { $addFields: { mySelfStates2: { $concatArrays: "$mySelfStates.mySelfState" } } },

        //психосоматика
        {
          $lookup: {
            from: "Psychosomaticstablet",
            let: { tabletId: "$_id" },
            pipeline: [
              { $match: { $expr: { $eq: ["$$tabletId", "$tabletId"] } } },
              { $project: { psychosomaticsId: 1, _id: 1 } },


            ],
            as: "psychosomatics"
          }
        },

        {
          $lookup: {
            from: "Joytablet",
            let: { tabletId: "$_id" },
            pipeline: [
              { $match: { $expr: { $eq: ["$$tabletId", "$tabletId"] } } },
              { $project: { joyId: 1, _id: 1 } },
            ],
            as: "joys"
          }
        },

        //мои communication
        {
          $lookup: {
            from: "MyCommunicationtablet",
            let: { tabletId: "$_id" },
            pipeline: [
              { $match: { $expr: { $eq: ["$$tabletId", "$tabletId"] } } },
              { $project: { myCommunicationId: 1, _id: 1 } },


            ],
            as: "myCommunications"
          }
        },

        //изображения
        {
          $lookup: {
            from: "image",
            let: { tabletId: "$_id" },
            pipeline: [
              {
                $match: {
                  $and: [
                    {
                      $expr: {
                        "$eq": ["$tabletId", "$$tabletId"],
                      }
                    },
                  ]
                }
              },
              {
                $sort: {
                  created: 1
                }
              },
              {
                $limit: 1
              },
              { $project: { path: 1, tabletId: 1, _id: 1, created: 1 } },
            ],
            as: "image"
          }
        },
        { $unwind: { path: "$image", preserveNullAndEmptyArrays: true } },

        {
          $group:
          {
            //_id: "$userId",
            _id: { userId: "$userId", tabletTypeId: "$tabletTypeId" },
            points: { $sum: 50 },//баллы за день
            userId: { $first: "$userId" },
            tabletTypeId: { $first: "$tabletTypeId" },

            markCount: {
              $sum: 1
            },
            myTalkForType: { $addToSet: "$myTalk" },//все myTalk из объединяемых tablet в массив по времени создания",

            mySelfStates: { $push: "$mySelfStates2" },

            //намерение на день String - берется из утренней скрижали"
            dayIntention: { $first: { $cond: [{ $eq: ["$tabletTypeId", "morning"] }, "$dayIntention", undefined] } },
            //Что я сделал для совершения намерения String - брать из вечерней скрижали dayIntention"
            dayIntentionAction: { $first: { $cond: [{ $eq: ["$tabletTypeId", "evening"] }, "$intentionActions", undefined] } },
            //? Краткое описание моего дня: содержит в себе: 1 описание утра с утренней tablet 2 с вечерней взять описание дня
            shortDescription: { $first: { $cond: [{ $or: [{ $eq: ["$tabletTypeId", "morning"] }, { $eq: ["$tabletTypeId", "evening"] }] }, "$shortDayDescription", undefined] } },
            //Какие зеркала я видел - массив String - взять все с дневной tablet, и взять все с вечерней tablet + ночной
            mirrors: { $addToSet: { $cond: [{ $or: [{ $eq: ["$tabletTypeId", "day"] }, { $eq: ["$tabletTypeId", "evening"] }, { $eq: ["$tabletTypeId", "night"] }] }, "$mirrors", undefined] } },
            //какие знаки и подсказки я увидела - String - взять с вечерней tablet
            signsAndHints: { $first: { $cond: [{ $eq: ["$tabletTypeId", "evening"] }, "$signsAndHints", undefined] } },
            //за что я благодарю мир - String - взять с вечерней tablet
            thanksFor: { $first: { $cond: [{ $eq: ["$tabletTypeId", "evening"] }, "$thanksFor", undefined] } },
            //мой ресурс - массив строк - взять все указанные 'мои ресурсы' с вечерней скрижали - заменили на радости
            joy: { $first: { $cond: [{ $eq: ["$tabletTypeId", "evening"] }, "$joys.joyId", undefined] } },//todayResources
            psychosomatics: { $first: { $cond: [{ $eq: ["$tabletTypeId", "evening"] }, "$psychosomatics.psychosomaticsId", undefined] } },

            //imageTabletId: { $first: { $cond: [{ $eq: ["$tabletTypeId", "morning"] }, "$_id", null] } },
            user: { $first: "$user" },
            //eventsSum: {$sum: {$size}}
            date: { $last: "$date" },
            level: { $last: "$level" },
            level_points: { $last: "$level_points" },

            myCommunications: { $push: "$myCommunications.myCommunicationId" },
            myRoles: { $push: { $cond: [{ $or: [{ $eq: ["$tabletTypeId", "day"] }, { $eq: ["$tabletTypeId", "evening"] }, { $eq: ["$tabletTypeId", "night"] }] }, "$myRoleTabletId", "$$REMOVE"] } },//"$$REMOVE"

            gameDayDate: { $max: "$gameDayDate" },

            images: { $push: "$image" }, //{$cond: [{ $ne: ["$tabletTypeId", null] }, "$image", "$$REMOVE"] }},//"$image"},
            //tabletNotification:{$first: "$tabletNotification"},
            tabletIds: { $push: "$_id" }
          }
        },
        { $sort: { date: 1 } },


        //сколько событий
        {
          $lookup:
          {
            from: "Event",
            let: { userId: "$userId" },
            pipeline: [
              {
                $match: {
                  "$expr": {
                    $and: [
                      { $gte: ["$dateComplete", start2] },
                      { $lt: ["$dateComplete", end2] },
                      { "$eq": ["$status", "completed"] },
                      { "$eq": ["$userId", "$$userId"] },
                    ]
                  }//, "status": "completed"
                }
              },
              {
                $project: {
                  _id: 1//, count: { $sum: 1 } 
                }
              }
            ],
            as: "events"
          }
        },
        { $addFields: { "eventSum": { $size: "$events" } } },


        {
          $addFields: {
            mySelfStates2: {
              $reduce: {
                input: "$mySelfStates",
                initialValue: [],
                in: {
                  $concatArrays: { $concatArrays: { $concatArrays: ["$$value", "$$this"] } }
                }
              }
            }
          }
        },


        {
          $addFields: {
            myCommunications: {
              $reduce: {
                input: "$myCommunications",
                initialValue: [],
                in: {
                  $concatArrays: { $concatArrays: { $concatArrays: ["$$value", "$$this"] } }
                }
              }
            }
          }
        },


        {
          $group:
          {
            _id: "$userId",
            userId: { $first: "$userId" },
            tabletPoints: { $sum: "$points" },//баллы за день
            markCount: {
              $sum: "$markCount"
            },
            myTalkTotal2: { $addToSet: "$myTalkForType" },
            //намерение на день String - берется из утренней скрижали"
            dayIntention: { $max: "$dayIntention" },
            //Что я сделал для совершения намерения String - брать из вечерней скрижали dayIntention"
            dayIntentionAction: { $max: "$dayIntentionAction" },
            //? Краткое описание моего дня: содержит в себе: 1 описание утра с утренней tablet 2 с вечерней взять описание дня
            shortDescription: { $addToSet: "$shortDescription" },
            //Какие зеркала я видел - массив String - взять все с дневной tablet, и взять все с вечерней tablet
            mirrors2: { $addToSet: "$mirrors" },
            //какие знаки и подсказки я увидела - String - взять с вечерней tablet
            signsAndHints: { $max: "$signsAndHints" },
            //за что я благодарю мир - String - взять с вечерней tablet
            thanksFor: { $max: "$thanksFor" },
            //мой ресурс - массив строк - взять все указанные 'мои ресурсы' с вечерней скрижали - заменили на радости
            joy: { $max: "$joy" },
            eventCount: { $first: "$eventSum" },
            psychosomaticsArr: { $max: "$psychosomatics" },

            mySelfStates: { $push: "$mySelfStates2" },
            level: { $last: "$level" },
            level_points: { $last: "$level_points" },


            myCommunications: { $push: "$myCommunications" },
            myRoles: { $push: "$myRoles" },

            gameDayDate: { $max: "$gameDayDate" },
            //imageId: {$first: "$imageId"},
            images: { $push: "$images" },
            //tabletNotification:{$first: "$tabletNotification"}     ,
            tabletIds: { $push: "$tabletIds" }
          },
        },

        {
          $addFields: {
            images: {
              $reduce: {
                input: "$images",
                initialValue: [],
                in: {
                  $concatArrays: { $concatArrays: { $concatArrays: ["$$value", "$$this"] } }
                }
              }
            }
          }
        },
        {
          $lookup:
          {
            from: "UserTask",
            let: { userId: "$userId" },
            pipeline: [
              { $match: { "$expr": { $and: [{ "$eq": ["$status", "completed"] }] } } },


              {
                $lookup: {
                  from: "Task",
                  let: { taskId: "$taskId" },
                  pipeline: [{ $match: { $expr: { $eq: ["$$taskId", "$_id"] } } },
                  { $project: { bonus: 1, _id: 1 } }],
                  as: "task"
                }
              },
              { $unwind: { path: "$task", preserveNullAndEmptyArrays: true } },


              { $project: { _id: 1, taskBonus: "$task.bonus" } }
            ],
            as: "dayTasks"
          }
        },
        { $addFields: { taskCount: { $size: "$dayTasks" } } },
        { $addFields: { taskBonus: { $sum: "$dayTasks.taskBonus" } } },
        //{ $unset: "dayTasks" }, //mongo v4.2

        {
          $addFields: {
            points: { $add: ["$tabletPoints", "$taskBonus"] }
          }
        },
        {
          $addFields: {
            myTalkTotal: {
              $reduce: {
                input: "$myTalkTotal2",
                initialValue: [],
                in: {
                  $concatArrays: ["$$this", "$$value"]
                }
              }
            }
          }
        },
        //{ $unset: "myTalkTotal2" } //mongo v4.2

        {
          $addFields: {
            mySelfStates2: {
              $reduce: {
                input: "$mySelfStates",
                initialValue: [],
                in: {
                  $concatArrays: { $concatArrays: { $concatArrays: ["$$value", "$$this"] } }
                }
              }
            }
          }
        },

        {
          $addFields: {
            myCommunications: {
              $reduce: {
                input: "$myCommunications",
                initialValue: [],
                in: {
                  $concatArrays: { $concatArrays: { $concatArrays: ["$$value", "$$this"] } }
                }
              }
            }
          }
        },
        {
          $addFields: {
            myRoles: {
              $reduce: {
                input: "$myRoles",
                initialValue: [],
                in: {
                  $concatArrays: ["$$value", "$$this"]
                }
              }
            }
          }
        },

        {
          $addFields: {
            mirrors: {
              $reduce: {
                input: "$mirrors2",
                initialValue: [],
                in: {
                  $concatArrays: { $concatArrays: ["$$value", "$$this"] }
                }
              }
            }
          }
        },

      ])).toArray()
      //console.log('a', a)


      for (let totalTablet of a) {
        const types = {}
        const mySelfStates = {}//selfStateTmp//.clone()
        for (let tablet of totalTablet.mySelfStates2) {
          if (types[tablet.type]) types[tablet.type]++
          else types[tablet.type] = 1
          if (mySelfStates[tablet.type]) {
            if (mySelfStates[tablet.type][tablet.name])
              mySelfStates[tablet.type][tablet.name]++
            else
              mySelfStates[tablet.type][tablet.name] = 1
          } else {
            mySelfStates[tablet.type] = { [tablet.name]: 1 }
          }
        }
        for (let type in mySelfStates) {
          for (let name in mySelfStates[type]) {
            mySelfStates[type][name] = mySelfStates[type][name] * 100 / types[type]
          }
        }
        totalTablet.mySelfStates = mySelfStates
        delete totalTablet.mySelfStates2
        //выборка 1 изображения за день
        let firstImage
        for (let image of totalTablet.images) {
          if (image?.created && (!firstImage || new Date(image.created) < new Date(firstImage.created)))
            firstImage = image
        }
        delete totalTablet.images
        totalTablet.imageId = firstImage?._id
      }
      //console.log('a', a)
      const promises = [];
      for (let tabletObj of a) {
        delete tabletObj.image
        delete tabletObj.dayTasks
        delete tabletObj.myTalkTotal2
        const psychosomaticsArr = tabletObj.psychosomaticsArr
        delete tabletObj.psychosomaticsArr
        // const myResource = tablet.myResource
        // delete tablet.myResource
        const joy = tabletObj.joy
        delete tabletObj.joy
        delete tabletObj.mirrors2
        const myCommunications = tabletObj.myCommunications
        delete tabletObj.myCommunications
        const myRoles = tabletObj.myRoles
        delete tabletObj.myRoles
        const tabletIds = tabletObj.tabletIds.reduce((prev, arr) => prev.concat(arr), [])
        delete tabletObj.tabletIds
        tabletObj.start = start2
        tabletObj.end = end2
        delete tabletObj._id
        delete tabletObj.id
        const tabletInst = (totalTabletId)
          ? await tablet.app.models.TotalTablet.upsertWithWhere({ id: totalTabletId }, tabletObj)
          : await tablet.app.models.TotalTablet.create(tabletObj)

        if (psychosomaticsArr && psychosomaticsArr.length > 0)
          promises.push(modelOperationsModule.hasAndBelongsToManyChangeR("TotalTablet", "psychosomatics", tabletInst.id, psychosomaticsArr))
        // for (let psychosomaticId of psychosomaticsArr) {
        //   promises.push(tabletInst.psychosomatics.add(psychosomaticId))
        //   //modelOperationsModule.hasManyChange(tabletInst.id, "Psychosomatics", )
        // }

        if (joy && joy.length > 0)
          promises.push(modelOperationsModule.hasAndBelongsToManyChange("TotalTablet", "joys", tabletInst.id, joy))
        // for (let joyId of joy) {
        //   promises.push(tabletInst.joys.add(joyId))
        // }
        if (myCommunications && myCommunications.length > 0) {
          let myCommunicationsPercent = {}
          for (let myCommunicationId of myCommunications) {
            if (myCommunicationsPercent[myCommunicationId])
              myCommunicationsPercent[myCommunicationId]++
            else
              myCommunicationsPercent[myCommunicationId] = 1;
          }
          promises.push(
            tablet.app.models.TotalTabletCommunications.deleteAll({ totalTabletId: tabletInst.id })
          )
          for (let myCommunicationId in myCommunicationsPercent)
            promises.push(
              tablet.app.models.TotalTabletCommunications.create({
                percent: myCommunicationsPercent[myCommunicationId] * 100 / myCommunications.length,
                totalTabletId: tabletInst.id,
                myCommunicationId: myCommunicationId
              })
            )
        }
        if (myRoles && myRoles.length > 0) {
          let myRolesPercent = {}
          for (let myRoleId of myRoles) {
            if (myRolesPercent[myRoleId])
              myRolesPercent[myRoleId]++
            else
              myRolesPercent[myRoleId] = 1;
          }
          promises.push(
            tablet.app.models.TotalTabletRole.deleteAll({ totalTabletId: tabletInst.id })
          )
          for (let myRoleId in myRolesPercent) {
            promises.push(
              tablet.app.models.TotalTabletRole.create({
                percent: myRolesPercent[myRoleId] * 100 / myRoles.length,
                totalTabletId: tabletInst.id,
                myRoleTabletId: myRoleId
              })
            )
          }
        }
        promises.push(
          tablet.updateAll({ id: { inq: tabletIds } }, { totalTabletId: tabletInst.id })
        )
      }
      await Promise.all(promises)
    } catch (e) {
      throw e
    }
  }

  /*only for query
  tablet.remoteMethod('createTotalTablet',
    {
      description: 'edit tablet',
      accepts: [
        { arg: 'startDate', type: 'string', required: true },
        { arg: 'endDate', type: 'string', required: true },
        { arg: 'start2', type: 'string', required: true },
        { arg: 'end2', type: 'string', required: true },
        { arg: 'userId', type: 'string', required: false },
      ],
      returns: {
        arg: 'edited tablet',
        type: 'object',
        root: true
      },
    }
  );*/


  /**
   * Метод для массового изменения списка связи коммуникаций для скрижали
   * @param {*} id 
   * @param {*} myCommunicationIds 
   * @param {*} options 
   * @param {*} cb 
   */
  tablet.changeMyCommunication = function (id, myCommunicationIds, options, cb) {
    tablet.findById(id, { include: "myCommunications" }, function (err, tabletInst) {
      if (err) throw err
      if (!tabletInst) {
        var err = new Error("not_found");
        err.statusCode = 404;
        cb(err)
      } else {
        const oldMyCommunications = JSON.parse(JSON.stringify(tabletInst)).myCommunications

        const promises = []
        const oldMyCommunicationsIds = oldMyCommunications.map(item => item.id)
        oldMyCommunications.forEach(item => {
          if (!myCommunicationIds.includes(item.id)) {
            promises.push(
              tabletInst.myCommunications.remove(item.id)
            )
          }
        })
        myCommunicationIds.forEach(itemId => {
          if (!oldMyCommunicationsIds.includes(itemId))
            promises.push(
              tabletInst.myCommunications.add(itemId)
            )
        })
        Promise.all(promises).then(res => {
          if (tabletInst?.totalTabletId) 
            tablet.createTotalTablet(
              null,
              null,
              tabletInst.start || new moment(tabletInst.created).subtract(1, 'day'),
              tabletInst.end || tabletInst.created,
              tabletInst.totalTabletId
            ).then((res2) => {
              cb(null, res)
            }, err => { cb(err) })
          else
            cb(null, res)
        }, err => { throw err; })
      }
    })
  }

  tablet.remoteMethod('changeMyCommunication',
    {
      description: 'Change myCommunications of tablet',
      accepts: [
        { arg: 'id', type: 'string', required: true },
        { arg: 'myCommunicationIds', type: 'array', required: true },
        {
          arg: "options",
          type: "object",
          http: "optionsFromRequest"
        }
      ],
      returns: {
        arg: 'obj',
        type: 'object',
        root: true
      },
      http: { path: '/:id/changeMyCommunication', verb: 'post' }
    }
  );


  tablet.changeMySelfStates = function (id, mySelfStatesIds, options, cb) {
    tablet.findById(id, function (err, tabletInst) {
      if (err) throw err
      modelOperationsModule.hasAndBelongsToManyChange('tablet', 'mySelfStates', id, mySelfStatesIds).then((res) => {
        if (tabletInst?.totalTabletId) 
          tablet.createTotalTablet(
            null,
            null,
            tabletInst.start || new moment(tabletInst.created).subtract(1, 'day'),
            tabletInst.end || tabletInst.created,
            tabletInst.totalTabletId
          ).then((res2) => {
            cb(null, res)
          }, err => { cb(err) })
        else
          cb(null, res)
      }, err => { throw err })
    })
  }

  tablet.remoteMethod('changeMySelfStates',
    {
      description: 'Change mySelfStates of tablet',
      accepts: [
        { arg: 'id', type: 'string', required: true },
        { arg: 'mySelfStatesIds', type: 'array', required: true },
        {
          arg: "options",
          type: "object",
          http: "optionsFromRequest"
        }
      ],
      returns: {
        arg: 'obj',
        type: 'object',
        root: true
      },
      http: { path: '/:id/changeMySelfStates', verb: 'post' }
    }
  );


  tablet.changeJoys = function (id, joyIds, options, cb) {
    tablet.findById(id, function (err, tabletInst) {
      if (err) throw err
      modelOperationsModule.hasAndBelongsToManyChange('tablet', 'joys', id, joyIds).then((res) => {
        if (tabletInst?.totalTabletId) 
          tablet.createTotalTablet(
            null,
            null,
            tabletInst.start || new moment(tabletInst.created).subtract(1, 'day'),
            tabletInst.end || tabletInst.created,
            tabletInst.totalTabletId
          ).then((res2) => {
            cb(null, res)
          }, err => { cb(err) })
        else
          cb(null, res)
      }, err => { throw err })
    })
  }

  tablet.remoteMethod('changeJoys',
    {
      description: 'Change joys of tablet',
      accepts: [
        { arg: 'id', type: 'string', required: true },
        { arg: 'joyIds', type: 'array', required: true },
        {
          arg: "options",
          type: "object",
          http: "optionsFromRequest"
        }
      ],
      returns: {
        arg: 'obj',
        type: 'object',
        root: true
      },
      http: { path: '/:id/changeJoys', verb: 'post' }
    }
  );

  

  tablet.changePsychosomatics = function (id, psychosomaticsComments, options, cb) {
    tablet.findById(id, function (err, tabletInst) {
      if (err) throw err
      tabletInst.psychosomaticComments.destroyAll(function(err, res) {
        if (err) throw err
        tablet.app.models.Psychosomaticstablet.create(psychosomaticsComments, function(err, res){
          if (err) throw err
          if (tabletInst?.totalTabletId) 
            tablet.createTotalTablet(
              null,
              null,
              tabletInst.start || new moment(tabletInst.created).subtract(1, 'day'),
              tabletInst.end || tabletInst.created,
              tabletInst.totalTabletId
            ).then((res2) => {
              cb(null, res)
            }, err => { cb(err) })
          else
            cb(null, res)
        })
      })
    })
  }

  tablet.remoteMethod('changePsychosomatics',
    {
      description: 'Change psychosomatics of tablet',
      accepts: [
        { arg: 'id', type: 'string', required: true },
        { arg: 'psychosomaticsComments', type: 'array', required: true },
        {
          arg: "options",
          type: "object",
          http: "optionsFromRequest"
        }
      ],
      returns: {
        arg: 'obj',
        type: 'object',
        root: true
      },
      http: { path: '/:id/changePsychosomatics', verb: 'post' }
    }
  );
};
