'use strict';

var md5 = require('md5');
var fs = require('fs');
const ffmpeg = require('fluent-ffmpeg');
var ffprobe = require('ffprobe-static');
const ffmpegPath = require('@ffmpeg-installer/ffmpeg').path;
ffmpeg.setFfmpegPath(ffmpegPath);
ffmpeg.setFfprobePath(ffprobe.path);

module.exports = function (Audio) {

    Audio.delete = function (filePath, fileId, cb) {
        fs.unlink(filePath, fileId, function (err) {
            if (err)
                cb(err);
            else {
                Audio.deleteById(fileId, function (err) {
                    if (err)
                        cd(err);
                    else {
                        console.log(`file was deleted: `, fileId);
                        cb(null, 'deleted')
                    };
                })
            }
        });
    };


    Audio.remoteMethod('delete',
        {
            description: 'Deletes a file.',
            accepts: [
                {
                    arg: 'filePath',
                    type: 'string',
                    required: true
                },
                {
                    arg: 'fileId',
                    type: 'string',
                    required: true
                }
            ],
            returns: {
                arg: 'fileObject',
                type: 'object',
                root: true
            },
            http: {
                //path: '/files/:file',
                verb: 'delete'
            }
        }
    );

    Audio.observe('before save', function (ctx, next) {
        console.log(`ctx.data`, ctx.data);
        if (ctx.isNewInstance) {
            var model = ctx.instance || ctx.data;
            var str = md5(model.containerType + model.containerId + model.name);
            console.log(`str`, str);
            var parts = [];
            parts.push(str.slice(0, 8));
            parts.push(str.slice(8, 12));
            parts.push(str.slice(12, 16));
            parts.push(str.slice(16, 20));
            parts.push(str.slice(20, 32));

            model._id = parts.join('-');
        }
        next();
    });

    var loopback = require('loopback');
    var app = module.exports = loopback();
    var multer = require('multer');
    app.use(multer().any());

    Audio.upload = async function (type, modelId, description, manyModel, manyFK, req, cb) {//загрузка со сжатием на сервере

        let mainDir = __dirname;
        mainDir = mainDir.substr(0, mainDir.lastIndexOf('common'));

        const filename = md5(modelId);
        let path = mainDir + 'static/storage/users';
        let fullPath = '/static/storage/users/' + filename
        let searchquery = {};
        description = (description == '{}') ? '' : description;
        let originalname = req.files[0].originalname.replace(/[/\\?%*:|"<>]/g, '-');
        let insertquery = {
            description,
        };
        if (type == "tablet") {
            path = mainDir + 'static/storage/tablets/' + modelId;
            fullPath = '/static/storage/tablets/' + modelId + '/' + originalname;
            searchquery.path = fullPath;
            searchquery.tabletId = modelId;
            insertquery.path = fullPath;
            insertquery.tabletId = modelId;
            fs.existsSync(path) || fs.mkdirSync(path)
        } else {
            path = mainDir + 'static/storage/' + type + '/' + modelId;
            fullPath = '/static/storage/' + type + '/' + modelId + '/' + originalname;
            searchquery.path = fullPath;
            searchquery[type + 'Id'] = modelId;
            insertquery.path = fullPath;
            insertquery[type + 'Id'] = modelId;
            fs.existsSync(path) || fs.mkdirSync(path)
        }

        let audioObj
        try {
            await fs.writeFileSync(path + '/' + originalname, req.files[0].buffer)
            const audioMeta = await getMediaMeta(path + '/' + originalname)
            // for (let key in audioMeta) {
            //     console.log('key', key, audioMeta[key])
            // }

            insertquery.duration = audioMeta.format.duration
            audioObj = await Audio.upsertWithWhere(searchquery, insertquery)
            if (manyModel) {//связь 1-м
                await Audio.app.models[manyModel].upsertWithWhere({ id: modelId }, { [manyFK]: audioObj.id })
            }
        } catch (err) {
            throw err
        }
        return audioObj
    };

    function getMediaMeta(path) {
        return new Promise((resolve, reject) => {
            ffmpeg.ffprobe(path, function(err, metadata) {
                if (err) reject(err);                    
                else resolve(metadata)
            })
        })
    }

    Audio.remoteMethod('upload',
        {
            description: 'Uploads files.',
            accepts: [
                {
                    arg: 'type',
                    type: 'string',
                    required: true
                },
                {
                    arg: 'modelId',
                    type: 'string',
                    required: true
                },
                {
                    arg: 'description',
                    type: 'string'
                },
                {
                    arg: 'manyModel',
                    type: 'string',
                    required: false,
                    description: "название модели если связь м-1"
                },
                {
                    arg: 'manyFK',
                    type: 'string',
                    required: false,
                    description: "название внешнего ключа если связь м-1"
                },
                {
                    arg: 'req',
                    type: 'object',
                    'http': {
                        source: 'req'
                    }
                },
            ],
            returns: {
                arg: 'audioModelObject',
                type: 'object',
                root: true
            },
            http: {
                verb: 'post'
            }
        }
    );
}