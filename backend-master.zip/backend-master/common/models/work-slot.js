'use strict';
var moment = require('moment');
var momentTz = require('moment-timezone');
const basic = require("../../helpers/basic.js")

module.exports = function(Workslot) {
    //Workslot.observe('before save', function (ctx, next) {
    //Workslot.beforeRemote('**', function (ctx, slot, next) {
        // console.log(`ctx.data`, ctx.instance);//+

    //     console.log(`ctx.body`, ctx.req.body);//+
    //     console.log(`ctx.args`, ctx.args);//+
    //     next()
    // })
    Workslot.changeMonthSchedule = async function (year, month, slots, options, cb) {
        try {

            const existed = await Workslot.find({where:{//workslotfind
                year,
                month,
                masterId: options.accessToken.userId,
                userConsultationId: {nin: [undefined, null, ""]}
            }})

            //existed.forEach(existedSlot => {
                for(let existedSlot of existed) {
                if (!slots.some(slot => (
                    slot.day == existedSlot.day 
                    && (slot.startHour < existedSlot.startHour 
                    || (slot.startHour == existedSlot.startHour && slot.startMinute <= existedSlot.startMinute ))
                    && (slot.endHour > existedSlot.endHour ||
                        (slot.endHour == existedSlot.endHour && slot.endMinute >= existedSlot.endMinute ))
                    ))) {
                        let err = new Error("Error: consultation exists")
                        err.statusCode = 409
                        throw err
                    }
            };
            await Workslot.deleteAll({//workslotdelete
                year,
                month,
                masterId: options.accessToken.userId,
                userConsultationId: {inq: [undefined, null, ""]}
            })
            const promises = []
            slots.forEach(slot => {
                let bool = false
                for (let i = 0; i < existed.length; i++) {
                    if (
                        slot.day == existed[i].day 
                        && (slot.startHour < existed[i].startHour 
                        || (slot.startHour == existed[i].startHour && slot.startMinute <= existed[i].startMinute ))
                        && (slot.endHour > existed[i].endHour ||
                            (slot.endHour == existed[i].endHour && slot.endMinute >= existed[i].endMinute ))
                        ) {
                            promises.push(existed[i].updateAttributes({//workslotupdate
                                startHour: slot.startHour,
                                startMinute: slot.startMinute,
                                endHour: slot.endHour,
                                endMinute: slot.endMinute,
                                startDate: slot.startDate,
                                endDate: slot.endDate,
                            }))
                            bool = true;
                            existed.splice(i, 1);
                            break;
                        }
                }
                // if (existed.filter(existedSlot => (
                //     slot.day == existedSlot.day 
                //     && (slot.startHour < existedSlot.startHour 
                //     || (slot.startHour == existedSlot.startHour && slot.startMinute <= existedSlot.startMinute ))
                //     && (slot.endHour > existedSlot.endHour ||
                //         (slot.endHour == existedSlot.endHour && slot.endMinute >= existedSlot.endMinute ))
                //     ))){

                    if (!bool) {
                        promises.push(Workslot.create(slot))
                    }
            });
            const a = await Promise.all(promises)
            return "ok"
        } catch (err) {
            throw err
        }
    };


    Workslot.remoteMethod('changeMonthSchedule',
        {
            description: 'Change month schedule',
            accepts: [
                {
                    arg: 'year',
                    type: 'number',
                    required: true
                },
                {
                    arg: 'month',
                    type: 'number',
                    required: true
                },
                {
                    arg: 'slots',
                    type: 'array',
                    required: true
                },
                {
                    arg: "options",
                    type: "object",
                    http: "optionsFromRequest"
                },
                //{ arg: 'res', type: 'object', http: { source: 'res' }}
            ],
            returns: {
                arg: 'fileObject',
                type: 'object',
                root: true
            },
            http: {
                //path: '/files/:file',
                verb: 'post'
            }
        }
    );
    
    /**
     * создание консультации пользователя, добавленного в расписание мастера
     * @param {*} id 
     * @param {*} userId 
     * @param {*} consultationId 
     * @param {*} cb 
     */
    Workslot.UserConsultation = function (id, userId,consultationId, cb) {
        Workslot.findById(id, {include: "userConsultation"}, function (err, slot) { //workslotfind
            if (err) throw err
            if (!slot) {
                var err = new Error("not_found");
                err.statusCode = 404;
                cb(err)
            } else {
                const slotObj = JSON.parse(JSON.stringify(slot))
                if (slotObj.userConsultation?.id) {
                    const err = new Error("Error: consultation exists")
                    err.statusCode = 409
                    cb(err)
                } else {
                    const duration = new Date(slot.endDate).getTime() - (new Date(slot.startDate)).getTime()
                    Workslot.app.models.UserConsultation.create({//userconsultationcreate
                        userId: userId, 
                        consultationId, 
                        duration, 
                        startDate: slot.startDate, 
                        endDate: slot.endDate,
                    }, function(err, userConsultation) {
                        if (err) {
                            cb(err)
                            //still go
                        }
                        else{
                        slot.updateAttribute("userConsultationId", userConsultation.id, function(err, res) {//workslotupdate
                            if (err) throw err
                            cb(null, userConsultation)
                        })}
                    })
                }
            }
        })
    }

    Workslot.remoteMethod('UserConsultation',
        {
            description: 'Create user consultation, related with work slot',
            accepts: [
                {arg: 'id', type: 'string', required: true},
                {arg: 'userId', type: 'string', required: true},
                {arg: 'consultationId', type: 'string', required: true},
            ],
            returns: {
                arg: 'new user consultation',
                type: 'object',
                root: true
            },
            http: {path: '/:id/UserConsultation', verb: 'post'}
        }
    );

    Workslot.createUserConsultation = function (id, userId, consultationId, cb) {
        Workslot.find({ where: { id: { inq: id }, userConsultationId: { inq: [undefined, null, ""] } } }, { include: "userConsultation" }, function (err, slots) {//workslotfind
            if (err) throw err
            if (!slots || slots.length == 0) {
                var err = new Error("free_slots_not_found");
                err.statusCode = 404;
                cb(err)
            } else {
                if (id.length != slots.length) {
                    const err = new Error("Error: consultation exists")
                    err.statusCode = 409
                    cb(err)
                } else {
                    let duration = 0;
                    let startDate = new Date(slots[0].startDate)
                    slots.forEach((slot) => {
                        duration += new Date(slot.endDate).getTime() - (new Date(slot.startDate)).getTime()
                        if (startDate.getTime() > new Date(slot.startDate).getTime()) startDate = new Date(slot.startDate)
                    })                    
                    Workslot.app.models.UserConsultation.create({ //userconsultationcreate
                        userId: userId, 
                        consultationId, 
                        duration, 
                        startDate,
                        endDate: moment(startDate).add(duration, 'millisecond')
                    }, function (err, userConsultation) {
                        if (err) throw err
                        Workslot.updateAll({ id: { inq: id } }, { userConsultationId: userConsultation.id }, function (err, res) {//workslotupdate
                            if (err) throw err
                            cb(null, userConsultation)
                        })
                    })
                }
            }
        })
    }

    Workslot.remoteMethod('createUserConsultation',
        {
            description: 'Create user consultation, related with work slots',
            accepts: [
                { arg: 'id', type: 'array', required: true },
                { arg: 'userId', type: 'string', required: true },
                { arg: 'consultationId', type: 'string', required: true },
                //{ arg: 'res', type: 'object', http: { source: 'res' }}
            ],
            returns: {
                arg: 'new user consultation',
                type: 'object',
                root: true
            },
            http: { path: '/createUserConsultation', verb: 'post' }
        }
    );


    Workslot.markDay = async function (year, month, day, timezone = "Europe/Moscow", options, res, cb) {
        try {
            const date = new moment.utc([year, month - 1, day])
            const start = date.clone().startOf('day')
            const end = start.clone().add(1, 'day')

            const startLocal = basic.getTZdate(start, timezone)
            const endLocal = basic.getTZdate(end, timezone)

            const exists = await Workslot.find({//workslotfind
                where: {
                    //year, month, day,
                    //startDate: {between: [startLocal, endLocal]}, endDate: {between: [startLocal, endLocal]},
                    startDate: {lt: endLocal}, endDate: {gt: startLocal},
                    masterId: options.accessToken.userId
                }, limit: 1
            })

            let result = []
            let err
            if (exists?.length > 0) {//если слоты, нужно все убрать - даже если слот затрагивает день частично
                await Workslot.deleteAll({//workslotdelete
                    //year, month, day,
                    startDate: {lt: endLocal}, endDate: {gt: startLocal},
                    masterId: options.accessToken.userId,
                    userConsultationId: { inq: [undefined, null, ""] }
                })
                result = await Workslot.find({//workslotfind
                    where: {
                        //year, month, day,
                        startDate: {lt: endLocal}, endDate: {gt: startLocal},
                        masterId: options.accessToken.userId
                    }
                })
                if (result?.length > 0) {
                    // err = new Error("consultation exists")
                    // err.statusCode = 409
                    res.status(409)
                }
            } else {//нет слотов 
                let dayTmp = await Workslot.app.models.ScheduleDay.findOne({ where: { masterId: options.accessToken.userId } })
                dayTmp = JSON.parse(JSON.stringify(dayTmp))
                if (dayTmp?.hours?.length > 0) {
                    const currDate = new moment.utc()
                    const timezoneOffset = currDate.valueOf() - new moment.utc(momentTz.tz(currDate, timezone)
                        .format('YYYY-MM-DDTHH:mm:ss:SSS'), "YYYY-MM-DDTHH:mm:ss:SSS").valueOf();

                    const promises = []
                    dayTmp.hours.forEach(slot => {
                        let startTimeLocal = new moment.utc([year, month-1, day, slot.startHour, slot.startMinute])
                        let endTimeLocal = new moment.utc(`${year}-${month}-${day}T${slot.endHour}:${slot.endMinute}:00.000Z`,
                            'YYYY-MM-DDTHH:mm:ss:SS')

                        promises.push(
                            Workslot.create({//workslotcreate
                                startHour: slot.startHour,
                                startMinute: slot.startMinute,
                                endHour: slot.endHour,
                                endMinute: slot.endMinute,
                                startDate: new moment(moment(startTimeLocal).valueOf() + timezoneOffset),
                                endDate: new moment(moment(endTimeLocal).valueOf() + timezoneOffset),
                                masterId: options.accessToken.userId, year, month, day
                            })
                        )
                    })
                    result = await Promise.all(promises)
                } else {
                    err = new Error("day template not found")
                    err.statusCode = 404
                }
            }

            if (err) throw err
            else return result
        } catch (err) {
            throw err
        }
    };


    Workslot.remoteMethod('markDay',
        {
            description: 'Смена выделения дня - очистка/заполнение дня типовым днём',
            accepts: [
                {
                    arg: 'year',
                    type: 'number',
                    required: true
                },
                {
                    arg: 'month',
                    type: 'number',
                    required: true
                },
                {
                    arg: 'day',
                    type: 'number',
                    required: true
                },
                {
                    arg: 'timezone',
                    type: 'string',
                    required: false
                },
                {
                    arg: "options",
                    type: "object",
                    http: "optionsFromRequest"
                },
                { arg: 'res', type: 'object', http: { source: 'res' }}
            ],
            returns: {
                arg: 'workslots',
                type: 'array',
                root: true
            },
            http: {
                verb: 'post'
            }
        }
    );


    Workslot.markDays = async function (days, timezone = "Europe/Moscow", options, res, cb) {
        try {
            const promises = []
            days.forEach(day => {
                promises.push(Workslot.markDay(day.year, day.month, day.day, timezone, options, res))
            })
            const result = await Promise.all(promises)
            return result
        } catch (err) {
            throw err
        }
    };


    Workslot.remoteMethod('markDays',
        {
            description: 'Смена выделения дней - очистка/заполнение дней типовым днём',
            accepts: [
                {
                    arg: 'days',
                    type: 'array',
                    required: true
                },
                {
                    arg: 'timezone',
                    type: 'string',
                    required: false
                },
                {
                    arg: "options",
                    type: "object",
                    http: "optionsFromRequest"
                },
                { arg: 'res', type: 'object', http: { source: 'res' }}//res.status(409)
            ],
            returns: {
                arg: 'workslots',
                type: 'array',
                root: true
            },
            http: {
                verb: 'post'
            }
        }
    );

    

    Workslot.changeSlotActivity = async function (year, month, day, startHour, startMinute, endHour, endMinute, timezone = "Europe/Moscow", options, cb) {
        try {
            const start = new moment.utc([year, month - 1, day, startHour, startMinute])
            const end = new moment.utc([year, month - 1, day, endHour, endMinute])

            const startLocal = basic.getTZdate(start, timezone)
            const endLocal = basic.getTZdate(end, timezone)

            const exists = await Workslot.findOne({//workslotfind
                where: {
                    // year, month, day,
                    // startHour, startMinute, endHour, endMinute,
                    startDate: startLocal, endDate: endLocal,
                    masterId: options.accessToken.userId
                }
            })

            let result
            let err
            if (exists) {//если есть, то нужно удалить
                if (exists.userConsultationId) {
                    err = new Error("consultation exists")
                    err.statusCode = 409
                } else {
                    await exists.destroy()//workslotdelete
                    result = {}
                }
            } else {//нет слота
                //const currDate = new moment.utc()//Date();
                // const timezoneOffset = currDate.valueOf() - new moment.utc(momentTz.tz(currDate, timezone)
                //     .format('YYYY-MM-DDTHH:mm:ss:SSS'), "YYYY-MM-DDTHH:mm:ss:SSS").valueOf();

                // let startTimeLocal = new moment.utc([year, month-1, day, startHour, startMinute])
                // let endTimeLocal = new moment.utc(`${year}-${month}-${day}T${endHour}:${endMinute}:00.000Z`,
                //     'YYYY-MM-DDTHH:mm:ss:SS')

                result = await Workslot.create({//workslotcreate
                    year, month, day,
                    startHour, startMinute, endHour, endMinute,
                    startDate: startLocal,//new moment(moment(startTimeLocal).valueOf() + timezoneOffset),
                    endDate: endLocal,//new moment(moment(endTimeLocal).valueOf() + timezoneOffset),
                    masterId: options.accessToken.userId
                })
            }

            if (err) throw err
            else return result
        } catch (err) {
            throw err
        }
    };

    Workslot.remoteMethod('changeSlotActivity',
        {
            description: 'Смена Активности слота дня',
            accepts: [
                {
                    arg: 'year',
                    type: 'number',
                    required: true
                },
                {
                    arg: 'month',
                    type: 'number',
                    required: true
                },
                {
                    arg: 'day',
                    type: 'number',
                    required: true
                },
                {
                    arg: 'startHour',
                    type: 'number',
                    required: true
                },
                {
                    arg: 'startMinute',
                    type: 'number',
                    required: true
                },
                {
                    arg: 'endHour',
                    type: 'number',
                    required: true
                },
                {
                    arg: 'endMinute',
                    type: 'number',
                    required: true
                },
                {
                    arg: 'timezone',
                    type: 'string',
                    required: false
                },
                {
                    arg: "options",
                    type: "object",
                    http: "optionsFromRequest"
                },
                //{ arg: 'res', type: 'object', http: { source: 'res' }}
            ],
            returns: {
                arg: 'slot',
                type: 'object',
                root: true
            },
            http: {
                verb: 'post'
            }
        }
    );

        /**
         * 
         * @param {number} year - required
         * @param {number} month - required
         * @param {number} day - required
         * @param {string} timezone - in format "Europe/Moscow"
         * @param {*} options 
         * @param {*} res 
         * @param {*} cb 
         * @returns 
         */
    Workslot.applyTemplateToDay = async function (year, month, day, timezone = "Europe/Moscow", options, res, cb) {
        try {
            const start = new moment.utc([year, month - 1, day])
            const end = start.clone().add(1, 'day')

            const startLocal = basic.getTZdate(start, timezone)
            const endLocal = basic.getTZdate(end, timezone)

            const exists = await Workslot.find({//workslotfind
                where: {
                    //year, month, day,
                    startDate: {lt: endLocal}, endDate: {gt: startLocal},
                    masterId: options.accessToken.userId
                }
            })
            let dayTmp = await Workslot.app.models.ScheduleDay.findOne({ where: { masterId: options.accessToken.userId } })
            dayTmp = JSON.parse(JSON.stringify(dayTmp))

            let response = []
            let err
            //убрать все слоты не входящие в шаблон, добавить все нехватающие по шаблону
            if (dayTmp?.hours?.length > 0) {//если слоты, нужно все убрать
                let promises = []
                for (let i = 0; i < exists?.length; i++) {
                    const startH = new moment.utc(momentTz.tz(exists[i].startDate, timezone).format('YYYY-MM-DDTHH:mm:ss:SSS'), "YYYY-MM-DDTHH:mm:ss:SSS")
                    const endH = new moment.utc(momentTz.tz(exists[i].endDate, timezone).format('YYYY-MM-DDTHH:mm:ss:SSS'), "YYYY-MM-DDTHH:mm:ss:SSS")

                    const exist = dayTmp.hours.some(hour => (
                        startH.hours() == hour.startHour 
                        && startH.minutes() == hour.startMinute
                        && endH.hours() == hour.endHour 
                        && endH.minutes() == hour.endMinute))

                    if (!exist) {//удаление не подходящих
                        if (exists[i].userConsultationId) {
                            // err = new Error("consultation exists")
                            // err.statusCode = 409
                            res.status(409)//return inserted slots but with conflict status code
                        } else {
                            promises.push(exists[i].destroy())//workslotdelete
                        }
                    }
                }
                await Promise.all(promises)

                const currDate = new moment.utc()//Date();
                const timezoneOffset = currDate.valueOf() - new moment.utc(momentTz.tz(currDate, timezone)
                    .format('YYYY-MM-DDTHH:mm:ss:SSS'), "YYYY-MM-DDTHH:mm:ss:SSS").valueOf();
                promises = []
                dayTmp.hours.forEach(slot => {
                    let startTimeLocal = new moment.utc([year, month-1, day, slot.startHour, slot.startMinute])
                    let endTimeLocal = new moment.utc(`${year}-${month}-${day}T${slot.endHour}:${slot.endMinute}:00.000Z`,
                        'YYYY-MM-DDTHH:mm:ss:SS')

                    promises.push(
                        Workslot.upsertWithWhere({//workslotcreate //workslotupdate
                            // startHour: slot.startHour,
                            // startMinute: slot.startMinute,
                            // endHour: slot.endHour,
                            // endMinute: slot.endMinute,
                            startDate: new moment(moment(startTimeLocal).valueOf() + timezoneOffset),
                            endDate: new moment(moment(endTimeLocal).valueOf() + timezoneOffset),
                            masterId: options.accessToken.userId, year, month, day
                        }, {
                            startHour: slot.startHour,
                            startMinute: slot.startMinute,
                            endHour: slot.endHour,
                            endMinute: slot.endMinute,
                            startDate: new moment(moment(startTimeLocal).valueOf() + timezoneOffset),
                            endDate: new moment(moment(endTimeLocal).valueOf() + timezoneOffset),
                            masterId: options.accessToken.userId, year, month, day
                        })
                    )
                })
                //response = 
                await Promise.all(promises)
                response = await Workslot.find({
                    where: {
                        startDate: {lt: endLocal}, endDate: {gt: startLocal},
                        masterId: options.accessToken.userId
                    }
                })
            } else {
                err = new Error("day template not found")
                err.statusCode = 404
            }

            if (err) throw err
            else return response
        } catch (err) {
            throw err
        }
    };


    Workslot.remoteMethod('applyTemplateToDay',
        {
            description: 'Применить типовой день',
            accepts: [
                {
                    arg: 'year',
                    type: 'number',
                    required: true
                },
                {
                    arg: 'month',
                    type: 'number',
                    required: true
                },
                {
                    arg: 'day',
                    type: 'number',
                    required: true
                },
                {
                    arg: 'timezone',
                    type: 'string',
                    required: false
                },
                {
                    arg: "options",
                    type: "object",
                    http: "optionsFromRequest"
                },
                { arg: 'res', type: 'object', http: { source: 'res' }}
            ],
            returns: {
                arg: 'workslots',
                type: 'array',
                root: true
            },
            http: {
                verb: 'post'
            }
        }
    );
    

    Workslot.applyTemplateToDays = async function (days, timezone = "Europe/Moscow", options, res, cb) {
        try {
            const promises = []
            days.forEach(day => {
                promises.push(Workslot.applyTemplateToDay(day.year, day.month, day.day, timezone, options, res))
            })
            const result = await Promise.all(promises)//even if some failed
            return result
        } catch (err) {
            throw err
        }
    };


    Workslot.remoteMethod('applyTemplateToDays',
        {
            description: 'Сделать все активные дни типовыми',
            accepts: [
                {
                    arg: 'days',
                    type: 'array',
                    required: true
                },
                {
                    arg: 'timezone',
                    type: 'string',
                    required: false
                },
                {
                    arg: "options",
                    type: "object",
                    http: "optionsFromRequest"
                },
                { arg: 'res', type: 'object', http: { source: 'res' }}
            ],
            returns: {
                arg: 'workslots',
                type: 'array',
                root: true
            },
            http: {
                verb: 'post'
            }
        }
    );


    Workslot.clearDay = async function (year, month, day, timezone = "Europe/Moscow", options, res, cb) {
        try {
            const currDate = new moment.utc([year, month - 1, day])

            const start = currDate.startOf('day')
            const end = start.clone().add(1, 'day')

            const startLocal = basic.getTZdate(start, timezone)
            const endLocal = basic.getTZdate(end, timezone)

            await Workslot.deleteAll({//workslotdelete
                // year, month, day,
                startDate: { gte: startLocal }, endDate: { lte: endLocal },
                masterId: options.accessToken.userId,
                userConsultationId: {inq: [null, undefined, ""]}
            })
            const exists = await Workslot.find({//workslotfind
                where: {
                    // year, month, day,
                    startDate: { gte: startLocal }, endDate: { lte: endLocal },
                    masterId: options.accessToken.userId
                }
            })            
            if (exists?.length > 0) {
                res.status(409)
            }

            return exists
        } catch (err) {
            throw err
        }
    };


    Workslot.remoteMethod('clearDay',
        {
            description: 'Очистить день',
            accepts: [
                {
                    arg: 'year',
                    type: 'number',
                    required: true
                },
                {
                    arg: 'month',
                    type: 'number',
                    required: true
                },
                {
                    arg: 'day',
                    type: 'number',
                    required: true
                },
                {
                    arg: 'timezone',
                    type: 'string',
                    required: false
                },
                {
                    arg: "options",
                    type: "object",
                    http: "optionsFromRequest"
                },
                { arg: 'res', type: 'object', http: { source: 'res' }}
            ],
            returns: {
                arg: 'workslots',
                type: 'array',
                root: true
            },
            http: {
                verb: 'post'
            }
        }
    );


    Workslot.getMonth = async function (year, month, timezone = "Europe/Moscow", options, cb) {
        try {
            const currDate = new moment.utc([year, month - 1])

            const start = currDate.startOf('month')
            const end = currDate.clone().endOf('month')

            const startLocal = basic.getTZdate(start, timezone)
            const endLocal = basic.getTZdate(end, timezone)

            return Workslot.find({//workslotfind
                where: {
                    startDate: { lt: endLocal }, endDate: { gt: startLocal },
                    masterId: options.accessToken.userId
                }
            })
        } catch (err) {
            throw err
        }
    };


    Workslot.remoteMethod('getMonth',
        {
            description: 'Получить слоты на месяц по часовому поясу мастера',
            accepts: [
                {
                    arg: 'year',
                    type: 'number',
                    required: true
                },
                {
                    arg: 'month',
                    type: 'number',
                    required: true
                },
                {
                    arg: 'timezone',
                    type: 'string',
                    required: false
                },
                {
                    arg: "options",
                    type: "object",
                    http: "optionsFromRequest"
                }
            ],
            returns: {
                arg: 'workslots',
                type: 'array',
                root: true
            },
            http: {
                verb: 'get'
            }
        }
    );



    Workslot.getWeek = async function (startDate, options, cb) {
        try {
            const endDate = new moment(startDate).add(1, 'week')

            return Workslot.find({//workslotfind
                where: {
                    startDate: { lt: endDate }, 
                    endDate: { gt: startDate },
                    //masterId: options.accessToken.userId
                    userConsultationId: {inq: [null, undefined, ""]},
                }
            })
        } catch (err) {
            throw err
        }
    };


    Workslot.remoteMethod('getWeek',
        {
            description: 'Получить слоты на неделю для пользователя',
            accepts: [
                {
                    arg: 'startDate',
                    type: 'date',
                    required: true
                },
                {
                    arg: "options",
                    type: "object",
                    http: "optionsFromRequest"
                }
            ],
            returns: {
                arg: 'workslots',
                type: 'array',
                root: true
            },
            http: {
                verb: 'get'
            }
        }
    );
};
