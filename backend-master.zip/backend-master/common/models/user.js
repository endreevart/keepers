/* eslint comma-dangle: ["error", "never"] */
'use strict';
var moment = require('moment');
const emailModule = require("../../helpers/email.js")
const smsModule = require("../../helpers/sms.js")
const pushNotification = require('../../helpers/pushNotification');
var { Buffer } = require('buffer');
const path = require('path');
require('dotenv').config({path: path.resolve(__dirname, '../../.env')})
const sb_salt = process.env.sb_salt;
let istest = process.env.test;

module.exports = function (user) {

	user.loginFacebook = function (data, include, cb) {//проверка импорта из csv
		cb = cb || utils.createPromiseCallback();
		console.log('data', data);
		console.log('cb', cb);

		function tokenHandler(err, token) {
			if (err) return cb(err);
			if (Array.isArray(include) ? include.indexOf('user') !== -1 : include === 'user') {
				// NOTE(bajtos) We can't set token.user here:
				//  1. token.user already exists, it's a function injected by
				//     "AccessToken belongsTo User" relation
				//  2. ModelBaseClass.toJSON() ignores own properties, thus
				//     the value won't be included in the HTTP response
				// See also loopback#161 and loopback#162
				token.__data.user = user;
			}
			cb(err, token);
		}

		user.findOne({
			where: {
				email: data.email
			}
		}, function (err, user) {
			if (err) {
				console.log('findone err', err);
				return cb(err)
			}
			else {
				if (user) {
					console.log('user', user);
					/*let bcrypt = require('bcryptjs');
					bcrypt.compare(data.password, user.password, function (err, isMatch) {//проверка пароля
						if (err) { console.log('bcrypt err', err); return cb(err); }
						else if (isMatch) {
					console.log('pass isMatch', isMatch);*/
					if (user.createAccessToken.length === 2) {
						console.log('2')
						user.createAccessToken(data.ttl, tokenHandler);
					} else {
						console.log('3')
						user.createAccessToken(data.ttl, data, tokenHandler);
					}
					/*} else {
						console.log('password fail');
						var err = new Error("password_fail");
						err.statusCode = 401;
						cb(err)
					}
				});*/
				} else {//пользователь не найден
					console.log('user not found');
					//var err = new Error("user_not_found");
					//err.statusCode = 404;
					cb(null, { notFound: true })
				}
			}
		});
	};

	// user.remoteMethod(
	// 	'loginFacebook',
	// 	{
	// 		description: 'Login a user with just email.',
	// 		accepts: [
	// 			{ arg: 'credentials', type: 'object', required: true, http: { source: 'body' } },
	// 			{ arg: 'include', type: ['string'], http: { source: 'query' } }
	// 		],
	// 		returns: {
	// 			arg: 'accessToken', type: 'object', root: true
	// 		},
	// 		http: { verb: 'post' },
	// 	},
	// );

	user.loginPhone = function (data, include, cb) {
		cb = cb || utils.createPromiseCallback();
		console.log('data', data);
		console.log('cb', cb);

		function tokenHandler(err, token) {
			if (err) return cb(err);
			if (Array.isArray(include) ? include.indexOf('user') !== -1 : include === 'user') {
				// NOTE(bajtos) We can't set token.user here:
				//  1. token.user already exists, it's a function injected by
				//     "AccessToken belongsTo User" relation
				//  2. ModelBaseClass.toJSON() ignores own properties, thus
				//     the value won't be included in the HTTP response
				// See also loopback#161 and loopback#162
				token.__data.user = user;
			}
			cb(err, token);
		}

		user.findOne({
			where: {
				phone: data.phone
			}//, include: ["paidAccount"]
		}, function (err, user) {
			if (err) {
				console.log('findone err', err);
				return cb(err)
			}
			else {
				if (user) {
					// let userInst = JSON.parse(JSON.stringify(user))
					// if (userInst.paidAccount?.canEnter !== true) {
					// 	var err = new Error("access_denied");
					// 	err.statusCode = 403;
					// 	cb(err)
					// } else {
						let bcrypt = require('bcryptjs');
						bcrypt.compare(data.password, user.password, function (err, isMatch) {//проверка пароля
							if (err) { console.log('bcrypt err', err); return cb(err); }
							else if (isMatch) {
								console.log('pass isMatch', isMatch);
								if (user.createAccessToken.length === 2) {
									console.log('2')
									user.createAccessToken(data.ttl, tokenHandler);
								} else {
									console.log('3')
									user.createAccessToken(data.ttl, data, tokenHandler);
								}
							} else {
								console.log('password fail');
								var err = new Error("password_fail");
								err.statusCode = 401;
								cb(err)
							}
						});
					//}
				} else {//пользователь не найден
					console.log('user not found');
					var err = new Error("user_not_found");
					err.statusCode = 404;
					cb(err)
				}
			}
		});
	};


	user.createAccessToken = function (ttl, options, cb) {
		if (cb === undefined && typeof options === 'function') {
			// createAccessToken(ttl, cb)
			cb = options;
			options = undefined;
		}

		cb = cb || utils.createPromiseCallback();

		let tokenData;
		if (typeof ttl !== 'object') {
			// createAccessToken(ttl[, options], cb)
			tokenData = { ttl };
		} else if (options) {
			// createAccessToken(data, options, cb)
			tokenData = ttl;
		} else {
			// createAccessToken(options, cb);
			tokenData = {};
		}

		const userSettings = user.constructor.settings;
		tokenData.ttl = Math.min(tokenData.ttl || userSettings.ttl, userSettings.maxTTL);
		user.models.accessTokens.create(tokenData, options, cb);
		return cb.promise;
	};

	user.remoteMethod(
		'loginPhone',
		{
			description: 'Login a user with phone and password.',
			accepts: [
				{ arg: 'credentials', type: 'object', required: true, http: { source: 'body' } },
				{ arg: 'include', type: ['string'], http: { source: 'query' } }
			],
			returns: {
				arg: 'accessToken', type: 'object', root: true
			},
			http: { verb: 'post' },
		},
	);

	/*user.on('resetPasswordRequest', function (info) {
	  console.log(info.email); // the email of the requested user
	  console.log(info.accessToken.id); // the temp access token to allow password reset
	  console.log('info',info)
	  // requires AccessToken.belongsTo(User)
	  info.accessToken.user(function (err, user) {
		console.log(user); // the actual user
	  });
	});*/




	/*user.remoteMethod(
		'checkPhone',
		{
			description: 'Send by sms new password to a user with phone.',
			accepts: [
				{ arg: 'credentials', type: 'object', required: true, http: { source: 'body' } },
				{ arg: 'include', type: ['string'], http: { source: 'query' } }
			],
			returns: {
				arg: 'answer', type: 'object', root: true
			},
			http: { verb: 'post' },
		},
	);*/

	user.checkPhone = function (data, include, cb) {//проверка телефона и запись
		const userPhone = data.phone
		user.findOne({
			where: {
				phone: userPhone
			}
		}, function (err, userInfo) {
			if (err) {
				console.log('findone err', err);
				return cb(err)
			}
			else {
				if (userInfo) {
					let code = '0000'//Math.trunc(Math.random() * 100000).toString();
					console.log('code', code);
					let hash = user.app.models.User.hashPassword(code);
					console.log('hash', hash);
					user.upsertWithWhere({ id: userInfo.id }, { newPassword: hash }, function (err, user2) {
						if (err !== null) {
							console.log('error while uploading!');
							return cb(err);
						} else {
							console.log('no error, success', user2);
							cb(null, code)
							// console.log('checkPhone sms 0')
							// smsModule.sendSMS(userPhone, 'Проверочный код: ' + code).then(answ => {

							// })
							/*user.app.models.settings.findOne({
								where: { name: "smsApiId" }
							}, function (err, setting) {
								if (err) {
									console.log('findone err', err);
									cb(null, code)////////////////////////////////////////
								}
								else {
									if (setting && setting.value && setting.value.application_id) {
										//sms send here
										setting = JSON.parse(JSON.stringify(setting));
										console.log('userPhone',userPhone)
										const data = {
											application_id: setting.value.application_id,
											application_token: setting.value.application_token,
											number: userPhone,
											text: 'Code: ' + code,
											sender_id: setting.value.sender_id,
											sender_id_value: setting.value.sender_id_value,
											country: setting.value.country
										  };
									
										  console.log(data);
										  //return
									
										  let request = require('request');
									
										  request.post({
											url:     'https://portal.bulkgate.com/api/1.0/simple/transactional',
											json:   data
										  }, function(error, response, body){
											if (error) {
											  //cb(error)
											  throw error
											} else {
											  //console.log('response', response);
											  console.log('sms_response', body);
											  cb(null, code)
											  //return
											}
										  });*/



							/*let request = require('request');

							let phone = data.phone.toString();
							let apiId = setting.value;

							const https = require('https');

							console.log('start');

							const options = {
								hostname: 'portal.bulkgate.com',
								port: 443,
								path: '/api/1.0/simple/transactional',
								method: 'POST',
								headers: {
									'Content-Type': 'application/json'
								}
							}

							const data = JSON.stringify({
								application_id: '10774',
								application_token: 'IrgzJUkYeRoU6EpIEWfTCSYEYzpfWZxd59rErsJdIOpXVJmBDn',
								number: '+79651098871',
								text: 'Code: 0000',
								sender_id: 'gText',
								sender_id_value: 'AYA'
							})

							const httpRequest = https.request(options, (res) => {
								console.log(res.statusCode);

								res.on('data', (d) => {
									process.stdout.write(d)
								})
							})

							httpRequest.on('error', (err) => {
								console.error(err);
							})

							httpRequest.write(data);
							httpRequest.end();

							console.log('done');

							request(`https://sms.ru/sms/send?api_id=${apiId}&to=${phone}&msg=${code}&json=1`, function (error, response, body) {
								//request(`https://sms.ru/my/balance?api_id=${apiId}&json=1`, function (error, response, body) {
								if (error) {
									cb(error)
								} else {
									console.log('sms_response', body);
									//cb(null,'sms was send')
									cb(null, code)//////////////////////////
								}
							});*/
							/*} else {
								console.log('api code did not found', err);
								cb(null, code)//////////////////////////
							}
						}
					})*/
						}
					});

				} else {//пользователь не найден
					console.log('user not found');
					var err = new Error("user_not_found");
					err.statusCode = 404;
					cb(err)
				}
			}
		});
	};

	user.remoteMethod('confirmEmail', {
		description: 'Confirm entered email',
		accepts: [
			{
				arg: 'email', type: 'string', required: true
			}
		],
		returns: [
			{
				arg: 'confirmation', type: 'string', root: true
			}
		],
		http: { verb: 'post' }
	})

	user.confirmEmail = function (email, cb) {
		console.log(email);
		const mailer = require('nodemailer');

		const tranporter = mailer.createTransport({
			service: 'gmail',//'Yahoo', // no need to set host or port etc.
			auth: {
				user: 'sdesk27@gmail.com',//'ugene.chkalov@yahoo.com',
				pass: 'jlo8864xy'//'utbdhtpjsynjngvd'
			}
		})

		tranporter.sendMail({
			from: 'sdesk27@gmail.com',//'ugene.chkalov@yahoo.com', // sender address
			to: email, // list of receivers
			subject: "email confirmation", // Subject line
			text: "Test text", // plain text body
			html: "<b><a href='google.com'>I am Google</a></b>", // html body
		}).then((data) => {
			console.log(data);

			cb(null, email);
		})
	}

	user.afterRemote('create', function (context, user1, next) {
		console.log('user1', user1)
		//const __dirname = '/opt/api/server'
		var path = require('path');
		console.log('path.resolve(', path.resolve(__dirname, '../../server/views/verify.ejs'))
		var options = {
			type: 'email',
			to: user1.email,
			from: 'sdesk27@gmail.com',
			subject: 'Thanks for registering.',
			template: path.resolve(__dirname, '../../server/views/verify.ejs'),
			redirect: '/verified',
			user: user1,
			//port: 443,//4200,
			//host: 'aya.dev-vt2b.ru',
			verifyHref: 'https://keepers.dev-vt2b.ru/api/users/confirm?uid=' + user1.id + '&redirect=/api/verified'//&token='+''%2F
		};
		console.log('options', options)

		user1.verify(options, function (err, response) {
			if (err) {
				//user.deleteById(user1.id);
				console.log('err', err)
				next(err);
			}
			console.log('response', response)
			next()
			/*context.res.render('response', {
			  title: 'Signed up successfully',
			  content: 'Please check your email and click on the verification link ' +
				  'before logging in.',
			  redirectTo: '/',
			  redirectToLinkText: 'Log in'
			});*/
		});
	});

	// Method to render
	/*User.afterRemote('prototype.verify', function(context, user, next) {
		console.log('verified')
		context.res.render('response', {
		title: 'A Link to reverify your identity has been sent '+
			'to your email successfully',
		content: 'Please check your email and click on the verification link '+
			'before logging in',
		redirectTo: '/',
		redirectToLinkText: 'Log in'
		});
	});*/

	user.remoteMethod(
		'setNewPassword',
		{
			description: 'Set new password to a user with phone, return access token.',
			accepts: [
				{ arg: 'credentials', type: 'object', required: true, http: { source: 'body' } },
				{ arg: 'include', type: ['string'], http: { source: 'query' } }
			],
			returns: {
				arg: 'accessToken', type: 'object', root: true
			},
			http: { verb: 'post' },
		},
	);

	user.setNewPassword = function (data, include, cb) {//проверка импорта из csv
		cb = cb || utils.createPromiseCallback();
		console.log('data', data);
		console.log('cb', cb);

		function tokenHandler(err, token) {
			if (err) return cb(err);
			if (Array.isArray(include) ? include.indexOf('user') !== -1 : include === 'user') {
				// NOTE(bajtos) We can't set token.user here:
				//  1. token.user already exists, it's a function injected by
				//     "AccessToken belongsTo User" relation
				//  2. ModelBaseClass.toJSON() ignores own properties, thus
				//     the value won't be included in the HTTP response
				// See also loopback#161 and loopback#162
				token.__data.user = user;
			}
			cb(err, token);
		}

		user.findOne({
			where: {
				phone: data.phone
			}
		}, function (err, userInfo) {
			if (err) {
				console.log('findone err', err);
				return cb(err)
			}
			else {
				if (userInfo && userInfo.newPassword) {
					console.log('userInfo', userInfo);
					let bcrypt = require('bcryptjs');
					bcrypt.compare(data.password, userInfo.newPassword, function (err, isMatch) {//проверка пароля
						if (err) { console.log('bcrypt err', err); return cb(err); }
						else if (isMatch) {

							user.upsertWithWhere({ id: userInfo.id }, { newPassword: null }, function (err, user2) {//, password: data.password
								if (err !== null) {
									console.log('error while uploading!');
									return cb(err);
								} else {
									console.log('no error, success', user2);
									if (user2.createAccessToken.length === 2) {
										console.log('2')
										user2.createAccessToken(data.ttl, tokenHandler);
									} else {
										console.log('3')
										user2.createAccessToken(data.ttl, data, tokenHandler);
									}
									//cb(null, 'ok')
								}
							});
							console.log('pass isMatch', isMatch);

						} else {
							console.log('password fail');
							var err = new Error("password_fail");
							err.statusCode = 401;
							cb(err)
						}
					});
				} else {//пользователь не найден
					console.log('user or newPassword not found');
					var err = new Error("user_or_new_password_not_found");
					err.statusCode = 404;
					cb(err)
				}
			}
		});
	};

	/*user.observe('before save', async function (ctx) {
		if (ctx.isNewInstance) {
		  const data = {
			application_id: '10774',
			application_token: 'IrgzJUkYeRoU6EpIEWfTCSYEYzpfWZxd59rErsJdIOpXVJmBDn',
			number: ctx.instance.phone,
			text: 'Code: 0000',
			sender_id: 'gText',
			sender_id_value: 'AYA',
			country: 'ru'
		  };
	
		  console.log(data);
		  //return
	
		  let request = require('request');
	
		  request.post({
			url:     'https://portal.bulkgate.com/api/1.0/simple/transactional',
			json:   data
		  }, function(error, response, body){
			if (error) {
			  //cb(error)
			  throw error
			} else {
			  //console.log('response', response);
			  console.log('sms_response', body);
			  //cb(null, code)
			  return
			}
		  });
	
		  request.get(`https://portal.bulkgate.com/api/1.0/simple/transactional
		  ?application_id=10774
		  &application_token=IrgzJUkYeRoU6EpIEWfTCSYEYzpfWZxd59rErsJdIOpXVJmBDn
		  &number=${ctx.instance.phone}
		  &text=Code:_0000
		  &sender_id=gText
		  &sender_id_value=AYA
		  &json=1`, function (error, response, body) {
			if (error) {
			  //cb(error)
			  throw error
			} else {
			  //console.log('response', response);
			  //console.log('sms_response', body);
			  //cb(null, code)
			  return
			}
		  });
	
		  this.http.post('https://portal.bulkgate.com/api/1.0/simple/transactional', data, {
			headers: new HttpHeaders({
			  'Content-Type': 'application/json'
			})
		  }).subscribe((res) => {
			console.log(res);
			this.errors.code = '';
		  }, (err) => {
			console.log(err);
			this.errors.code = err.error.error;
		  });
	
		} else {
		  return
		}
	  })*/

	user.observe('before save', function (ctx, next) {
		if (ctx.isNewInstance) {
			next()
		} else {
			//при изменении очков происходит проверка для изменения уровня
			if (ctx.currentInstance && ctx.data?.level_points >= ctx.currentInstance.level * 1000) {
				ctx.data.level_points -= ctx.currentInstance.level * 1000
				ctx.data.level = ctx.currentInstance.level + 1
			}
			if (ctx.currentInstance && (ctx.data?.firstname != ctx.currentInstance.firstname || ctx.data?.lastname != ctx.currentInstance.lastname)) {
				user.app.models.MasterUsers.updateAll(
					{ userId: ctx.currentInstance.id },
					{ firstname: ctx.data.firstname || ctx.currentInstance.firstname, lastname: ctx.data.lastname || ctx.currentInstance.lastname }
				)
			}
			next()
		}
	})

	user.observe('after save', async function (ctx, next) {
		// console.log('ctx.instance', ctx.instance)
		// console.log('ctx.data', ctx.data)
		// console.log('ctx.isNewInstance', ctx.isNewInstance)
		// console.log('ctx.currentInstance', ctx.currentInstance)
		if (ctx.isNewInstance) {
			await user.app.models.TabletNotification.create({ userId: ctx.instance.id, tabletTypeId: 'morning', date: new Date(2020, 0, 1, 2, 0, 0) })
			await user.app.models.TabletNotification.create({ userId: ctx.instance.id, tabletTypeId: 'evening', date: new Date(2020, 0, 1, 17, 0, 0) })

			await user.app.models.MaterialSection.create({ userId: ctx.instance.id, name: 'Избранное' })
			await ctx.instance.wallet.create()
			await ctx.instance.paidAccount.create({userId: ctx.instance.id})
			//add role
			/*app.models.RoleMapping.create({
				principalType: app.models.RoleMapping.USER,
				principalId: ctx.instance.id,
				roleId: "user"
			}, function(err, principal) {
				console.log('principal', principal)
				//cb(err);
			});*/
		}


		/*if (ctx.isNewInstance) {
		  //user.app.models.upsertWithWhere({userId: }, {})
		ctx.instance.morningTablet = new Date(2000, 0, 1, 8, 0, 0)
		ctx.instance.eveningTablet = new Date(2000, 0, 1, 23, 0, 0)
	} else {
		if (!ctx.isNewInstance && ctx.data.morningTablet && ctx.data.morningTablet != ctx.currentInstance.morningTablet) {
			ctx.data.morningTablet = new Date(2020, 0, 1, new Date(ctx.data.morningTablet).getHours(), new Date(ctx.data.morningTablet).getMinutes())
		}
		if (!ctx.isNewInstance && ctx.data.eveningTablet && ctx.data.eveningTablet != ctx.currentInstance.eveningTablet) {
			ctx.data.eveningTablet = new Date(2020, 0, 1, new Date(ctx.data.eveningTablet).getHours(), new Date(ctx.data.eveningTablet).getMinutes())
		}
	}*/
		//next()
	})


	user.addLevelPoints = async function (userId, bonus = 0) {
		if (userId) {
			try {
				const userInst = await user.findById(userId)
				await userInst.updateAttribute("level_points", userInst.level_points + bonus)
				return true
			} catch (e) {
				throw e
			}
		} else {
			return false
		}
	}

	user.remoteMethod(
		'addLevelPoints',
		{
			description: 'add bonus to user instance',
			accepts: [
				{ arg: 'userId', type: 'string', required: true },
				{ arg: 'bonus', type: 'number', required: false }
			],
			returns: {
				arg: 'answ', type: 'boolean', root: true
			},
		},
	);


	//статистика профиля мастера
	user.getMasterStat = async function (masterId) {
		return new Promise(async (resolve, reject) => {
			let stat = {
				userConsultations: {//КОНСУЛЬТАЦИИ [UserConsultation] Количество | Назначенных | На сегодня | Всего
					active: 0,//[Количество] - "status" != "cancelled"
					created: 0,// [Назначенных] - "status":"created"
					today: 0,// [Сегодня] - Надо смотреть по воркслотам за сегодня чтобы был
					all: 0,// [Всего] - Все мастера
				},
				// ЗАДАНИЕ ИГРОКАМ [UserTask] Количество | Выдано | Ожидают проверки
				userTasks: {
					all: 0,// [Количество] - всего
					created: 0,// [Выдано] - "status":"created"
					await: 0,// [Ожидают проверки] - "status":"await"
				},
				// СКРИЖАЛИ ИГРОКОВ (Игроков мастера) [TotalTablets] Количество | Ожидают проверки | За вчера
				totalTablet: {
					all: 0,// [Количество] - всего
					notChecked: 0,// [Ожидают проверки] - "checked":false
					yesterday: 0,// [За вчера] - смотреть по "gameDayDate"						
				}
			}

			try {
				const yesterdayStart = new moment.utc().subtract(1, 'days').startOf('day')
				const yesterdayEnd = new moment.utc().subtract(1, 'days').endOf('day')
				const dayStart = new moment().startOf('day')
				const dayEnd = new moment().endOf('day')

				let master = await user.findById(masterId, {
					include: [
						{
							relation: "users", scope: {
								include: [
									{ relation: "totalTablets", scope: { where: { or: [{ checked: false }, { gameDayDate: { between: [yesterdayStart, yesterdayEnd] } }] } } }
								]
							}
						}
					]
				})

				let consultations = await user.app.models.Consultation.find({
					where: { masterId: masterId }, include:
						{ relation: "userConsultations", scope: { include: "workSlots" } }//userconsultationfind //workslotfind
				})
				consultations = JSON.parse(JSON.stringify(consultations))

				stat.userConsultations.active = consultations.reduce((prev, c) => prev + c?.userConsultations?.filter(userCons => userCons?.status != "cancelled")?.length || 0, 0)
				stat.userConsultations.created = consultations.reduce((prev, c) => prev + c?.userConsultations?.filter(userCons => userCons?.status == "created")?.length || 0, 0)
				stat.userConsultations.today = consultations.reduce((prev, c) => prev +
					c?.userConsultations?.filter(userCons =>
						userCons?.workSlots?.some(
							workSlot => {
								return (
									dayEnd.isAfter(workSlot.startDate) && dayStart.isSameOrBefore(workSlot.startDate)
									|| dayEnd.isSameOrAfter(workSlot.endDate) && dayStart.isBefore(workSlot.endDate)
									)
							}
						))?.length
					|| 0, 0)
				stat.userConsultations.all = consultations.reduce((prev, c) => prev + c?.userConsultations?.length || 0, 0)

				let userTasks = await user.app.models.Task.find({
					where: { masterId: masterId }, include:
						{ relation: "userTasks", scope: {} }
				})
				userTasks = JSON.parse(JSON.stringify(userTasks))

				stat.userTasks.all = userTasks.reduce((prev, task) => prev + task?.userTasks?.length || 0, 0)
				stat.userTasks.created = userTasks.reduce((prev, task) => prev + task?.userTasks?.filter(userTask => userTask?.status == "created")?.length || 0, 0)
				stat.userTasks.await = userTasks.reduce((prev, task) => prev + task?.userTasks?.filter(userTask => userTask?.status == "await")?.length || 0, 0)


				master = JSON.parse(JSON.stringify(master))

				const masterUsers = master.users.map(userInst => userInst.id) || []

				stat.totalTablet.all = await user.app.models.TotalTablet.count({ userId: { inq: masterUsers } })
				stat.totalTablet.notChecked = master.users.reduce((prev, userInst) => 
					prev + userInst?.totalTablets?.filter(totalTablet => totalTablet?.checked == false)?.length || 0, 0)
				stat.totalTablet.yesterday = master.users.reduce((prev, userInst) => prev +
					userInst?.totalTablets?.filter(
						totalTablet => {
							return (yesterdayStart.isSameOrBefore(totalTablet.gameDayDate) && yesterdayEnd.isSameOrAfter(totalTablet.gameDayDate))
						}
					)?.length
				|| 0, 0)
				stat.tablet = stat.totalTablet

			} catch (err) {
				reject(err)
			}
			resolve(stat)
		})
	}

	user.remoteMethod('getMasterStat',
		{
			description: 'статистика профиля мастера',
			accepts: [
				{
					arg: 'masterId',
					type: 'string',
					required: false
				}
			],
			returns: {
				arg: 'stat',
				description: 'master stat',
				type: 'array',
				root: true
			}
		}
	);


	//статистика профиля мастера
	user.getMasterStats = function (options, cb) {
		user.getMasterStat(options.accessToken.userId).then((res) => {cb(null, res)}, err => {throw err})
	}

	user.remoteMethod('getMasterStats',
		{
			description: 'статистика профиля мастера',
			accepts: [
				{
					arg: "options",
					type: "object",
					http: "optionsFromRequest"
				}
			],
			returns: {
				arg: 'stat',
				description: 'master stat',
				type: 'array',
				root: true
			},
			http: {
				verb: 'get'
			}
		}
	);



	//статистика профиля пользователя
	user.getUserStat = async function (userId) {
		return new Promise(async (resolve, reject) => {
			let stat = {
				// ЗАДАНИЙ [UserTask] Количество | Сегодня | "Горячее" | New | Всего
				userTasks: {
					completed: 0,// [Количество] - "status": "completed"
					today: 0,// [Сегодня] - "status": "created", "endDate" : в текущих сутках
					hot: 0,// ["Горячее"] - "status": "created","endDate" в ближайшие 3 часа
					created: 0,// [New] - "status": "created"
					all: 0,// [Всего] - Все пользователя
				},
				//СОБЫТИЙ [Event] Количество | Сегодня | Всего
				events: {
					created: 0,// [Количество] - "status": "created", "dateComplete": {"gte": "${DateTime.now()}"}
					today: 0,// [Сегодня] - "status": "created", "dateComplete" : в текущих сутках
					all: 0,// [Всего] - Все пользователя
				},
				//КОНСУЛЬТАЦИЙ [UserConsultation] Количество | Назначенных | Сегодня | Всего
				userConsultations: {
					active: 0,//[Количество] - "status" != "cancelled"
					created: 0,// [Назначенных] - "status":"created"
					today: 0,// [Сегодня] - Надо смотреть по воркслотам за сегодня чтобы был
					all: 0,// [Всего] - Все пользователя
				},
			}

			try {
				const now = new moment()
				const dayStart = new moment().startOf('day')
				const dayEnd = new moment().endOf('day')

				let userTasks = await user.app.models.UserTask.find({
					where: { userId: userId }
				})

				stat.userTasks.completed = userTasks?.filter(userTask => userTask?.status == "completed")?.length
				stat.userTasks.today = userTasks?.filter(userTask =>
					(userTask?.status == "created" && dayEnd.isSameOrAfter(userTask.endDate) && dayStart.isBefore(userTask.endDate))
				)?.length
				stat.userTasks.hot = userTasks?.filter(userTask =>
					(userTask?.status == "created" && now.clone().add(3, 'hour').isSameOrAfter(userTask.endDate) && now.isBefore(userTask.endDate))
				)?.length
				stat.userTasks.created = userTasks?.filter(userTask => userTask?.status == "created")?.length
				stat.userTasks.all = userTasks?.length

				let events = await user.app.models.Event.find({
				where: { userId: userId, eventTypeId: {inq: ["consultation"]} }
				});
				stat.events.created = events?.filter(event => (event?.status == "created" && now.isSameOrBefore(event.dateComplete)))?.length
				stat.events.today = events?.filter(event =>
					(event?.status == "created" && dayEnd.isSameOrAfter(event.dateComplete) && dayStart.isBefore(event.dateComplete))
				)?.length
				stat.events.all = events?.length

				let userConsultations = await user.app.models.UserConsultation.find({//userconsultationfind
					where: { userId: userId }, include: "workSlots"//workslotfind
				})
				userConsultations = JSON.parse(JSON.stringify(userConsultations))

				stat.userConsultations.active = userConsultations?.filter(userConsultation => (userConsultation?.status != "cancelled"))?.length
				stat.userConsultations.created = userConsultations?.filter(userConsultation => (userConsultation?.status == "created"))?.length
				stat.userConsultations.today = userConsultations?.filter(userConsultation =>
					userConsultation?.workSlots?.some(
						workSlot => {
							return (
								dayEnd.isAfter(workSlot.startDate) && dayStart.isSameOrBefore(workSlot.startDate)
								|| dayEnd.isSameOrAfter(workSlot.endDate) && dayStart.isBefore(workSlot.endDate)
							)
						}
					)
				)?.length
				stat.userConsultations.all = userConsultations?.length

			} catch (err) {
				reject(err)
			}
			resolve(stat)
		})
	}

	user.remoteMethod('getUserStat',
		{
			description: 'статистика профиля пользователя',
			accepts: [
				{
					arg: 'userId',
					type: 'string',
					required: false
				}
			],
			returns: {
				arg: 'stat',
				description: 'user stat',
				type: 'array',
				root: true
			}
		}
	);


	//статистика профиля пользователя
	user.getUserStats = function (options, cb) {
		user.getUserStat(options.accessToken.userId).then((res) => { cb(null, res) }, err => { throw err })
	}

	user.remoteMethod('getUserStats',
		{
			description: 'статистика профиля пользователя',
			accepts: [
				{
					arg: "options",
					type: "object",
					http: "optionsFromRequest"
				}
			],
			returns: {
				arg: 'stat',
				description: 'user stat',
				type: 'array',
				root: true
			},
			http: {
				verb: 'get'
			}
		}
	);

	//статистика профиля пользователя со стороны мастера
	user.getUserOfMasterStat = async function (masterId, userId) {
		return new Promise(async (resolve, reject) => {
			let stat = {
				// МОИ ЗАДАНИЯ ИГРОКУ [UserTask] Количество | На сегодня | "Горячее"| Сделано
				userTasks: {
					created: 0,// [Количество] - "status": "created"
					today: 0,// [На сегодня] - "status": "created", "endDate" : в текущих сутках
					hot: 0,// ["Горячее"] - "status": "created","endDate" в ближайшие 3 часа
					completed: 0,// [Сделано] - "status": "completed"
				},
				// МОИ СОБЫТИЯ [Event] Количество | На сегодня | Всего
				events: {
					completed: 0,// [Количество] - "status": "completed"
					today: 0,// [На сегодня] - "date" : в текущих сутках
					all: 0,// [Всего] - Всего
				},
			}

			try {
				const now = new moment()
				const dayStart = new moment().startOf('day')
				const dayEnd = new moment().endOf('day')

				let userTasks = await user.app.models.Task.find({
					where: { masterId: masterId }, include:
						{ relation: "userTasks", scope: {where: {userId: userId}} }
				})
				userTasks = JSON.parse(JSON.stringify(userTasks))

				stat.userTasks.created = userTasks.reduce((prev, task) => prev + task?.userTasks?.filter(userTask => userTask?.status == "created")?.length || 0, 0)
				stat.userTasks.today = userTasks.reduce((prev, task) => prev + task?.userTasks?.filter(userTask => 
					(userTask?.status == "created" && userTask.endDate && dayEnd.isSameOrAfter(userTask.endDate) && dayStart.isBefore(userTask.endDate))
					)?.length || 0, 0)
				stat.userTasks.hot = userTasks.reduce((prev, task) => prev + task?.userTasks?.filter(userTask => 
					(userTask?.status == "created" && userTask.endDate && now.clone().add(3, 'hour').isSameOrAfter(userTask.endDate) && now.isSameOrBefore(userTask.endDate))
					)?.length || 0, 0)
				stat.userTasks.completed = userTasks.reduce((prev, task) => prev + task?.userTasks?.filter(userTask => userTask?.status == "completed")?.length || 0, 0)

				let events = await user.app.models.Event.find({
					where: { masterId: masterId, userId: userId, eventTypeId: {inq: ["consultation"]} }
				});
// 				completed: 0,// [Количество] - "status": "completed" ("поменять на статус "created","dateComplete": {"gte": "${DateTime.now()}"})
// today: 0,// [На сегодня] - "date" : в текущих сутках ( поменять на "status": "created","dateComplete" : в текущих сутках)
				//stat.events.completed = events?.filter(event => (event?.status == "completed"))?.length
				stat.events.completed = events?.filter(event =>
					(event?.status == "created" && event.dateComplete && moment().isSameOrAfter(event?.dateComplete))
				)?.length
				stat.events.today = events?.filter(event =>
					(event?.status == "created" && event.dateComplete && dayEnd.isSameOrAfter(event.dateComplete) && dayStart.isBefore(event.dateComplete))
				)?.length
				stat.events.all = events?.length
				
			} catch (err) {
				reject(err)
			}
			resolve(stat)
		})
	}

	user.remoteMethod('getUserOfMasterStat',
		{
			description: 'статистика профиля пользователя со стороны мастера',
			accepts: [
				{
					arg: 'masterId',
					type: 'string',
					required: false
				},
				{
					arg: 'userId',
					type: 'string',
					required: false
				}
			],
			returns: {
				arg: 'stat',
				description: 'user stat',
				type: 'array',
				root: true
			}
		}
	);


	//статистика профиля пользователя со стороны мастера
	user.getUserOfMasterStats = function (userId, options, cb) {
		user.getUserOfMasterStat(options.accessToken.userId, userId).then((res) => { cb(null, res) }, err => { throw err })
	}

	user.remoteMethod('getUserOfMasterStats',
		{
			description: 'статистика профиля пользователя со стороны мастера',
			accepts: [
				{
					arg: 'userId',
					type: 'string',
					required: false
				},
				{
					arg: "options",
					type: "object",
					http: "optionsFromRequest"
				}
			],
			returns: {
				arg: 'stat',
				description: 'user stat',
				type: 'array',
				root: true
			},
			http: {
				verb: 'get'
			}
		}
	);
	
	//запросить пользователю роль MasterKeeper
	user.requestMasterKeeper = async function (options, cb) {
		try {
			const initUser = await user.findById(options.accessToken.userId)
			if (!initUser) {
				var err = new Error("not_found");
				err.statusCode = 404;
				throw err
			} else if (!initUser?.isMaster) {
				let err = new Error("permission denied")
				err.statusCode = 403
				throw err
			} else if (initUser?.isMasterKeeper) {
				var err = new Error("already_masterkeeper");
				err.statusCode = 409;
				throw err
			} else {
				emailModule.sendEmail(null, {
					subject: 'Заявка на роль мастера-хранителя',
					text: `Пользователь ${initUser.firstname} ${initUser.lastname} (id ${initUser.id}) хочет стать мастером-хранителем`
				},
					true)
				return 'ok'
			}
		} catch (err) {
			throw err
		}
	}

	user.remoteMethod('requestMasterKeeper',
		{
			description: 'запросить пользователю роль MasterKeeper',
			accepts: [
				//{ arg: 'id', type: 'string', required: true },
				{
					arg: "options",
					type: "object",
					http: "optionsFromRequest"
				}
			],
			returns: {
				arg: 'obj',
				description: 'objj',
				type: 'object',
				root: true
			},
			http: {
				//path: '/:id/setMasterKeeper',
				verb: 'post'
			}
		}
	);

		
	//запросить доступ к supabase
	user.getSB = async function (options, cb) {
		try {
			const initUser = await user.findById(options.accessToken.userId)
			if (!initUser) {
				var err = new Error("not_found");
				err.statusCode = 404;
				throw err
			} else {
				var CryptoJS = require('crypto-js');
				let pass
				if (initUser.sbPass) {
					var bytes = CryptoJS.AES.decrypt(initUser.sbPass, sb_salt);
					pass = bytes.toString(CryptoJS.enc.Utf8);
				} else {

					const crypto = require('crypto');
					let buf = Buffer.alloc(10);
					pass = crypto.randomFillSync(buf, 5).toString('hex');

					var encrypted = CryptoJS.AES.encrypt(pass, sb_salt);
					const crPass = encrypted.toString();
					await initUser.updateAttribute("sbPass", crPass)
				}
				return pass
			}
		} catch (err) {
			throw err
		}
	}

	user.remoteMethod('getSB',
		{
			description: 'запросить доступ к supabase',
			accepts: [
				//{ arg: 'id', type: 'string', required: true },
				{
					arg: "options",
					type: "object",
					http: "optionsFromRequest"
				}
			],
			returns: {
				arg: 'string',
				description: 'string',
				type: 'string',
				root: true
			},
			http: {
				verb: 'get'
			}
		}
	);

	//отправить пуш всем пользователям
	user.sendPushAll = async function (data, data2, options, cb) {
		//try {
			return pushNotification.sendPushToAll(data, data2)
		// } catch (err) {
		// 	throw err
		// }
	}

	user.remoteMethod('sendPushAll',
		{
			description: 'отправить пуш всем пользователям',
			accepts: [
				{ arg: 'data', type: 'object', required: true },
				{ arg: 'data2', type: 'object', required: false },
				{
					arg: "options",
					type: "object",
					http: "optionsFromRequest"
				}
			],
			returns: {
				arg: 'obj',
				type: 'answ',
				root: true
			},
			http: {
				verb: 'post'
			}
		}
	);




	/*
	user.checkPhone = function (data, include, cb) {//проверка телефона и запись
		const userPhone = data.phone
		user.findOne({
			where: {
				phone: userPhone
			}
		}, function (err, userInfo) {
			if (err) {
				console.log('findone err', err);
				return cb(err)
			}
			else {
				if (userInfo) {
					let code = '0000'//Math.trunc(Math.random() * 100000).toString();
					console.log('code', code);
					let hash = user.app.models.User.hashPassword(code);
					console.log('hash', hash);
					user.upsertWithWhere({ id: userInfo.id }, { newPassword: hash }, function (err, user2) {
						if (err !== null) {
							console.log('error while uploading!');
							return cb(err);
						} else {
							console.log('no error, success', user2);
							cb(null, code)

						}
					});

				} else {//пользователь не найден
					console.log('user not found');
					var err = new Error("user_not_found");
					err.statusCode = 404;
					cb(err)
				}
			}
		});
	};*/

		
	user.remoteMethod(
		'checkExistence',
		{
			description: 'Check existence of phone in db',
			accepts: [
				{ arg: 'phone', type: 'string', required: true }
			],
			returns: {
				arg: 'answer - true if exists', type: 'boolean', root: true
			},
			http: { verb: 'get' },
		},
	);

	user.checkExistence = function (phone, cb) {//проверка телефона и запись
		user.findOne({
			where: {
				phone: phone
			}
		}, function (err, userInfo) {
			if (err) {
				console.log('findone err', err);
				return cb(err)
			}
			else {
				cb(null, !!userInfo)
			}
		})
	}



	user.remoteMethod(
		'checkNewPhone',
		{
			description: 'Send activation code by sms to a new user with phone.',
			accepts: [
				{ arg: 'phone', type: 'string', required: true },
			],
			returns: {
				arg: 'answer', type: 'string', root: true
			},
			http: { verb: 'post' },
		},
	);

	user.checkNewPhone = function (phone, cb) {//проверка телефона и создание нового пользователя
		user.findOne({
			where: {
				phone: phone, //activation_phone: false
			}
		}, function (err, userInfo) {console.log('userInfo', userInfo)
			if (err) {
				console.log('findone err', err);
				return cb(err)
			}
			else {
				//повторная отправка для только что созданного пользователя/восстановления пароля
				if (userInfo /*&& !userInfo.activation_phone*/) {
					if (istest && phone.length <= 6) {//!!TEMPORARY only for test
						let code = '0000'
						user.upsertWithWhere({ id: userInfo.id }, { activation_code: code, activation_time: new moment().add(5, 'minutes').toDate() }, function (err, user2) {
							if (err !== null) {
								console.log('error while uploading!');
								return cb(err);
							} else {
								cb(null, 'ok')
							}
						});
					} else {
						let code = Math.trunc(Math.random() * 100000).toString();
						while (code.length < 6) code += '0'

						smsModule.sendSMS(phone, (userInfo.activation_phone ? 'Ваш код восстановления: ' : 'Ваш код регистрации: ') + code).then(answ => {
							user.upsertWithWhere({ id: userInfo.id }, { activation_code: code, activation_time: new moment().add(5, 'minutes').toDate() }, function (err, user2) {
								if (err !== null) {
									console.log('error while uploading!');
									return cb(err);
								} else {
									cb(null, 'ok')
								}
							});
						}, err => { throw err })
					}
				} else {//пользователь не найден
					const password = Math.random().toString(36).substr(2, 8)
					if (istest && phone.length <= 6) {//!!TEMPORARY only for test
						let code = '0000'
						user.create({ activation_code: code, phone, password, activation_time: new moment().add(5, 'minutes').toDate() }, function (err, user2) {
							if (err !== null) {
								console.log('error while uploading!');
								return cb(err);
							} else {
								cb(null, 'ok')
							}
						});
					} else {
						let code = Math.trunc(Math.random() * 100000).toString();
						while (code.length < 6) code += '0'
						smsModule.sendSMS(phone, 'Ваш код регистрации: ' + code).then(answ => {
							user.create({ activation_code: code, phone, password, activation_time: new moment().add(5, 'minutes').toDate() }, function (err, user2) {
								if (err !== null) {
									console.log('error while uploading!');
									return cb(err);
								} else {
									cb(null, 'ok')
								}
							});
						}, err => { throw err })
					}
				}
			}
		});
	};

	user.remoteMethod(
		'checkActivationCode',
		{
			description: 'Check activation code of new user.',
			accepts: [
				{ arg: 'phone', type: 'string', required: true },
				{ arg: 'code', type: 'string', required: true },
			],
			returns: {
				arg: 'answer', type: 'string', root: true
			},
			http: { verb: 'post' },
		},
	);

	user.checkActivationCode = function (phone, code, cb) {//проверка телефона и отправка токена
		if (code) {
			user.findOne({
				where: {
					phone: phone, activation_code: code//, activation_phone: false
				}
			}, function (err, userInfo) {
				if (err) {
					console.log('findone err', err);
					return cb(err)
				}
				else {
					//повторная отправка для только что созданного пользователя
					if (userInfo) {

						user.upsertWithWhere({ id: userInfo.id }, { activation_code: null, activation_phone: true, activation_time: null }, function (err, user2) {
							if (err !== null) {
								console.log('error while uploading!');
								return cb(err);
							} else {

								cb = cb || utils.createPromiseCallback();
								const data = {}
								const include = {}

								function tokenHandler(err, token) {
									if (err) return cb(err);
									if (Array.isArray(include) ? include.indexOf('user') !== -1 : include === 'user') {
										// NOTE(bajtos) We can't set token.user here:
										//  1. token.user already exists, it's a function injected by
										//     "AccessToken belongsTo User" relation
										//  2. ModelBaseClass.toJSON() ignores own properties, thus
										//     the value won't be included in the HTTP response
										// See also loopback#161 and loopback#162
										token.__data.user = user2;
									}
									cb(err, token);
								}


								if (user2.createAccessToken.length === 2) {
									user2.createAccessToken(data.ttl, tokenHandler);
								} else {
									user2.createAccessToken(data.ttl, data, tokenHandler);
								}
							}
						});
					} else {
						console.log('code_failed');
						var err = new Error("code_failed");
						err.statusCode = 401;
						cb(err)
					}
				}
			});
		} else {
			console.log('code_required');
			var err = new Error("code_required");
			err.statusCode = 412;
			cb(err)
		}
	};



	user.remoteMethod(
		'editMyInfo',
		{
			description: 'User can edit own info',
			accepts: [
				{ arg: 'data', type: 'object', required: true },
				{
					arg: "options",
					type: "object",
					http: "optionsFromRequest"
				}
			],
			returns: {
				arg: 'user', type: 'object', root: true
			},
			http: { verb: 'post' },
		},
	);

	user.editMyInfo = function (data, options, cb) {//редактирование пользователя самого себя
		user.findById(options.accessToken.userId, function (err, userInfo) {
			if (err) throw err
			else {
				//повторная отправка для только что созданного пользователя
				if (userInfo) {
					userInfo.updateAttributes(data, function (err, userIns) {
						if (err) throw err
						cb(null, userIns)
					})
				} else {
					var err = new Error("error");
					err.statusCode = 400;
					cb(err)
				}
			}
		});
	};
};
