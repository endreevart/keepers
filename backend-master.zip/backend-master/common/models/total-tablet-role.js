'use strict';

module.exports = function(Totaltabletrole) {

};
