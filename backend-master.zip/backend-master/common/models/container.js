'use strict';

module.exports = function(container) {
  container.beforeRemote('upload', function(req, unused, next) {
    if (req.params.container) {
      container.createContainer({name: req.params.container}, function() {
        next();
      });
    } else {
      next();
    }
  });
};
