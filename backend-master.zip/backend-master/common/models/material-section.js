'use strict';

module.exports = function(Materialsection) {
    Materialsection.duplicate = function (id, name, options, cb) {
        Materialsection.findById(id,{include: "librarySections"}, function (err, section) { 
            if (err) throw err
            if (!section) {
                var err = new Error("not_found");
                err.statusCode = 404;
                cb(err)
            } else {
                Materialsection.create({userId: section.userId, name}, function(err, newSection) {
                    if (err) throw err
                    section = JSON.parse(JSON.stringify(section))
                    const promises = []
                    section.librarySections.forEach(librarySection => {
                        promises.push(newSection.librarySections.create({materialId: librarySection.materialId, userId: librarySection.userId}))
                    });
                    Promise.all(promises).then(res => {
                        Materialsection.findById(newSection.id,{include: "librarySections"}, function (err, newSection) {
                            if (err) throw err
                            cb(null, newSection)
                        })
                    }, err => {throw err})
                })
            }
        })
    }

    Materialsection.remoteMethod('duplicate',
        {
            description: 'Duplicate section of material',
            accepts: [
                {arg: 'id', type: 'string', required: true},
                {arg: 'name', type: 'string', required: true},
                {
                    arg: "options",
                    type: "object",
                    http: "optionsFromRequest"
                }
            ],
            returns: {
                arg: 'new material section',
                type: 'object',
                root: true
            },
            http: {path: '/:id/duplicate', verb: 'post'}
        }
    );
};
