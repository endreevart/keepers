'use strict';

module.exports = function(Rubric) {

};
