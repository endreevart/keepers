'use strict';

module.exports = function (Event) {
    Event.getForMaster = function (userId, search, endDate, startDate, status, eventTypeId, order, orderByDate = true, skip = 0, limit, options, cb) {
        let searchFilter = { masterId: options.accessToken.userId }
        if (userId) searchFilter.userId = userId
        if (endDate) searchFilter.date = { "lt": endDate }
        if (startDate) searchFilter.date = { "gt": startDate }
        if (endDate && startDate) searchFilter.date = { "between": [startDate, endDate] }
        if (status) searchFilter.status = status
        if (eventTypeId) searchFilter.eventTypeId = eventTypeId

        let relation
        let nestedRelation
        let include
        let descriptionName
        if (search && eventTypeId) {
            switch (eventTypeId) {
                case "task": {
                    relation = "userTask"
                    nestedRelation = "task"
                    descriptionName = "description"
                    break;
                }
                case "consultation":{//"userConsultationId": {
                    relation = "userConsultation"
                    nestedRelation = "consultation"
                    descriptionName = "shortDescription"
                    break;
                }
            }
            include = {
                "relation": relation, "scope": {
                    include: {
                        "relation": nestedRelation, "scope": {
                            where:
                            {
                                'or': [
                                    { name: { like: new RegExp(search, "i") } },
                                    { [descriptionName]: { like: new RegExp(search, "i") } }
                                ]
                            }
                        }
                    }
                }
            }
        } else if (search && !eventTypeId) {
            // var err = new Error("not_found");
            // err.statusCode = 404;
            // throw err
            searchFilter['or'] = [
                { "name": { like: new RegExp(search, "i") } },
                { "description": { like: new RegExp(search, "i") } }
            ]
        } 
        //else {
            Event.find({
                where: searchFilter,
                include: include,//rubricFilter, 
                order: `${orderByDate ? "date" : "dateComplete"} ${(order > 0) ? "ASC" : "DESC"}`,
                skip: (skip && !search) ? skip : undefined,
                limit: (limit && !search) ? limit : undefined,//: (limit && (rubrics.length == 0)) ? limit : undefined,
            }, function (err, items) {
                if (err) throw err;
                if (search && eventTypeId) {
                    items = JSON.parse(JSON.stringify(items))
                    let filteredItems = []
                    let skipCount = 0
                    for (let item of items) {
                        if (skipCount >= skip && (typeof item[relation]?.[nestedRelation] == "array" && item[relation]?.[nestedRelation]?.length > 0 
                         || typeof item[relation]?.[nestedRelation] == "object" && item[relation]?.[nestedRelation]?.id ))
                            filteredItems.push(item)
                        else if (typeof item[relation]?.[nestedRelation] == "array" && item[relation]?.[nestedRelation]?.length > 0 
                        || typeof item[relation]?.[nestedRelation] == "object" && item[relation]?.[nestedRelation]?.id )
                            skipCount++
                        if (limit && filteredItems.length == limit) break
                    }
                    items = filteredItems
                }
                cb(null, items)
            })
        //}
    }

    Event.remoteMethod('getForMaster',
        {
            description: 'Returns masters events with filtering',
            accepts: [
                {
                    arg: 'userId',
                    type: 'string',
                    required: false
                },
                {
                    arg: 'search',
                    type: 'string',
                    description: "поиск по названию и краткому описанию",
                    required: false
                },
                {
                    arg: 'endDate',
                    type: 'date',
                    required: false
                },
                {
                    arg: 'startDate',
                    type: 'date',
                    required: false
                },
                {
                    arg: 'status',
                    type: 'string',
                    required: false
                },
                {
                    arg: 'eventTypeId',
                    type: 'string',
                    required: false
                },
                {
                    arg: 'order',
                    type: 'number',
                    description: "сортировка по полю dateComplete/date",
                    required: true
                },
                {
                    arg: 'orderByDate',
                    type: 'boolean',
                    description: "сортировка по полю dateComplete/date"
                },
                {
                    arg: 'skip',
                    type: 'number',
                    required: false
                },
                {
                    arg: 'limit',
                    type: 'number',
                    required: false
                },
                {
                    arg: "options",
                    type: "object",
                    http: "optionsFromRequest"
                }
            ],
            returns: {
                arg: 'events',
                type: 'array',
                root: true
            },
            http: {
                verb: 'get'
            }
        }
    );
};
