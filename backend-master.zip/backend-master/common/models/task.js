'use strict';
var moment = require('moment');
const pushNotification = require('../../helpers/pushNotification');

module.exports = function(Task) {

      /**
     * array of all active tasks with users
     * 
     * @param {string} userId
     * @param {*} cb 
     */
  //Список всех активных заданий конкретного мастера назначенных на Игроков
  Task.getActiveForMaster = function (masterId, options, cb) {
    if (!masterId || masterId == "{}") masterId = options.accessToken.userId
    Task.find({
      where: {
        masterId: masterId,
        startDate: { lte: new Date() },
        or: [{endDate: undefined}, {endDate: {gt: new Date()}}]
      },
      include: {relation: 'users', scope: {limit: 1, fields: ['id']}}
    }, function (err, tasksInstance) {
      if (err) throw err;
      //const tasks = JSON.parse(JSON.stringify(tasksInstance))
      for (let i = 0; i < tasksInstance.length; i++) {
        const task = JSON.parse(JSON.stringify(tasksInstance[i]))
        if (task.users.length == 0) {
            tasksInstance.splice(i, 1);
            i--
        }
      }
      cb(null, tasksInstance)
    })
  }

  Task.remoteMethod('getActiveForMaster',
    {
      description: 'Список всех активных заданий конкретного мастера назначенных на Игроков',
      accepts: [
        {
          arg: 'masterId',
          type: 'string',
          required: false
        },
        {
            arg: "options",
            type: "object",
            http: "optionsFromRequest"
        }
      ],
      returns: {
        arg: 'taskArray',
        description: 'array of all active tasks with users',
        type: 'array',
        root: true
      },
      http: {
        verb: 'post'
      }
    }
  );



      /**
     * master adds task for user
     * 
     * @param {string} userId
     * @param {string} taskId
     * @param {date} startDate
     * @param {date} endDate
     * @param {*} cb 
     */
  //Мастер с помощью этой функции назначает задание на пользователя
  Task.createUserTask = async function (userId, taskId, startDate, endDate, userConsultationId, options, cb) {

    if (!startDate || startDate == "{}") startDate = undefined
    if (!endDate || endDate == "{}") endDate = undefined
    let userTasks = []

    try {
      //если есть параметры времени, создаем задание по ним
      if (startDate || endDate) {
        const userTask = await Task.app.models.UserTask.create({
          "startDate": startDate,
          "endDate": endDate,
          "userId": userId,
          "taskId": taskId
        })
        userTasks = [userTask]
      } else {
        //если нет - создаем задачи для пользователей по параметрам задачи
        const task = await Task.findById(taskId)
        if (!task) {
          var err = new Error("task_not_found");
          err.statusCode = 404;
          cb(err)
        } else {
          startDate = moment(task.startDate)
          if (task.duration && task.periodicity) {
            //задания создаются по периодичности и продолжительности 
            let taskStart = 0;
            while (taskStart < task.duration) {
              const endTimeUT = (taskStart + task.periodicity <= task.duration) ? startDate.clone().add(task.periodicity, 'days') : endDate
              const userTask = await Task.app.models.UserTask.create({
                "startDate": startDate,
                "endDate": endTimeUT,
                //"status": ,
                "userId": userId,
                "taskId": task.id,
                userConsultationId: userConsultationId,
              })
              userTasks.push(userTask)
              startDate.add(task.periodicity, 'days')
              taskStart += task.periodicity;
            }
          } else {
            const userTask = await Task.app.models.UserTask.create({
              "startDate": startDate,
              "endDate": task.endDate,
              "userId": userId,
              "taskId": taskId,
              userConsultationId: userConsultationId,
            })
            userTasks = [userTask]
          }
        }
      }
      pushNotification.sendPushToUser(
        userId, 
        { 'title': 'ЗАДАНИЯ', 'body': 'Поздравляем, у вас новое задание!' },
        { "type": "userTask", "action": "create"/*, "itemId": null*/ }
        ).then(res => { }, e => { console.log('e', e) })
    } catch (err) {
      throw err
    }
    return(userTasks)
  }

  Task.remoteMethod('createUserTask',
    {
      description: 'Мастер с помощью этой функции назначает задание на пользователя',
      accepts: [
        {
          arg: 'userId',
          type: 'string',
          required: true
        },
        {
          arg: 'taskId',
          type: 'string',
          required: true
        },
        {
          arg: 'startDate',
          type: 'date',
          required: false
        },
        {
          arg: 'endDate',
          type: 'date',
          required: false
        },
        {
          arg: 'userConsultationId',
          type: 'string',
          required: false
        },
        {
          arg: "options",
          type: "object",
          http: "optionsFromRequest"
        }
      ],
      returns: {
        arg: 'userTask',
        description: 'user task',
        type: 'array',
        root: true
      },
      http: {
        verb: 'post'
      }
    }
  );

    /**
   * Returns tasks with filtering by rubrics
   * @param {string[]} rubrics названия рубрик
   * @param {string} search по названию и описанию TAsk
   * @param {boolean} draft статус task
   * @param {object} include
   * @param {*} cb
   */
  Task.getByRubrics = function (sections = [], rubrics, search, draft, include, skip = 0, limit, options, cb) {
    let searchFilter = { masterId: options.accessToken.userId }
    if (search) {
      searchFilter['or'] = [
        { name: { like: new RegExp(search, "i") } },
        { description: { like: new RegExp(search, "i") } }
      ]
    }

    let rubricFilter = []
    if (include) rubricFilter = include

    if (draft !== undefined && draft !== null) searchFilter.draft = draft
    if (rubrics.length > 0) rubricFilter.push({ relation: 'rubrics', scope: { where: { name: { inq: rubrics } } } })
    //if (sections.length > 0) rubricFilter.push({ relation: 'taskSections', scope: { /*where: { name: { inq: rubrics } }*/ } })
    if (sections.length > 0) rubricFilter.push({ relation: 'taskLibrary', scope: { where: { userId: options.accessToken.userId }, include: "taskSection" } })

    Task.find({ 
      where: searchFilter, 
      include: (rubricFilter.length > 0) ? rubricFilter : undefined,
      skip: (skip && (rubrics.length == 0)) ? skip : undefined,
      limit: (limit && (rubrics.length == 0)) ? limit : undefined,
    }, function (err, tasks) {
      if (err) throw err;

      if (rubrics.length > 0 || sections.length > 0) {
        tasks = JSON.parse(JSON.stringify(tasks))
        let filteredTasks = []
        let skipCount = 0

        for (let task of tasks) {
          if (rubrics.length > 0 && !task["rubrics"].find(rubric => check(rubric.name, rubrics) )) continue;
          if (sections.length > 0 && !task["taskLibrary"].find(lib => check(lib["taskSection"].name, sections) )) continue;
          if (skipCount >= skip)
            filteredTasks.push(task)
          else
            skipCount++
          if (limit && filteredTasks.length == limit) break
        }
        tasks = filteredTasks
      }

      function check(name, arr){
        const reg = new RegExp(`^${name}$`, 'i')
        return arr.find(el => reg.test(el))
      }
      cb(null, tasks)
    })
  }

  Task.remoteMethod('getByRubrics',
    {
      description: 'Returns tasks with filtering by rubrics',
      accepts: [
        {
          arg: 'sections',
          type: 'array',
          required: false
        },
        {
          arg: 'rubrics',
          type: 'array',
          required: true
        },
        {
          arg: 'search',
          type: 'string',
          description: "поиск по названию и описанию",
          required: false
        },
        {
          arg: 'draft',
          type: 'boolean',
          required: false
        },
        {
          arg: 'include',
          type: 'array',
          required: false
        },
        {
            arg: 'skip',
            type: 'number',
            required: false
        },
        {
            arg: 'limit',
            type: 'number',
            required: false
        },
        {
          arg: "options",
          type: "object",
          http: "optionsFromRequest"
        }
      ],
      returns: {
        arg: 'tasks',
        type: 'array',
        root: true
      },
      http: {
        verb: 'get'
      }
    }
  );

  
  Task.materialsIsFavourite = function (id, filter = {}, options, cb) {
    const libFilter = {
      relation: "librarySections", scope: {
        where: { "userId": options.accessToken.userId },
        include: [{ relation: "materialSection", scope: { where: { name: "Избранное" } } }]
      }
    }
    if (!filter?.include) {
      filter.include = [libFilter]
    } else {
      filter.include.push(libFilter)
    }
    //в выдаче только опубликованные материалы
    if (filter.where?.draft === undefined || filter.where?.draft === null) {
        if (filter.where) filter.where.draft = false
        else filter.where = { draft: false }
    }

    Task.findById(id, { include: { relation: "materials", scope: { ...filter } }},function (err, task) {
      if (err) throw err
      if (!task) {
          var err = new Error("task_not_found");
          err.statusCode = 404;
          cb(err)
      } else {
        // task.materials.find({ ...filter }, function (err, materials) {
        //   if (err) throw err

          let materials = JSON.parse(JSON.stringify(task)).materials
          materials.forEach(item => {
            item.isFavourite = item.librarySections.some(section => (section.userId == options.accessToken.userId && section.materialSection?.name == "Избранное"))
              ? true : false
            if (!filter.include.includes("librarySections") && !filter.include.find(include => ((include?.relation == "librarySections") && !include?.scope?.where?.userId)))
              delete item.librarySections
          });
          cb(null, materials)
        //})
      }
    })
  }

  Task.remoteMethod('materialsIsFavourite',
    {
      description: 'Find out if materials belongs to favourite section of user',
      accepts: [
        { arg: 'id', type: 'string', required: true },
        { arg: 'filter', type: 'object', required: false },
        {
          arg: "options",
          type: "object",
          http: "optionsFromRequest"
        }
      ],
      returns: {
        arg: 'materials',
        type: 'array',
        root: true
      },
      http: { path: '/:id/materials/isFavourite', verb: 'get' }
    }
  );


  /**
   * Метод для массового изменения списка связи разделов для задачи
   * @param {*} id 
   * @param {*} sectionIds 
   * @param {*} options 
   * @param {*} cb 
   */
   Task.changeSections = function (id, sectionIds, options, cb) {
    Task.findById(id, function (err, task) {
      if (err) throw err
      if (!task) {
        var err = new Error("not_found");
        err.statusCode = 404;
        cb(err)
      } else {
        //удаление всех непопавших в список
        Task.app.models.TaskLibrary.deleteAll({
          taskId: id,
          userId: options.accessToken.userId,
          taskSectionId: { nin: sectionIds },
        }, function (err, res) {
          if (err) throw err
          const promises = []
          sectionIds.forEach(sectionId => {
            promises.push(
              Task.app.models.TaskLibrary.findOrCreate({
                taskId: id,
                userId: options.accessToken.userId,
                taskSectionId: sectionId,
              })
            )
          })
          Promise.all(promises).then(res => {
            cb(null)
          }, err => { throw err; })
        })
      }
    })
  }

  Task.remoteMethod('changeSections',
    {
      description: 'Change sections of task',
      accepts: [
        { arg: 'id', type: 'string', required: true },
        { arg: 'sectionIds', type: 'array', required: true },
        {
          arg: "options",
          type: "object",
          http: "optionsFromRequest"
        }
      ],
      returns: {
        arg: 'task',
        type: 'object',
        root: true
      },
      http: { path: '/:id/changeSections', verb: 'post' }
    }
  );
};
