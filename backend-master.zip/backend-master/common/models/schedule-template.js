'use strict';
var moment = require('moment');
var momentTz = require('moment-timezone');
const basic = require("../../helpers/basic.js")

module.exports = function (Scheduletemplate) {
    
    Scheduletemplate.validatesUniquenessOf('masterId');
    Scheduletemplate.validate('daysFormat', 
        function (err) { 
            const days = JSON.parse(JSON.stringify(this)).days
            for (let i = 1; i <= 7; i++ ) {
                for (let j = 1; j <= 5; j++ ) {
                    if (days?.[i]?.[j] === undefined) return err()
                }
            }
        }, 
        {message: 'days format invalid'})

    
    Scheduletemplate.createScheduleTmp = function (days, options, cb) {
        Scheduletemplate.upsertWithWhere(
            { masterId: options.accessToken.userId }, 
            { masterId: options.accessToken.userId, days: days}, 
        function (err, tmp) {
            if (err) cb(err)
            else cb(null, tmp)
        })
    }

    Scheduletemplate.ScheduleTemplateDays = function () {
        const tmp = {}
        for (let i = 1; i <= 7; i++ ) {
            tmp[i] = {}
            for (let j = 1; j <= 5; j++ ) {
                tmp[i][j] = false
            }
        }
        return tmp;
    }

    Scheduletemplate.remoteMethod('createScheduleTmp',
        {
            description: 'Задать типовой месяц - create/update schedule',
            accepts: [
                { arg: 'days', type: 'object', required: true },
                {
                    arg: "options",
                    type: "object",
                    http: "optionsFromRequest"
                },
            ],
            returns: {
                arg: 'schedule',
                type: 'object',
                root: true
            },
            http: {  verb: 'post' }
        }
    );

    
    Scheduletemplate.change = async function (days, options, cb) {
        try {
            let tmp = await Scheduletemplate.findOne({where: { masterId: options.accessToken.userId, days: {neq: null} }})
            if (!tmp?.days) tmp = {"days": Scheduletemplate.ScheduleTemplateDays(), masterId: options.accessToken.userId}     
            for (let weekday in days){
                if (days[weekday]?.length > 0 && weekday <= 7)
                    for (let day of days[weekday]){
                        if (day <= 5)
                            tmp.days[weekday][day] = !tmp.days[weekday][day]
                        }
            }
            return Scheduletemplate.upsertWithWhere(
                { masterId: options.accessToken.userId }, 
                { masterId: tmp.masterId, days: tmp.days})
        } catch (err){
            throw err
        }
    }

    Scheduletemplate.remoteMethod('change',
        {
            description: 'Смена Выделения ряда дней - change schedule',
            accepts: [
                { 
                    arg: 'days', 
                    type: 'object', 
                    descriptions: '{1:[1,2],2:[2,3]….}',
                    required: true 
                },
                {
                    arg: "options",
                    type: "object",
                    http: "optionsFromRequest"
                },
            ],
            returns: {
                arg: 'schedule',
                type: 'object',
                root: true
            },
            http: {  verb: 'post' }
        }
    );


    
    Scheduletemplate.apply = async function (year, month, timezone = "Europe/Moscow", options, res, cb) {
        try {
            const currDate = new moment.utc([year, month - 1])

            const start = currDate.startOf('month')
            const end = currDate.clone().add(1, 'month')

            const startLocal = basic.getTZdate(start, timezone)
            const endLocal = basic.getTZdate(end, timezone)

            await Scheduletemplate.app.models.WorkSlot.deleteAll({//workslotdelete
                //year, month,
                startDate: { lt: endLocal }, endDate: { gt: startLocal },
                masterId: options.accessToken.userId,
                userConsultationId: { inq: [undefined, null, ""] }
            })

            const exists = await Scheduletemplate.app.models.WorkSlot.find({//workslotfind
                where: {
                    //year, month,
                    startDate: { lt: endLocal }, endDate: { gt: startLocal },
                    masterId: options.accessToken.userId
                }, limit: 1
            })
            if (exists?.length > 0) {
                res.status(409)
            }

            let dayTmp = await Scheduletemplate.app.models.ScheduleDay.findOne({ where: { masterId: options.accessToken.userId } })
            dayTmp = JSON.parse(JSON.stringify(dayTmp))
            let monthTmp = await Scheduletemplate.findOne({ where: { masterId: options.accessToken.userId, days: { neq: null } } })
            monthTmp = JSON.parse(JSON.stringify(monthTmp))

            let response = []
            let err

            if (dayTmp?.hours?.length > 0 && monthTmp?.days?.[1]?.[1] !== undefined) {
                let promises = []

                const currDate = new moment.utc()
                const timezoneOffset = currDate.valueOf() - new moment.utc(momentTz.tz(currDate, timezone)
                    .format('YYYY-MM-DDTHH:mm:ss:SSS'), "YYYY-MM-DDTHH:mm:ss:SSS").valueOf();
                
                let first = new moment([year, month - 1])
                let last = first.clone().endOf("month")
                
                let firstDay = first//basic.getTZdate(first, timezone)
                const lastDay = last//basic.getTZdate(last, timezone)

                //firstDay.subtract(1, 'day')
                let week = 1
                let intOfWeek = 0
                while (firstDay.isSameOrBefore(lastDay)) {
                    intOfWeek++
                    if (intOfWeek > 7) {
                        intOfWeek = 1
                        week++
                    }
                    //console.log('firstDay.isoWeekday()', firstDay.toString(), firstDay.date(), firstDay.isoWeekday(), week)
                    //isoWeekday - monday as 1 day of week
                    if (monthTmp?.days?.[firstDay.isoWeekday()]?.[week]) {
                        dayTmp.hours.forEach(slot => {
                            let startTimeLocal = new moment.utc([year, month - 1, firstDay.date(), slot.startHour, slot.startMinute])
                            let endTimeLocal = new moment.utc(`${year}-${month}-${firstDay.date()}T${slot.endHour}:${slot.endMinute}:00.000Z`,
                                'YYYY-MM-DDTHH:mm:ss:SS')

                            promises.push(
                                Scheduletemplate.app.models.WorkSlot.upsertWithWhere({//workslotupdate //workslotcreate
                                    startHour: slot.startHour,
                                    startMinute: slot.startMinute,
                                    endHour: slot.endHour,
                                    endMinute: slot.endMinute,
                                    masterId: options.accessToken.userId, year, month, day: firstDay.date()
                                }, {
                                    startHour: slot.startHour,
                                    startMinute: slot.startMinute,
                                    endHour: slot.endHour,
                                    endMinute: slot.endMinute,
                                    startDate: new moment(moment(startTimeLocal).valueOf() + timezoneOffset),
                                    endDate: new moment(moment(endTimeLocal).valueOf() + timezoneOffset),
                                    masterId: options.accessToken.userId, year, month, day: firstDay.date()
                                })
                            )
                        })
                    }
                    firstDay.add(1, 'day')
                }
                response = await Promise.all(promises)
            } else {
                err = new Error("day template not found")
                err.statusCode = 404
            }

            if (err) throw err
            else return response
        } catch (err) {
            throw err
        }
    }

    Scheduletemplate.remoteMethod('apply',
        {
            description: 'Задать месяцу типовой - применить типовой месяц с типовым расписанием на день',
            accepts: [
                { 
                    arg: 'year', 
                    type: 'number', 
                    required: true 
                },
                { 
                    arg: 'month', 
                    type: 'number', 
                    required: true 
                },
                { 
                    arg: 'timezone', 
                    type: 'string', 
                    required: false 
                },
                {
                    arg: "options",
                    type: "object",
                    http: "optionsFromRequest"
                },
                { arg: 'res', type: 'object', http: { source: 'res' }},
            ],
            returns: {
                arg: 'schedule',
                type: 'object',
                root: true
            },
            http: {  verb: 'post' }
        }
    );
    

    
    Scheduletemplate.get = async function (options, cb) {
        try {
            const result = await Scheduletemplate.findOrCreate({where: { masterId: options.accessToken.userId, days: {neq: null}}}, { masterId: options.accessToken.userId})
            return result?.[0]
        } catch (err){
            throw err
        }
    }

    Scheduletemplate.remoteMethod('get',
        {
            description: 'Запрос на получения шаблона месяца',
            accepts: [
                {
                    arg: "options",
                    type: "object",
                    http: "optionsFromRequest"
                },
            ],
            returns: {
                arg: 'schedule',
                type: 'object',
                root: true
            },
            http: {  verb: 'get' }
        }
    );


    //OLD VERS
    // Scheduletemplate.upsertMonth = async function (isMonth, days, options, cb) {
    //     const masterId = options.accessToken.userId
    //     try {
    //         const templates = await Scheduletemplate.find({where: {masterId}})
    //         for (let i = 0; i < templates.length; i++) {
    //             await templates[i].days.destroyAll()
    //             await templates[i].destroy()
    //         }
    //         const schedule = await Scheduletemplate.create({ masterId, isMonth })
    //         days = days.filter(day => day.hours.length > 0)
    //         await schedule.days.create(days)
    //     } catch (e) {
    //         throw e
    //     }
    //     return "ok"
    // }

    // Scheduletemplate.remoteMethod('upsertMonth',
    //     {
    //         description: 'Create or update schedule template for master',
    //         accepts: [
    //             {
    //                 arg: 'isMonth',
    //                 type: 'boolean',
    //                 description: "шаблон по дням (true) или по дням недели",
    //                 required: true
    //             },
    //             {
    //                 arg: 'days',
    //                 type: 'array',
    //                 required: true
    //             },
    //             {
    //                 arg: "options",
    //                 type: "object",
    //                 http: "optionsFromRequest"
    //             }
    //         ],
    //         returns: {
    //             arg: 'template',
    //             type: 'object',
    //             root: true
    //         },
    //         http: {
    //             verb: 'post'
    //         }
    //     }
    // );
};
