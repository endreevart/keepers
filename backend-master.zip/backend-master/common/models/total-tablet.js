'use strict';

module.exports = function(Totaltablet) {

};
