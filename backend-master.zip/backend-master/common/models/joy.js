'use strict';

module.exports = function(Joy) {
    Joy.observe('after save', async function (ctx, next) {
        if (ctx.isNewInstance) {
            //для первой добавленной радости - +500 баллов пользователю
            const userJoy = await Joy.findOne({where: {userId: ctx.instance.userId, id: {neq: ctx.instance.id}}}) 
            if (!userJoy) {
                const user = await Joy.app.models.user.findById(ctx.instance.userId)
                await user.updateAttribute("level_points", user.level_points + 500)
            }
        }
    })
};
