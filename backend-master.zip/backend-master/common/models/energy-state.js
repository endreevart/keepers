'use strict';
var moment = require('moment');

module.exports = function(Energystate) {

/**
   * Create energy state with user time
   * 
   * @param {string} userId
   * @param {number} value
   * @param {number} year
   * @param {number} month - where january is 0
   * @param {number} day
   * @param {number} hours
   * @param {number} minutes
   * @param {number} seconds
   * @param {*} cb 
   */
  //создает запись energystate с пользовательским временем
  Energystate.createWithTime = function (userId, value, year, month, day, hours, minutes, seconds, cb) {
    Energystate.create({userId, value, date: new Date(year, month, day, hours, minutes, seconds)}, function(err, result) {
        if (err) throw err;
        cb(null, result)
    })
  }
    
  Energystate.remoteMethod('createWithTime',
    {
      description: 'Create energy state with user time',
      accepts: [
        {
          arg: 'userId',
          type: 'string',
          required: true
        },
        {
          arg: 'value',
          type: 'number',
          required: true
        },
        {
          arg: 'year',
          type: 'number',
          required: true
        },
        {
          arg: 'month',
          description: 'january is 0',
          type: 'number',
          required: true
        },
        {
          arg: 'day',
          type: 'number',
          required: true
        },
        {
          arg: 'hours',
          type: 'number',
          required: true
        },
        {
          arg: 'minutes',
          type: 'number',
          required: true
        },
        {
          arg: 'seconds',
          type: 'number',
          required: true
        }
      ],
      returns: {
          arg: 'energyStateObject',
          type: 'object',
          root: true
      },
      http: {
          verb: 'post'
      }
    }
  );

/**
   * Returns array of energy state object for a day
   * 
   * @param {string} userId
   * @param {number} year
   * @param {number} month - where january is 0
   * @param {number} day
   * @param {*} cb 
   */
  //по следующим параметрам возвращает массив объектов energy state за день
  Energystate.getDay = function (userId, year, month, day, cb) {
    const start = new Date(year, month, day);
    const end = moment(start).endOf('day').toDate();console.log('start', start, end)
    Energystate.find({where: {
        userId: userId, 
        date: {between: [start, end]}
    }}, function(err, result) {
        if (err) throw err;
        cb(null, result)
    })
  }
    
  Energystate.remoteMethod('getDay',
    {
      description: 'Returns array of energy states for a day',
      accepts: [
        {
          arg: 'userId',
          type: 'string',
          required: true
        },
        {
          arg: 'year',
          type: 'number',
          required: true
        },
        {
          arg: 'month',
          description: 'january is 0',
          type: 'number',
          required: true
        },
        {
          arg: 'day',
          type: 'number',
          required: true
        }
      ],
      returns: {
          arg: 'energyStateObjects',
          description: 'array of all energy states for a day',
          type: 'object',
          root: true
      },
      http: {
          verb: 'post'
      }
    }
  );

  /**
   * Returns object of average energy state for each day for a week
   * 
   * @param {string} userId
   * @param {number} year
   * @param {number} month - where january is 0
   * @param {number} day
   * @param {*} cb 
   */
  //по следующим параметрам возвращает среднее значение энергетического баланса за каждый день в течении недели
  Energystate.getWeek = function (userId, year, month, day, cb) {
    const currentDate = new Date(year, month, day);
    const start = moment(currentDate).startOf('isoWeek').toDate();//понедельник
    const end = moment(currentDate).endOf('isoWeek').toDate();//воскресенье
    Energystate.find({where: {
        userId: userId, 
        date: {between: [start, end]}
    }}, function(err, result) {
        if (err) throw err;
        let answer = {};
        //для каждой даты
        result.map(state => {
            const datestring = new Date(state.date).getDay();
            answer[datestring] ? (answer[datestring].num++, answer[datestring].sum += state.value) : (answer[datestring] = {num: 1, sum: state.value});
        })
        //среднее каждого энергетического баланса за день недели
        for (let key in answer) {
            answer[key] = answer[key].sum / answer[key].num;
        }
        cb(null, answer)
    })
  }
    
  Energystate.remoteMethod('getWeek',
    {
      description: 'Returns object of average energy state for each day for a week',
      accepts: [
        {
          arg: 'userId',
          type: 'string',
          required: true
        },
        {
          arg: 'year',
          type: 'number',
          required: true
        },
        {
          arg: 'month',
          description: 'january is 0',
          type: 'number',
          required: true
        },
        {
          arg: 'day',
          type: 'number',
          required: true
        }
      ],
      returns: {
          arg: 'energyStates',
          description: 'object of all energy states for a week, e.g. {1: 1.5, 4: 5}, there monday is 1, sunday is 0',
          type: 'object',
          root: true
      },
      http: {
          verb: 'post'
      }
    }
  );
  
  /**
   * Returns object of average energy state for each day for a month
   * 
   * @param {string} userId
   * @param {number} year
   * @param {number} month - where january is 0
   * @param {*} cb 
   */
  //по следующим параметрам возвращает среднее значение энергетического баланса за каждый день в течении месяца
  Energystate.getMonth = function (userId, year, month, cb) {
    const start = new Date(year, month);
    const end = moment(start).endOf('month').toDate();
    Energystate.find({where: {
        userId: userId, 
        date: {between: [start, end]}
    }}, function(err, result) {
        if (err) throw err;
        let answer = {};
        //для каждого дня расчет суммы и кол-ва оценок
        result.map(state => {
            const datestring = new Date(state.date).getDate();
            answer[datestring] ? (answer[datestring].num++, answer[datestring].sum += state.value) : (answer[datestring] = {num: 1, sum: state.value});
        })
        //среднее энергетического баланса за день месяца
        for (let key in answer) {
            answer[key] = answer[key].sum / answer[key].num;
        }
        cb(null, answer)
    })
  }
    
  Energystate.remoteMethod('getMonth',
    {
      description: 'Returns object of average energy state for each day for a month',
      accepts: [
        {
          arg: 'userId',
          type: 'string',
          required: true
        },
        {
          arg: 'year',
          type: 'number',
          required: true
        },
        {
          arg: 'month',
          description: 'january is 0',
          type: 'number',
          required: true
        }
      ],
      returns: {
          arg: 'energyStates',
          description: 'object of all energy states for a month, e.g. {1: 1.5, 4: 5}',
          type: 'object',
          root: true
      },
      http: {
          verb: 'post'
      }
    }
  );
    
  /**
   * Returns object of average energy state for each month for a year
   * 
   * @param {string} userId
   * @param {number} year
   * @param {*} cb 
   */
  //по следующим параметрам возвращает среднее значение энергетического баланса за каждый месяц в течении года
  Energystate.getYear = function (userId, year, cb) {
    const start = new Date(year, 0);
    const end = moment(start).endOf('year').toDate();
    Energystate.find({where: {
        userId: userId, 
        date: {between: [start, end]}
    }}, function(err, result) {
        if (err) throw err;
        let answer = {};
        //для каждого месяца расчет суммы и кол-ва оценок
        result.map(state => {
            const datestring = new Date(state.date).getMonth();
            answer[datestring] ? (answer[datestring].num++, answer[datestring].sum += state.value) : (answer[datestring] = {num: 1, sum: state.value});
        })
        //среднее энергетического баланса за месяц
        for (let key in answer) {
            answer[key] = answer[key].sum / answer[key].num;
        }
        cb(null, answer)
    })
  }
    
  Energystate.remoteMethod('getYear',
    {
      description: 'Returns object of average energy state for each month for a year',
      accepts: [
        {
          arg: 'userId',
          type: 'string',
          required: true
        },
        {
          arg: 'year',
          type: 'number',
          required: true
        }
      ],
      returns: {
          arg: 'energyStates',
          description: 'object of all energy states for a year, there january is 0, e.g. {1: 1.5, 4: 5}',
          type: 'object',
          root: true
      },
      http: {
          verb: 'post'
      }
    }
  );
};
