'use strict';
var md5 = require('md5');
var fs = require('fs');
const ffmpeg = require('fluent-ffmpeg');
var ffprobe = require('ffprobe-static');
const ffmpegPath = require('@ffmpeg-installer/ffmpeg').path;
ffmpeg.setFfmpegPath(ffmpegPath);
ffmpeg.setFfprobePath(ffprobe.path);

module.exports = function (Video) {
    Video.delete = function (filePath, fileId, cb) {
        fs.unlink(filePath, fileId, function (err) {
            if (err)
                cb(err);
            else {
                Video.deleteById(fileId, function (err) {
                    if (err)
                        cd(err);
                    else {
                        console.log(`file was deleted: `, fileId);
                        cb(null, 'deleted')
                    };
                })
            }
        });
    };


    Video.remoteMethod('delete',
        {
            description: 'Deletes a file.',
            accepts: [
                {
                    arg: 'filePath',
                    type: 'string',
                    required: true
                },
                {
                    arg: 'fileId',
                    type: 'string',
                    required: true
                }
            ],
            returns: {
                arg: 'fileObject',
                type: 'object',
                root: true
            },
            http: {
                //path: '/files/:file',
                verb: 'delete'
            }
        }
    );

    Video.observe('before save', function (ctx, next) {
        console.log(`ctx.data`, ctx.data);
        if (ctx.isNewInstance) {
            var model = ctx.instance || ctx.data;
            var str = md5(model.containerType + model.containerId + model.name);
            console.log(`str`, str);
            var parts = [];
            parts.push(str.slice(0, 8));
            parts.push(str.slice(8, 12));
            parts.push(str.slice(12, 16));
            parts.push(str.slice(16, 20));
            parts.push(str.slice(20, 32));

            model._id = parts.join('-');
        }
        next();
    });

    var loopback = require('loopback');
    var app = module.exports = loopback();
    var multer = require('multer');
    app.use(multer().any());

    Video.upload = function (type, modelId, description, manyModel, manyFK, req, cb) {//загрузка
//console.log('video uploadtype, modelId, description, manyModel, manyFK, duration',type, modelId, description, manyModel, manyFK, duration)
        let mainDir = __dirname;
        mainDir = mainDir.substr(0, mainDir.lastIndexOf('common'));

        const filename = md5(modelId);
        const origName = req.files[0].originalname
        let path = mainDir + 'static/storage/video';
        let fullPath = '/static/storage/video/' + filename
        let searchquery = {};
        let insertquery = {
            name: origName,
            extension: req.files[0].mimetype,
            description,
            size: Math.round(req.files[0].size / 1024 / 1024 * 1000) / 1000,
        };

        path = mainDir + 'static/storage/' + type + '/' + modelId;
        fullPath = '/static/storage/' + type + '/' + modelId + '/' + origName;
        searchquery.path = fullPath;
        searchquery[type + 'Id'] = modelId;
        insertquery.path = fullPath;
        insertquery[type + 'Id'] = modelId;
        fs.existsSync(path) || fs.mkdirSync(path)

        fs.writeFile(path + '/' + origName, req.files[0].buffer, function (err) {
            if (err) {
                console.log('err1', err);
                cb(null, 'err')
            }
            else {
                let lastIndex = origName.lastIndexOf(".");
                let name2 = origName.substring(0, lastIndex);

                ffmpeg.ffprobe(path + '/' + origName, function(err, videoMeta) {
                    if (err) throw err;                    
                    insertquery.duration = videoMeta.format.duration
                    
                    ffmpeg(path + '/' + origName)
                    .screenshots({
                        timestamps: ['10%'],
                        filename: name2 + '.png',
                        folder: path,
                        size: '320x?'
                    });
                    Video.upsertWithWhere(searchquery, insertquery, function (err, videoObj) {
                        if (err !== null) {
                            console.log('error while uploading!', err);
                            cb(null, 'err');
                        } else {
                            videoObj.thumbnail.create({
                                path: '/static/storage/' + type + '/' + modelId + '/' + name2 + '.png',
                                name:  name2 + '.png'
                            }, function(err, thumbnail) {
                                if (err) throw err
                                if (manyModel) {//связь 1-м
                                    Video.app.models[manyModel].upsertWithWhere({ id: modelId }, { [manyFK]: videoObj.id }, function (err, obj) {
                                        if (err !== null) {
                                            console.log('error while uploading!', err);
                                            cb(null, 'err');
                                        } else {
                                            //console.log('obj', obj)
                                            cb(null, 'ok')
                                        }
                                    })
                                } else {
                                    cb(null, 'ok')
                                }

                            })
                        }
                    });
                })
            }
        })
    };

    Video.remoteMethod('upload',
        {
            description: 'Uploads file.',
            accepts: [
                {
                    arg: 'type',
                    type: 'string',
                    required: true,
                    description: "like in connection"
                },
                {
                    arg: 'modelId',
                    type: 'string',
                    required: true,
                    description: "внешний ключ сущности для записи в видео"
                },
                {
                    arg: 'description',
                    type: 'string'
                },
                {
                    arg: 'manyModel',
                    type: 'string',
                    required: true,
                    description: "название модели если связь м-1"
                },
                {
                    arg: 'manyFK',
                    type: 'string',
                    required: true,
                    description: "название внешнего ключа если связь м-1"
                },
                {
                    arg: 'req',
                    type: 'object',
                    'http': {
                        source: 'req'
                    }
                },
            ],
            returns: {
                arg: 'fileObject',
                type: 'object',
                root: true
            },
            http: {
                verb: 'post'
            }
        }
    );
};
