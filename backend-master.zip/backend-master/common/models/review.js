'use strict';

module.exports = function (Review) {

    Review.observe('before save', async function (ctx, next) {
        if (ctx.isNewInstance) {
            ctx.instance.userId = ctx.options?.accessToken?.userId;
        }
    })

    Review.observe('after save', async function (ctx, next) {
        if (ctx.isNewInstance) {//при создании отзыва - обновлять рейтинг
            try {
                let model
                if (ctx.instance.consultationId) {
                    model = await Review.app.models.Consultation.findById(ctx.instance.consultationId, { include: 'reviews' })
                } else if (ctx.instance.materialId) {
                    model = await Review.app.models.Material.findById(ctx.instance.materialId, { include: 'reviews' })
                } else {
                    var err = new Error("not_found");
                    err.statusCode = 404;
                    throw err
                }
                const modelObj = JSON.parse(JSON.stringify(model))
                const sum = modelObj?.reviews?.reduce((prev, review) => prev + review?.value, 0)
                model.updateAttributes({ "averageRate": sum / (modelObj?.reviews?.length), "reviewNum": modelObj?.reviews?.length })
            } catch (err) { throw err }
        }
    })

    Review.getMasterNumber = async function (options, cb) {
        try {
            let user = await Review.app.models.user.findById(options.accessToken.userId,
                {
                    include: [
                        { relation: "consultations", scope: { fields: ['reviewNum', 'masterId', 'id'], include: { relation: "reviews", scope: { fields: ['consultationId', 'id'] } } } },
                        { relation: "library", scope: { fields: ['reviewNum', 'masterId', 'id'], include: { relation: "reviews", scope: { fields: ['materialId', 'id'] } } } },
                    ],
                    fields: ['id']
                }
            )
            user = JSON.parse(JSON.stringify(user));
            const consultationNum = user.consultations.reduce((prev, cons) => prev + cons.reviews?.length, 0)
            const libraryNum = user.library.reduce((prev, lib) => prev + lib.reviews?.length, 0)
            return (consultationNum + libraryNum)
        } catch (e) {
            cb(e)
        }
    }

    Review.remoteMethod('getMasterNumber',
        {
            description: 'get number of reviews on masters consultation/materials',
            accepts: [
                {
                    arg: "options",
                    type: "object",
                    http: "optionsFromRequest"
                }
            ],
            returns: {
                arg: 'number',
                type: 'number',
                root: true
            },
            http: { verb: 'get' }
        }
    );



    Review.getMasterList = async function (type, grade, skip, limit, options, cb) {
        try {
            let aggr = [];
            if (grade < 1 || grade > 5) grade = undefined
            else aggr = [{ $match: { value: grade } }]
            if (skip || limit) aggr.push({ "$sort": { "date": -1 } })
            const consultationLookup = {
                $lookup:
                {
                    from: "Consultation",
                    let: { consultationId: "$consultationId" },
                    pipeline: [
                        { $match: { $expr: { $and: [{ $eq: ["$$consultationId", "$_id"] }, { $eq: ["$masterId", options.accessToken.userId] }] } } },
                        { $project: { _id: 1, created: 1, masterId: 1, id: "$_id"/*, date: 1, userId: 1 */ } }
                    ],
                    as: "consultation"
                }
            }
            const materialLookup = {
                $lookup:
                {
                    from: "Material",
                    let: { materialId: "$materialId" },
                    pipeline: [
                        { $match: { $expr: { $and: [{ $eq: ["$$materialId", "$_id"] }, { $eq: ["$masterId", options.accessToken.userId] }] } } },
                        { $project: { _id: 1, created: 1, masterId: 1, id: "$_id", /*date: 1, userId: 1 */ } }
                    ],
                    as: "material"
                }
            }
            switch (type) {
                case "consultation": {
                    aggr = aggr.concat([
                        consultationLookup,
                        { $unwind: { path: "$consultation", preserveNullAndEmptyArrays: true } },
                        { $match: { "consultation": {$exists: true}} },
                    ])
                    break;
                }
                case "material": {
                    aggr = aggr.concat([
                        materialLookup,
                        { $unwind: { path: "$material", preserveNullAndEmptyArrays: true } },
                        { $match: { "material": {$exists: true}} },
                    ])
                    break;
                }
                default: {
                    aggr = aggr.concat([
                        consultationLookup,
                        { $unwind: { path: "$consultation", preserveNullAndEmptyArrays: true } },
                        //{ $match: { $expr: { $eq: ["$consultationId", "$consultation._id"] } } },
                        materialLookup,
                        { $unwind: { path: "$material", preserveNullAndEmptyArrays: true } },
                        //{ $match: { $expr: { $or: [{ $eq: ["$consultationId", "$consultation._id"] }, { $eq: ["$materialId", "$material._id"] }] } } },
                    ])
                }
            }
            if (skip) aggr.push({ "$skip": skip })
            if (limit) aggr.push({ "$limit": limit })
            aggr.push({ $addFields: { "id": "$_id" } })

            let mongoConnector = Review.app.dataSources.mongodb.connector;
            let reviewsId = await mongoConnector.collection("Review").aggregate(aggr).map(x => x._id).toArray();
            const reviews = await Review.find({
                where: { id: { inq: reviewsId } }, include: [{
                    "relation": "user",
                    "scope": {
                        "include": ["image"]
                    }
                },
                { "relation": "consultation", "scope": { "include": ["image"] } },
                {
                    "relation": "material", "scope": {
                        "include": ["cover",
                            { "relation": "video", "scope": { "include": "thumbnail" } }
                        ]
                    }
                }],
                order: "date DESC"
            })

            return reviews
        } catch (e) {
            throw e
        }
    }

    Review.remoteMethod('getMasterList',
        {
            description: 'get list of masters reviews',
            accepts: [
                { arg: 'type', type: 'string', required: true, description: 'consultation/material/any other == all' },
                { arg: 'grade', type: 'number', required: true, description: '1/2/3/4/5/any other == all' },
                { arg: 'skip', type: 'number', required: false },
                { arg: 'limit', type: 'number', required: false },
                {
                    arg: "options",
                    type: "object",
                    http: "optionsFromRequest"
                }
            ],
            returns: {
                arg: 'reviews',
                type: 'array',
                root: true
            },
            http: { verb: 'get' }
        }
    );
};
