'use strict';

module.exports = function(Mentalcardquality) {

};
