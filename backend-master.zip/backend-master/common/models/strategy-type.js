'use strict';

module.exports = function(Strategytype) {

};
