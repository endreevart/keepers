/* eslint comma-dangle: ["error", "never"] */
'use strict';

var md5 = require('md5');

module.exports = function (attachment) {

  attachment.upload = function (containerType, containerId, req, cb) {//запись вложений на сервер
    req.params.container = containerType + '_' + containerId;
    attachment.app.models.container.createContainer({ name: req.params.container }, function () {
      //attachment.app.models.container.upload(req, {}, function (err, fileObj) {
      let mainDir = __dirname;
      mainDir = mainDir.substr(0, mainDir.lastIndexOf('common'));
      fs.writeFile(mainDir + 'server/storage/'+req.params.container +'/' + req.files[0].originalname, req.files[0].buffer, function (err) {
        if (err) {console.log('err1')
          cb(null, 'err');
        } else {
          //var fileInfo = fileObj.files.file[0];
          
          attachment.upsertWithWhere({
            name: req.files[0].originalname,//fileInfo.name,
            type: req.files[0].mimetype,//fileInfo.type,
            local: false,
            containerId: containerId,
            containerType: containerType
          }, {
            name: req.files[0].originalname,//fileInfo.name,
            type: req.files[0].mimetype,//fileInfo.type,
            local: false,
            containerId: containerId,
            containerType: containerType,
            date: new Date(),
            size: req.files[0].size//fileInfo.size
          }, function (err, obj) {
            if (err !== null) {
              console.log('error while uploading!');
              cb(null, 'err');
            } else {
              console.log('no error, successful uploaded obj', obj);
              cb(null, 'ok');
            }
          });
        }
      });
    });
  };
  attachment.download = function (containerType, containerId, file, ctx, res, cb) {
    ctx.req.params.container = containerType + '_' + containerId;
    attachment.app.models.container
      .download(ctx.req.params.container, file, ctx.req, res, function (err) {
        if (err) cb(err);
      });
  };

  attachment.delete = function (containerType, containerId, fileName, fileId, req, cb) {
    req.params.container = containerType + '_' + containerId;
    attachment.app.models.container.removeFile(req.params.container, fileName, function (err) {
      if (err)
        cb(err);
      else {
        /*attachment.deleteAll({
          name: fileName,
          containerId: containerId,
          containerType: containerType}, function (err) {
          if (err)
            cb(err);
          else {console.log(`file was deleted: `,file);
            cb(null, 'deleted')
          };
        })*/
        attachment.deleteById(fileId, function (err) {
          if (err)
            cd(err);
          else {
            console.log(`file was deleted: `, fileName);
            cb(null, 'deleted')
          };
        })
      }
    });
  };


  attachment.remoteMethod('upload',
    {
      description: 'Uploads a file.',
      accepts: [
        {
          arg: 'containerType',
          type: 'string',
          required: true
        },
        {
          arg: 'containerId',
          type: 'string',
          required: true
        },
        {
          arg: 'req',
          type: 'object',
          'http': {
            source: 'req'
          }
        },
        /*{
          arg: 'ctx',
          type: 'object',
          http: {
            source: 'context'
          }
        }*/
      ],
      returns: {
        arg: 'fileObject',
        type: 'object',
        root: true
      },
      http: {
        verb: 'post'
      }
    }
  );
  attachment.remoteMethod('download',
    {
      description: 'Downloads a file.',
      accepts: [
        {
          arg: 'containerType',
          type: 'string',
          required: true
        },
        {
          arg: 'containerId',
          type: 'string',
          required: true
        },
        {
          arg: 'file',
          type: 'string',
          required: true
        },
        {
          arg: 'ctx',
          type: 'object',
          http: {
            source: 'context'
          }
        },
        {
          arg: 'res',
          type: 'object',
          http: {
            source: 'res'
          }
        }
      ],
      returns: {
        type: 'file'
      },
      http: {
        path: '/download/:file',
        verb: 'get'
      }
    }
  );
  attachment.remoteMethod('delete',
    {
      description: 'Deletes a file.',
      accepts: [
        {
          arg: 'containerType',
          type: 'string',
          required: true
        },
        {
          arg: 'containerId',
          type: 'string',
          required: true
        },
        {
          arg: 'fileName',
          type: 'string',
          required: true
        },
        {
          arg: 'fileId',
          type: 'string',
          required: true
        },
        {
          arg: 'req',
          type: 'object',
          'http': {
            source: 'req'
          }
        }
      ],
      returns: {
        arg: 'fileObject',
        type: 'object',
        root: true
      },
      http: {
        //path: '/files/:file',
        verb: 'delete'
      }
    }
  );

  attachment.observe('before save', function (ctx, next) {
    console.log(`ctx.data`, ctx.data);
    if (ctx.isNewInstance) {
      var model = ctx.instance || ctx.data;
      var str = md5(model.containerType + model.containerId + model.name);
      console.log(`str`, str);
      var parts = [];
      parts.push(str.slice(0, 8));
      parts.push(str.slice(8, 12));
      parts.push(str.slice(12, 16));
      parts.push(str.slice(16, 20));
      parts.push(str.slice(20, 32));

      model._id = parts.join('-');
    }
    next();
  });

};
