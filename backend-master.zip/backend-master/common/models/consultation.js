'use strict';

module.exports = function (Consultation) {

    Consultation.validate('maxDuration', 
        function (err) { if (this.maxDuration == 0 || this.maxDuration < -1) err(); }, 
        {message: 'maxDuration must have value above zero or -1'})
    Consultation.validate('costUnit', 
        function (err) { if (this.costUnit == 0 || this.costUnit < -1) err(); }, 
        {message: 'costUnit must have value above zero or -1'})

    /**
   * Returns consultations with filtering by rubrics
   * @param {string[]} rubrics названия рубрик
   * @param {string} search по названию и описанию consultation
   * @param {boolean} draft статус task
   * @param {number} order сортировка по полю created 
   * @param {*} cb
   */
    Consultation.getByRubrics = function (rubrics, search, draft, isPlayer, order, skip = 0, limit, options, cb) {
        let searchFilter = isPlayer ? {} : { masterId: options.accessToken.userId }
        if (search) {
            searchFilter['or'] = [
                { name: { like: new RegExp(search, "i") } },
                { shortDescription: { like: new RegExp(search, "i") } }
            ]
        }

        let rubricFilter = ["image",{"relation":"master","scope":{"include":["image"]}}]

        //if (isPlayer) searchFilter.draft = false
        if (draft !== undefined && draft !== null) searchFilter.draft = draft
        if (rubrics.length > 0) rubricFilter.push({ relation: 'rubrics', scope: { where: { name: { inq: rubrics } } } })

        Consultation.find({ 
            where: searchFilter, 
            include: rubricFilter, 
            order: (order > 0) ? "created ASC" : "created DESC", 
            skip: (skip && (rubrics.length == 0)) ? skip : undefined,
            limit: (limit && (rubrics.length == 0)) ? limit : undefined,
        }, function (err, items) {
            if (err) throw err;
            if (rubrics.length > 0) {
                items = JSON.parse(JSON.stringify(items))
                let filteredItems = []
                let skipCount = 0
                for (let item of items) {
                    if (item.rubrics?.length > 0 && skipCount >= skip)
                        filteredItems.push(item)
                    else if (item.rubrics?.length > 0)
                        skipCount++
                    if (limit && filteredItems.length == limit) break
                }
                items = filteredItems
            }
            cb(null, items)
        })
    }

    Consultation.remoteMethod('getByRubrics',
        {
            description: 'Returns consultations with filtering by rubrics',
            accepts: [
                {
                    arg: 'rubrics',
                    type: 'array',
                    required: true
                },
                {
                    arg: 'search',
                    type: 'string',
                    description: "поиск по названию и краткому описанию",
                    required: false
                },
                {
                    arg: 'draft',
                    type: 'boolean',
                    required: false
                },
                {
                    arg: 'isPlayer',
                    type: 'boolean',
                    required: false
                },
                {
                    arg: 'order',
                    type: 'number',
                    description: "сортировка по полю created",
                    required: true
                },
                {
                    arg: 'skip',
                    type: 'number',
                    required: false
                },
                {
                    arg: 'limit',
                    type: 'number',
                    required: false
                },
                {
                    arg: "options",
                    type: "object",
                    http: "optionsFromRequest"
                }
            ],
            returns: {
                arg: 'consultations',
                type: 'array',
                root: true
            },
            http: {
                verb: 'get'
            }
        }
    );

    /**
     * По айди находит консультацию и среди других консультаций (мастера, которому принадлежит данная) ищет по рубрикам (указанным в исходной консультации)
     * @param {string} id -required, consultation id
     * @param {number} limit 
     * @param {number} skip 
     * @param {*} cb 
     * @returns 
     */
    Consultation.getSimilar = async function (id, limit, skip, cb) {
        try {
            const consultation = await Consultation.findById(id)

            let mongoConnector = Consultation.app.dataSources.mongodb.connector;
            let rubricIds = await mongoConnector.collection("ConsultationRubric").aggregate([
                { $match: { consultationId: id } },
                {
                    $group:
                    {
                        _id: "$rubricId",
                    }
                }
            ]).map(x => x._id)
                .toArray();

            let aggr = [
                {
                    $match: {
                        rubricId: { "$in": rubricIds },
                        consultationId: { "$ne": id }
                    },
                },
                {
                    $group:
                    {
                        _id: "$consultationId",
                    },
                },
                {
                    $lookup:
                    {
                        from: "Consultation",
                        let: { consultationId: "$_id" },
                        pipeline: [
                            { $match: { $expr: { $and: [{ $eq: ["$$consultationId", "$_id"] }, { $eq: ["$masterId", consultation.masterId] }] } } },
                            { $project: { _id: 1, created: 1, masterId: 1/*, id: "$_id", date: 1, userId: 1 */ } }
                        ],
                        as: "consultation"
                    }
                },
                { $unwind: { path: "$consultation", preserveNullAndEmptyArrays: false } },
                {
                    $match: {
                        "consultation": { "$exists": true },
                    }
                },

            ]
            if (skip || limit) aggr.push({ "$sort": { "consultation.created": 1 } })
            if (skip) aggr.push({ "$skip": skip })
            if (limit) aggr.push({ "$limit": limit })

            aggr = aggr.concat(
                [{
                    $lookup:
                    {
                        from: "Consultation",
                        let: { consultationId: "$_id" },
                        pipeline: [
                            { $match: { $expr: { $and: [{ $eq: ["$$consultationId", "$_id"] }] } } },

                            {
                                $lookup: {
                                    from: "image",
                                    let: { consultationId: "$$consultationId" },
                                    pipeline: [
                                        { $match: { $expr: { $eq: ["$$consultationId", "$consultationId"] } } },
                                        { $addFields: { "id": "$_id" } },
                                    ],
                                    as: "image"
                                }
                            },
                            { $unwind: { path: "$image", preserveNullAndEmptyArrays: true } },

                            {
                                $lookup: {
                                    from: "user",
                                    let: { masterId: "$masterId" },
                                    pipeline: [
                                        { $match: { $expr: { $eq: ["$$masterId", "$_id"] } } },
                                        { $addFields: { "id": "$_id" } },

                                        {
                                            $lookup: {
                                                from: "image",
                                                let: { masterId: "$$masterId" },
                                                pipeline: [
                                                    { $match: { $expr: { $eq: ["$$masterId", "$userId"] } } },
                                                    { $addFields: { "id": "$_id" } },
                                                ],
                                                as: "image"
                                            }
                                        },
                                        { $unwind: { path: "$image", preserveNullAndEmptyArrays: true } },

                                    ],
                                    as: "master"
                                }
                            },
                            { $unwind: { path: "$master", preserveNullAndEmptyArrays: true } },
                            /*{
                            $lookup: {
                              from: "image",
                              let: { masterId: "$masterId" },
                              pipeline: [{ $match: { $expr: { $eq: ["$$masterId", "$userId"] } } },
                              //{ $project: { name: 1, _id: 1, type: 1 } }
                            ],
                              as: "masterImage"
                            }
                          },
                          { $unwind: { path: "$masterImage", preserveNullAndEmptyArrays: true } },*/


                            { $addFields: { "id": "$_id" } },
                        ],
                        as: "consultation"
                    }
                },
                { $unwind: { path: "$consultation", preserveNullAndEmptyArrays: false } },
                ])

            let consultations = await mongoConnector.collection("ConsultationRubric").aggregate(aggr).map(x => x.consultation).toArray();

            return consultations
        } catch (e) { throw e }
    }

    Consultation.remoteMethod('getSimilar',
        {
            description: 'Get similar consultations by rubrics',
            accepts: [
                { arg: 'id', type: 'string', required: true },
                { arg: 'limit', type: 'number', required: false },
                { arg: 'skip', type: 'number', required: false },
            ],
            returns: {
                arg: 'consultations',
                type: 'array',
                root: true
            },
            http: { path: '/:id/getSimilar', verb: 'get' }
        }
    );

    Consultation.materialsIsFavourite = function (id, filter = {}, options, cb) {
        const libFilter = {
            relation: "librarySections", scope: {
                where: { "userId": options.accessToken.userId },
                include: [{ relation: "materialSection", scope: { where: { name: "Избранное" } } }]
            }
        }
        if (filter.draft === undefined || filter.draft === null) filter.draft = false
        if (!filter?.include) {
            filter.include = [libFilter]
        } else {
            filter.include.push(libFilter)
        }
        Consultation.findById(id, function (err, consultation) {
            if (err) throw err
            if (!consultation) {
                var err = new Error("consultation_not_found");
                err.statusCode = 404;
                cb(err)
            } else {
                consultation.materials.find({ ...filter }, function (err, materials) {
                    if (err) throw err

                    materials = JSON.parse(JSON.stringify(materials))
                    materials.forEach(item => {
                        item.isFavourite = item.librarySections.some(section => (section.userId == options.accessToken.userId && section.materialSection?.name == "Избранное"))
                            ? true : false
                        if (!filter.include.includes("librarySections") && !filter.include.find(include => ((include?.relation == "librarySections") && !include?.scope?.where?.userId)))
                            delete item.librarySections
                    });
                    cb(null, materials)
                })
            }
        })
    }

    Consultation.remoteMethod('materialsIsFavourite',
        {
            description: 'Find out if materials belongs to favourite section of user',
            accepts: [
                { arg: 'id', type: 'string', required: true },
                { arg: 'filter', type: 'object', required: false },
                {
                    arg: "options",
                    type: "object",
                    http: "optionsFromRequest"
                }
            ],
            returns: {
                arg: 'materials',
                type: 'array',
                root: true
            },
            http: { path: '/:id/materials/isFavourite', verb: 'get' }
        }
    );
};
