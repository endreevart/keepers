'use strict';

module.exports = function(Eventtype) {

};
