'use strict';

module.exports = function(Wallet) {

};
