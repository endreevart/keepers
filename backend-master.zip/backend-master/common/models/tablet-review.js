'use strict';

module.exports = function(Tabletreview) {

};
