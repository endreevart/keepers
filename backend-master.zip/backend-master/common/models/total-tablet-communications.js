'use strict';

module.exports = function(Totaltabletcommunications) {

};
