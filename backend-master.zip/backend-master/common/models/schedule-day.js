'use strict';

module.exports = function(Scheduleday) {

    Scheduleday.validatesUniquenessOf('masterId');
    Scheduleday.validate('daysFormat', 
        function (err) { 
            const hours = JSON.parse(JSON.stringify(this)).hours
            if (!hours) 
                return err()
            else if (!Array.isArray(hours)) 
                return err()
            else
                for (let hour of hours ) {
                    if (hour.startHour === undefined || hour.startMinute === undefined || hour.endHour === undefined || hour.endMinute === undefined) return err()
                }
        }, 
        {message: 'hours format invalid'})

    Scheduleday.upsertDay = async function ( hours, options, cb) {
        const masterId = options.accessToken.userId
        try {
            await Scheduleday.deleteAll({masterId})
            const schedule = await Scheduleday.create({hours, masterId})
            return schedule
        } catch (e) {
            throw e
        }
    }

    Scheduleday.remoteMethod('upsertDay',
        {
            description: 'Create or update day schedule template for master',
            accepts: [
                {
                    arg: 'hours',
                    type: 'array',
                    required: true
                },
                {
                    arg: "options",
                    type: "object",
                    http: "optionsFromRequest"
                }
            ],
            returns: {
                arg: 'template',
                type: 'object',
                root: true
            },
            http: {
                verb: 'post'
            }
        }
    );


    Scheduleday.changeSlotActivity = async function (startHour, startMinute, endHour, endMinute, options, cb) {
        try {
            let dayTmp = await Scheduleday.findOne({ where: { masterId: options.accessToken.userId } })
            let hours = JSON.parse(JSON.stringify(dayTmp))?.hours
            if (hours?.length > 0) {
                let found = dayTmp.hours.findIndex(slot => (slot.startHour == startHour && slot.startMinute == startMinute
                    && slot.endHour == endHour && slot.endMinute == endMinute))

                let last = hours.length
                if (found == -1)
                    for (let i = 0; i < hours.length; i++) {
                        if ((hours[i].startHour > startHour)
                            || (hours[i].startHour == startHour && (hours[i].startMinute > startMinute))) {
                            last = i
                            break
                        }
                    }
                if (found != -1) {
                    hours.splice(found, 1)
                } else {
                    hours.splice(last, 0, { startHour, startMinute, endHour, endMinute })
                }
            } else if (dayTmp) {
                hours = [{ startHour, startMinute, endHour, endMinute }]
            } else {
                const err = new Error("day template not found")
                err.statusCode = 404
                throw err
            }

            let res = await dayTmp.updateAttribute("hours", hours)
            return res
        } catch (err) {
            throw err
        }
    };


    Scheduleday.remoteMethod('changeSlotActivity',
        {
            description: 'Смена Активности слота типового дня',
            accepts: [
                {
                    arg: 'startHour',
                    type: 'number',
                    required: true
                },
                {
                    arg: 'startMinute',
                    type: 'number',
                    required: true
                },
                {
                    arg: 'endHour',
                    type: 'number',
                    required: true
                },
                {
                    arg: 'endMinute',
                    type: 'number',
                    required: true
                },
                {
                    arg: "options",
                    type: "object",
                    http: "optionsFromRequest"
                }
            ],
            returns: {
                arg: 'scheduleday',
                type: 'object',
                root: true
            },
            http: {
                verb: 'post'
            }
        }
    );
      

    
    Scheduleday.get = async function (options, cb) {
        try {
            const result = await Scheduleday.findOrCreate({where: { masterId: options.accessToken.userId}}, { masterId: options.accessToken.userId})
            return result?.[0]
        } catch (err){
            throw err
        }
    }

    Scheduleday.remoteMethod('get',
        {
            description: 'Запрос на получения шаблона дня',
            accepts: [
                {
                    arg: "options",
                    type: "object",
                    http: "optionsFromRequest"
                },
            ],
            returns: {
                arg: 'schedule',
                type: 'object',
                root: true
            },
            http: {  verb: 'get' }
        }
    );
};
