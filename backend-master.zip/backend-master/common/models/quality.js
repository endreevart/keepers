'use strict';

module.exports = function (Quality) {

    Quality.getMy = function (options, cb) {
        Quality.find({ where:  { userId: { inq: [null, undefined, options.accessToken.userId] } } }, function (err, qualities) {
            if (err) throw err
            cb(null, qualities)
        })
    }

    Quality.remoteMethod('getMy',
        {
            description: 'Find qualities for user',
            accepts: [
                {
                    arg: "options",
                    type: "object",
                    http: "optionsFromRequest"
                }
            ],
            returns: {
                arg: 'qualities',
                type: 'array',
                root: true
            },
            http: { verb: 'get' }
        }
    );
};
