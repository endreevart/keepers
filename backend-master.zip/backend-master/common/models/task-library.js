'use strict';

module.exports = function(Tasklibrary) {

};
