'use strict';

module.exports = function (Mentalcard) {
    Mentalcard.observe('before save', async function (ctx, next) {
        if (!ctx.isNewInstance) {
            ctx.data.updated = new Date()
        }
    })

    Mentalcard.getLast = function (options, cb) {
        Mentalcard.find({
            where: { userId: options.accessToken.userId }, include: ["image", "realSelfImage", "qualities", {
                relation: "qualitiesCondition",
                scope: { include: "quality" }
            }], limit: 1, sort: "DESC updated"
        }, function (err, card) {
            if (err) throw err
            if (card?.length == 0 || card[0].completed) {
                Mentalcard.create({ userId: options.accessToken.userId }, function (err, card) {
                    if (err) throw err
                    cb(null, card)
                })
            } else {
                cb(null, card[0])
            }
        })
    }

    Mentalcard.remoteMethod('getLast',
        {
            description: 'Find last uncompleted mental card of user or create new',
            accepts: [
                {
                    arg: "options",
                    type: "object",
                    http: "optionsFromRequest"
                }
            ],
            returns: {
                arg: 'mentalCard',
                type: 'object',
                root: true
            },
            http: { verb: 'get' }
        }
    );


    Mentalcard.updateQualities = async function (id, mentalCardQualities, complete, options, cb) {
        try {
            const mentalCard = await Mentalcard.findById(id, { include: "qualitiesCondition" })

            if (!mentalCard) {
                var err = new Error("not_found");
                err.statusCode = 404;
                throw err
            } else {
                const qualitiesCondition = JSON.parse(JSON.stringify(mentalCard)).qualitiesCondition || []
                const newQualitiesConditionIds = {}
                mentalCardQualities.forEach(mentalCardQuality => {
                    if (mentalCardQuality.id)
                        newQualitiesConditionIds[mentalCardQuality.id] = mentalCardQuality
                });
                const promises = []
                for (let i = 0; i < qualitiesCondition.length; i++) {
                    //update
                    if (newQualitiesConditionIds[qualitiesCondition[i].id]) {
                        promises.push(Mentalcard.app.models.MentalCardQuality.upsertWithWhere(
                            { id: qualitiesCondition[i].id }, { ...newQualitiesConditionIds[qualitiesCondition[i].id], id: undefined }))
                    } else {
                        promises.push(mentalCard.qualitiesCondition.destroy(qualitiesCondition[i].id))
                    }
                }
                mentalCardQualities.forEach(mentalCardQuality => {
                    if (!mentalCardQuality.id && mentalCardQuality.qualityId) {//upd
                        // promises.push(mentalCard.qualitiesCondition.create({
                        //         qualityId: qualityObj.id,
                        //         //mentalCardId: quality.mentalCardId,
                        //         hasIt: qualityObj.hasIt
                        //     }))
                        promises.push(mentalCard.qualitiesCondition.create({ ...mentalCardQuality, id: undefined }))
                    }
                });
                const res = await Promise.all(promises)

                //за первую карту - 500 баллов
                if (complete && !mentalCard.complete) {
                    const num = await Mentalcard.count({ userId: options.accessToken.userId })
                    if (num == 1) {
                        await Mentalcard.app.models.user.addLevelPoints(options.accessToken.userId, 500)
                        await mentalCard.updateAttribute("completed", true)
                    }
                }

                return res
            }

        } catch (err) {
            throw err
        }
    }

    Mentalcard.remoteMethod('updateQualities',
        {
            description: 'update mental card',
            accepts: [
                { arg: 'id', type: 'string', required: true },
                { arg: 'mentalCardQualities', type: 'array', required: true },
                { arg: 'complete', type: 'boolean', required: true },
                {
                    arg: "options",
                    type: "object",
                    http: "optionsFromRequest"
                }
            ],
            returns: {
                arg: 'res',
                type: 'object',
                root: true
            },
            http: { path: '/:id/updateQualities', verb: 'post' }
        }
    );
};
