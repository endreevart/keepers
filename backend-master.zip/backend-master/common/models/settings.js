'use strict';

module.exports = function(Settings) {
    
};
