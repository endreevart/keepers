'use strict';

module.exports = function(Librarysection) {

};
