'use strict';

module.exports = function(Tasksection) {
    Tasksection.duplicate = function (id, name, options, cb) {
        Tasksection.findById(id,{include: "tasksLibrary"}, function (err, section) { 
            if (err) throw err
            if (!section) {
                var err = new Error("not_found");
                err.statusCode = 404;
                cb(err)
            } else {
                section = JSON.parse(JSON.stringify(section))
                Tasksection.create({userId: section.userId, name}, function(err, newSection) {
                    if (err) throw err
                    const promises = []
                    section.tasksLibrary.forEach(librarySection => {
                        promises.push(newSection.tasksLibrary.create({taskId: librarySection.taskId, userId: librarySection.userId}))
                    });
                    Promise.all(promises).then(res => {
                        Tasksection.findById(newSection.id,{include: "tasksLibrary"}, function (err, newSection) {
                            if (err) throw err
                            cb(null, newSection)
                        })
                    }, err => {throw err})
                })
            }
        })
    }

    Tasksection.remoteMethod('duplicate',
        {
            description: 'Duplicate section of task',
            accepts: [
                {arg: 'id', type: 'string', required: true},
                {arg: 'name', type: 'string', required: true},
                {
                    arg: "options",
                    type: "object",
                    http: "optionsFromRequest"
                }
            ],
            returns: {
                arg: 'new task section',
                type: 'object',
                root: true
            },
            http: {path: '/:id/duplicate', verb: 'post'}
        }
    );
};
