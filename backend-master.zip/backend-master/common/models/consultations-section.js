'use strict';

module.exports = function(Consultationssection) {

};
