'use strict';

module.exports = function(Myselfstate) {

};
