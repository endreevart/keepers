'use strict';

module.exports = function(Transaction) {

};
