'use strict';

var md5 = require('md5');
var fs = require('fs');
const pathModule = require('path');

module.exports = function (image) {


    image.delete = async function (fileId, cb) {
        try {
            let mainDir = __dirname;
            mainDir = mainDir.substr(0, mainDir.lastIndexOf('common'));
            const imageInst = await image.findById(fileId)
            const fullPath = pathModule.join(__dirname, '../..', imageInst.path)
            fs.unlinkSync(fullPath)//mainDir + imageInst.path)
            await imageInst.destroy()
            return 'ok'
        } catch (e) {
            throw e
        }
        /*fs.unlink(mainDir + filePath, function (err) {
            if (err)
                cb(err);
            else {
                image.deleteById(fileId, function (err) {
                    if (err)
                        cb(err);
                    else {
                        console.log(`file was deleted: `, fileId);
                        cb(null, 'deleted')
                    };
                })
            }
        });*/
    };


    image.remoteMethod('delete',
        {
            description: 'Deletes a file.',
            accepts: [
                // {
                //     arg: 'filePath',
                //     type: 'string',
                //     required: true
                // },
                {
                    arg: 'fileId',
                    type: 'string',
                    required: true
                }
            ],
            returns: {
                arg: 'fileObject',
                type: 'object',
                root: true
            },
            http: {
                //path: '/files/:file',
                verb: 'delete'
            }
        }
    );

    image.observe('before save', function (ctx, next) {
        console.log(`ctx.data`, ctx.data);
        if (ctx.isNewInstance) {
            var model = ctx.instance || ctx.data;
            var str = md5(model.containerType + model.containerId + model.name);
            console.log(`str`, str);
            var parts = [];
            parts.push(str.slice(0, 8));
            parts.push(str.slice(8, 12));
            parts.push(str.slice(12, 16));
            parts.push(str.slice(16, 20));
            parts.push(str.slice(20, 32));

            model._id = parts.join('-');
        }
        next();
    });

    var loopback = require('loopback');
    var app = module.exports = loopback();
    var multer = require('multer');
    app.use(multer().any());

    image.uploadWithCompression = async function (type, modelId, description, manyModel, manyFK, req, cb) {//загрузка со сжатием на сервере
        
        let mainDir = __dirname;
        mainDir = mainDir.substr(0, mainDir.lastIndexOf('common'));

        //console.log('curr', process.cwd())
        const filename = md5(modelId);
        let path = mainDir + 'static/storage/users';
        let fullPath = '/static/storage/users/' + filename
        let searchquery = {};
        let insertquery = {};
        if (type == "user") {
            path = mainDir + 'static/storage/users';
            fullPath = '/static/storage/users/' + filename
            searchquery.path = fullPath;
            searchquery.userId = modelId;
            insertquery.path = fullPath;
            insertquery.userId = modelId;
            if (fs.existsSync(path)) {
                //console.log('ok, exists')
            } else {
                console.log('nope')
                if (fs.mkdirSync(path)) {
                    console.log('ok, created')
                } else {
                    console.log('ok, created')
                }
            }
            //fs.existsSync(path) || fs.mkdirSync(path)
        } else if (type == "tablet") {
            path = mainDir + 'static/storage/tablets/' + modelId;
            fullPath = '/static/storage/tablets/' + modelId + '/' + req.files[0].originalname;
            searchquery.path = fullPath;
            searchquery.tabletId = modelId;
            insertquery.path = fullPath;
            insertquery.tabletId = modelId;
            fs.existsSync(path) || fs.mkdirSync(path)
        } else {
            fs.existsSync(mainDir + 'static/storage/' + type) || fs.mkdirSync(mainDir + 'static/storage/' + type)
            path = mainDir + 'static/storage/' + type + '/' + modelId;
            fullPath = '/static/storage/' + type + '/' + modelId + '/' + req.files[0].originalname;
            searchquery.path = fullPath;
            searchquery[type + 'Id'] = modelId;
            insertquery.path = fullPath;
            insertquery[type + 'Id'] = modelId;
            fs.existsSync(path) || fs.mkdirSync(path)
        }

        try {

            await fs.writeFileSync(path + '/' + req.files[0].originalname, req.files[0].buffer)

            if ((req.files[0].mimetype.indexOf("image/jpeg") == 0)//(req.files[0].mimetype.indexOf("image/gif") == 0) || 
                || (req.files[0].mimetype.indexOf("image/pjpeg") == 0) || (req.files[0].mimetype.indexOf("image/png") == 0)) {//если изображение, то сжимаем
                const imagemin = require('imagemin');//
                const imageminMozjpeg = require('imagemin-mozjpeg');
                const imageminPngquant = require('imagemin-pngquant');

                const files = await imagemin(
                    [path + '/' + req.files[0].originalname
                    ],
                    {
                        destination: path,
                        plugins: [imageminMozjpeg({ quality: 60 }),
                        imageminPngquant({ quality: [0.4, 0.5] })
                        ]
                    }
                );
                insertquery.description = description;
            }

            const imageObj = await image.upsertWithWhere(searchquery, insertquery)

            if (type == "userTask") {//связь м-м
                await imageObj.userTask.add(modelId)//, function (err, obj) {                    
            } else if (manyModel) {
                await image.app.models[manyModel].upsertWithWhere({ id: modelId }, { [manyFK]: imageObj.id })//, function (err, obj) {
            }
            //console.log('no error, successful uploaded obj', obj);
            return 'ok'

        } catch (err) {
            throw err
        }

    };


    image.remoteMethod('uploadWithCompression',
        {
            description: 'Uploads and compress file.',
            accepts: [
                {
                    arg: 'type',
                    type: 'string',
                    required: true
                },
                {
                    arg: 'modelId',
                    type: 'string',
                    required: true
                },
                {
                    arg: 'description',
                    type: 'string'
                },
                {
                    arg: 'manyModel',
                    type: 'string',
                    required: false,
                    description: "название модели если связь м-1"
                },
                {
                    arg: 'manyFK',
                    type: 'string',
                    required: false,
                    description: "название внешнего ключа если связь м-1"
                },
                {
                    arg: 'req',
                    type: 'object',
                    'http': {
                        source: 'req'
                    }
                },
            ],
            returns: {
                arg: 'fileObject',
                type: 'object',
                root: true
            },
            http: {
                verb: 'post'
            }
        }
    );

    image.uploadAvatar = function (options, req, cb) {//загрузка аватарки со сжатием на сервере

        if (options.accessToken && options.accessToken.userId) {
            image.app.models.user.findById(options.accessToken.userId, function (err, userInstance) {
                if (err) throw err;
                if (userInstance && userInstance.id) {

                    let mainDir = __dirname;
                    mainDir = mainDir.substr(0, mainDir.lastIndexOf('common'));
                    let origName = req.files[0].originalname;
                    let newName = userInstance.id.concat(origName.substr(origName.lastIndexOf("."), origName.length));//md5(userInstance.id).concat(origName.substr(origName.lastIndexOf("."), origName.length));
                    //const sha1 = require('sha1');

                    let path = mainDir + 'static/storage/users';//'/var/www/html/storage/users';
                    let fullPath = '/static/storage/users/' + newName;//req.files[0].originalname;
                    let searchquery = {};
                    let insertquery = {};

                    //searchquery.path = fullPath;
                    searchquery.userId = userInstance.id;
                    insertquery.path = fullPath;
                    insertquery.userId = userInstance.id;
                    if (fs.existsSync(path)) {
                        console.log('ok, exists')
                    } else {
                        console.log('nope')
                        if (fs.mkdirSync(path)) {
                            console.log('ok, created')
                        } else {
                            console.log('ok, created')
                        }
                    }
                    //fs.existsSync(path) || fs.mkdirSync(path)
                    const resPath = pathModule.join(path, '/', newName);
                    fs.writeFile(resPath, req.files[0].buffer, function (err) {
                        if (err) {
                            throw err;
                        }
                        else {
                            // if (userInstance.image?.path && userInstance.image?.path != fullPath)
                            //     fs.unlinkSync(pathModule.resolve(mainDir + userInstance.image.path))
                            image.deleteAll({ userId: userInstance.id }, function (err, delRes) {
                                if (err) throw err
                                if ((req.files[0].mimetype.indexOf("image/jpeg") == 0)//(req.files[0].mimetype.indexOf("image/gif") == 0) || 
                                    || (req.files[0].mimetype.indexOf("image/pjpeg") == 0) || (req.files[0].mimetype.indexOf("image/png") == 0)) {//если изображение, то сжимаем

                                    const imagemin = require('imagemin');//
                                    const imageminMozjpeg = require('imagemin-mozjpeg');//
                                    const imageminPngquant = require('imagemin-pngquant');//

                                    (async () => {
                                        const files = await imagemin(
                                            [resPath//req.files[0].originalname;
                                            ],
                                            {
                                                destination: path,//'server/storage/' + req.params.container,
                                                plugins: [imageminMozjpeg({ quality: 60 }),
                                                imageminPngquant({ quality: [0.4, 0.5] })
                                                ]
                                            }
                                        );

                                        insertquery.description = "";//description;
                                        image.upsertWithWhere(searchquery, insertquery, function (err, obj) {
                                            if (err !== null) {
                                                console.log('error while uploading!', err);
                                                cb(null, 'err');
                                            } else {
                                                console.log('no error, successful uploaded obj', obj);
                                                cb(null, 'ok')
                                            }
                                        });
                                    })();
                                } else {
                                    image.upsertWithWhere(searchquery, insertquery, function (err, obj) {
                                        if (err !== null) {
                                            console.log('error while uploading!', err);
                                            cb(null, 'err');
                                        } else {
                                            console.log('no error, successful uploaded obj', obj);
                                            cb(null, 'ok')
                                        }
                                    });
                                }
                            })
                        }
                    })

                    // } else {
                    //     let err = new Error("Error: wrong image type")
                    //     err.statusCode = 415
                    //     cb(err)
                    // }
                } else {
                    let err = new Error("Error: user not found")
                    err.statusCode = 401
                    cb(err)
                }
            })
        } else {
            let err = new Error("Error: no access token")
            err.statusCode = 401
            cb(err)
        }
    };
    image.remoteMethod('uploadAvatar',
        {
            description: 'Uploads and compress user avatar',
            accepts: [
                {
					arg: "options",
					type: "object",
					http: "optionsFromRequest"
				},
                {
                    arg: 'req',
                    type: 'object',
                    'http': {
                        source: 'req'
                    }
                },
            ],
            returns: {
                arg: 'fileObject',
                type: 'object',
                root: true
            },
            http: {
                verb: 'post'
            }
        }
    );


        /**
         * копирование изображения на сервере
         * @param {*} type 
         * @param {*} modelId 
         * @param {*} description 
         * @param {*} manyModel 
         * @param {*} manyFK 
         * @param {*} imageId 
         * @param {*} sourcepath - absolute path
         * @param {*} cb 
         */
    image.copy = async function (type, modelId, description, manyModel, manyFK, imageId, sourcepath, cb) {//копирование изображения на сервере
        
        let mainDir = __dirname;
        mainDir = mainDir.substr(0, mainDir.lastIndexOf('common'));

        try {
            if (!sourcepath && imageId) {
                const sourceImage = await image.findById(imageId)
                sourcepath = sourceImage?.path
            }
            if (!sourcepath) throw Error("image_required")

            let sourcename = sourcepath.split('\\').pop().split('/').pop();
                    
            //const filename = md5(modelId);
            let path = mainDir + 'static/storage/users';
            let fullPath = ''
            let folder = type
            if (type == "user") {
                folder = "users"
                sourcename = md5(modelId);
            } else if (type == "tablet") {
                folder = "tablets"
            }
            fs.existsSync(mainDir + 'static/storage/' + folder) || fs.mkdirSync(mainDir + 'static/storage/' + folder)
            path = mainDir + 'static/storage/' + folder + '/' + modelId;
            fullPath = '/static/storage/' + folder + '/' + modelId + '/' + sourcename;
            const searchquery = {
                path: fullPath,
                [type + 'Id']: modelId,
            }
            const insertquery = {
                path: fullPath,
                [type + 'Id']: modelId,
                description
            }
            fs.existsSync(path) || fs.mkdirSync(path)

            const endPath = pathModule.join(image.app.get("rootfolder"), fullPath)

            var readable = fs.createReadStream(sourcepath, { encoding: 'utf8', highWaterMark: 16 * 1024 });
            var writable = fs.createWriteStream(endPath);

            let stream = readable.pipe(writable);// use pipe to copy readable to writable
            stream.on('finish', async () => {
                const imageObj = await image.upsertWithWhere(searchquery, insertquery)
    
                if (type == "userTask") {//связь м-м
                    await imageObj.userTask.add(modelId)//, function (err, obj) {                    
                } else if (manyModel) {
                    await image.app.models[manyModel].upsertWithWhere({ id: modelId }, { [manyFK]: imageObj.id })//, function (err, obj) {
                }
                return 'ok'
            })

        } catch (err) {
            throw err
        }

    };
};
