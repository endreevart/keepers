'use strict';
const emailModule = require("../../helpers/email.js")

module.exports = function (Feedback) {

    Feedback.observe('before save', function (ctx, next) {
        if (ctx.isNewInstance) {
            if (ctx.instance.type == "app") ctx.instance.userId = ctx.options?.accessToken?.userId;
        }
        next()
    })

    Feedback.observe('after save', async function (ctx, next) {
        if (ctx.isNewInstance) {//при создании feedback - создавать event
            if (ctx.instance.type == "app") {
                const initUser = await Feedback.app.models.user.findById(ctx.instance.userId)
                if (!initUser) {
                    var err = new Error("not_found");
                    err.statusCode = 404;
                    throw err
                } else {
                    emailModule.sendEmail(null, {
                        subject: 'Отзыв на приложение',
                        text: `Пользователь ${initUser.firstname} ${initUser.lastname} (id ${initUser.id}) оставил отзыв: \n${ctx.instance.text}`
                    },
                        true)
                }
            } else {
                let name = ""
                let masterId
                if (ctx.instance.userTaskId) {
                    try {
                        let userTask = await Feedback.app.models.UserTask.findById(ctx.instance.userTaskId, { include: 'task' })
                        userTask = JSON.parse(JSON.stringify(userTask));
                        if (userTask && userTask.task) {
                            name = userTask.task.aim
                            masterId = userTask.task.masterId
                        }
                    } catch (err) { throw err }
                }
                await Feedback.app.models.Event.create({//eventcreate
                    userTaskId: ctx.instance.userTaskId,
                    userId: ctx.instance.userId,
                    masterId: masterId,
                    eventTypeId: "task",
                    description: "Добавлена обратная связь",
                    name,
                    dateComplete: new Date(),
                });
            }
        }
    })
};
