'use strict';

module.exports = function (Masterusers) {
    Masterusers.observe('before save', function (ctx, next) {
        if (ctx.isNewInstance) {
            Masterusers.app.models.user.findById(ctx.instance.userId, function (err, user) {
                if (err) throw err
                ctx.instance.firstname = user.firstname
                ctx.instance.lastname = user.lastname
                next()
            })
        } else {
            next()
        }
    })

    Masterusers.checkUser = function (userId, masterId, userTaskId, userConsultationId) {
        if (userId && masterId) {
            Masterusers.app.models.UserMaster.findOne({ where: { userId, masterId/*, active: true*/ } }, function (err, a) {
                if (err) throw err
                if (a) return true

                let taskWhere = { userId, status: "created" }
                if (userTaskId) taskWhere.id = { neq: userTaskId }
                Masterusers.app.models.UserTask.find({
                    where: taskWhere, include: {
                        relation: 'task', scope: {
                            where: { masterId }, fields: ['masterId']
                        }
                    }
                }, function (err, usertask) {
                    if (err) throw err
                    for (let i = 0; i < usertask.length; i++) {
                        if (usertask[i].task) return true
                    }

                    let consultationWhere = { userId, status: { inq: ["created", "started"] } }
                    if (userConsultationId) consultationWhere.id = { neq: userConsultationId }
                    Masterusers.app.models.UserConsultation.find({
                        where: consultationWhere,
                        include: {
                            relation: 'consultation', scope: {
                                where: { masterId }, fields: ['masterId']
                            }
                        }
                    }, function (err, userConsultation) {
                        if (err) throw err
                        for (let i = 0; i < userConsultation.length; i++) {
                            if (userConsultation[i].consultation) return true
                        }
                        Masterusers.upsertWithWhere({ userId, masterId }, { userId, masterId, active: false }, function (err, b) {
                            if (err) throw err
                            return false
                        })
                    })
                })
            })
        } else {
            return false
        }
    }

    Masterusers.remoteMethod(
        'checkUser',
        {
            description: '',
            accepts: [
                { arg: 'userId', type: 'string', required: true },
                { arg: 'masterId', type: 'string', required: true }
            ],
            returns: {
                arg: 'answ', type: 'boolean', root: true
            },
        },
    );
};
