'use strict';
var moment = require('moment');

module.exports = function (Aimobligation) {
  Aimobligation.observe('after save', async function (ctx, next) {

    if (ctx.isNewInstance) {
      //при добавлении обязательства создавать задание
    const aim = await Aimobligation.app.models.Aim.findById(ctx.instance.aimId, {include: {relation: 'images'/*, scope: {fields: ['id']}*/}})
      let startDate = new moment();
      let endDate = ctx.instance.duration ? startDate.clone().add(ctx.instance.duration, 'days') : undefined;
      const task = await Aimobligation.app.models.Task.create({
        "imageLink": undefined,
        "aim": aim.name,
        "description": ctx.instance.description,
        "requisite": undefined,
        "instruction": undefined,
        "startDate": startDate,
        "endDate": endDate,
        "bonus": undefined,
        "draft": false,
        "type": "aimObligation",
        "periodicity": ctx.instance.periodicity,
        "duration": ctx.instance.duration,
        "forCheck":false // задание, созданное на основе aimObligation не должно проверяться
      })
      let taskStart = 0;
      const aimObj = JSON.parse(JSON.stringify(aim));
      if (aimObj.images?.id)
         await task.images.create({...aimObj.images, id: undefined})
      if (ctx.instance.duration && ctx.instance.periodicity) {
        //задания создаются по периодичности и продолжительности обязательства
        while (taskStart < ctx.instance.duration) {
          const endTimeUT = (taskStart + ctx.instance.periodicity <= ctx.instance.duration) ? startDate.clone().add(ctx.instance.periodicity, 'days') : endDate
          const userTask = await Aimobligation.app.models.UserTask.create({
            "startDate": startDate,
            "endDate": endTimeUT,
            //"status": ,
            "userId": aim.userId,
            "taskId": task.id
          })
          if (aimObj.images?.id)
            await userTask.images.add(aimObj.images.id)
          startDate.add(ctx.instance.periodicity, 'days')
          taskStart += ctx.instance.periodicity;
        }
      } else {
        const userTask = await Aimobligation.app.models.UserTask.create({
          "startDate": startDate,
          "endDate": endDate,
          //"status": ,
          "userId": aim.userId,
          "taskId": task.id
        })
        if (aimObj.images?.id)
          await userTask.images.add(aimObj.images.id)
      }
    }
    //next()
  })
};
