'use strict';

module.exports = function (CaseType) {
}