'use strict';

module.exports = function(Todayresource) {

};
