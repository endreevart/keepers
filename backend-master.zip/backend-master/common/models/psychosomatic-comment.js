'use strict';

module.exports = function(Psychosomaticcomment) {

};
