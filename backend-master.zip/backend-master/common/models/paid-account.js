'use strict';

module.exports = function(PaidAccount) {
    PaidAccount.validatesUniquenessOf('userId');
};
