'use strict';
var md5 = require('md5');
var fs = require('fs');

module.exports = function(File) {
    File.delete = function (filePath, fileId, cb) {
        fs.unlink(filePath, fileId, function (err) {
            if (err)
                cb(err);
            else {
                File.deleteById(fileId, function (err) {
                    if (err)
                        cd(err);
                    else {
                        console.log(`file was deleted: `, fileId);
                        cb(null, 'deleted')
                    };
                })
            }
        });
    };


    File.remoteMethod('delete',
        {
            description: 'Deletes a file.',
            accepts: [
                {
                    arg: 'filePath',
                    type: 'string',
                    required: true
                },
                {
                    arg: 'fileId',
                    type: 'string',
                    required: true
                }
            ],
            returns: {
                arg: 'fileObject',
                type: 'object',
                root: true
            },
            http: {
                //path: '/files/:file',
                verb: 'delete'
            }
        }
    );

    File.observe('before save', function (ctx, next) {
        console.log(`ctx.data`, ctx.data);
        if (ctx.isNewInstance) {
            var model = ctx.instance || ctx.data;
            var str = md5(model.containerType + model.containerId + model.name);
            console.log(`str`, str);
            var parts = [];
            parts.push(str.slice(0, 8));
            parts.push(str.slice(8, 12));
            parts.push(str.slice(12, 16));
            parts.push(str.slice(16, 20));
            parts.push(str.slice(20, 32));

            model._id = parts.join('-');
        }
        next();
    });

    var loopback = require('loopback');
    var app = module.exports = loopback();
    var multer = require('multer');
    app.use(multer().any());

    File.upload = function (fileType, type, modelId, description, manyModel, manyFK, req, cb) {//загрузка
        //console.log('file.upload',modelId)
        let mainDir = __dirname;
        mainDir = mainDir.substr(0, mainDir.lastIndexOf('common'));

        const filename = md5(modelId);
        let path = mainDir + 'static/storage/file';
        let fullPath = '/static/storage/file/' + filename
        let searchquery = {};
        let insertquery = {
            name: req.files[0].originalname,
            mime: req.files[0].mimetype,
            description,
            size: Math.round(req.files[0].size / 1024 / 1024 * 1000) / 1000,
            type: fileType,
        };

        path = mainDir + 'static/storage/' + type + '/' + modelId;
        fullPath = '/static/storage/' + type + '/' + modelId + '/' + req.files[0].originalname;
        searchquery.path = fullPath;
        searchquery[type + 'Id'] = modelId;
        insertquery.path = fullPath;
        insertquery[type + 'Id'] = modelId;
        fs.existsSync(path) || fs.mkdirSync(path)


        fs.writeFile(path + '/' + req.files[0].originalname, req.files[0].buffer, function (err) {
            if (err) {
                console.log('err1', err);
                cb(null, 'err')
            }
            else {
                //insertquery.
                File.upsertWithWhere(searchquery, insertquery, function (err, fileObj) {
                    if (err !== null) {
                        console.log('error while uploading!', err);
                        cb(null, 'err');
                    } else {
                        if (manyModel) {//связь 1-м
                            File.app.models[manyModel].upsertWithWhere({ id: modelId }, { [manyFK]: fileObj.id }, function (err, obj) {
                                if (err !== null) {
                                    console.log('error while uploading!', err);
                                    cb(null, 'err');
                                } else {
                                    // console.log('obj', obj)
                                    cb(null, 'ok')
                                }
                            })
                        } else {
                            cb(null, 'ok')
                        }
                    }
                });
            }
        })
    };

    File.remoteMethod('upload',
        {
            description: 'Uploads file.',
            accepts: [
                {
                    arg: 'fileType',
                    type: 'string',
                    required: true,
                    description: "тип файла - image/text/audio/..."
                },
                {
                    arg: 'type',
                    type: 'string',
                    required: true,
                    description: "like in connection"
                },
                {
                    arg: 'modelId',
                    type: 'string',
                    required: true,
                    description: "внешний ключ сущности для записи в файл"
                },
                {
                    arg: 'description',
                    type: 'string'
                },
                {
                    arg: 'manyModel',
                    type: 'string',
                    required: false,
                    description: "название модели если связь м-1"
                },
                {
                    arg: 'manyFK',
                    type: 'string',
                    required: false,
                    description: "название внешнего ключа если связь м-1"
                },
                {
                    arg: 'req',
                    type: 'object',
                    'http': {
                        source: 'req'
                    }
                },
            ],
            returns: {
                arg: 'fileObject',
                type: 'object',
                root: true
            },
            http: {
                verb: 'post'
            }
        }
    );
};
