'use strict';
const path = require('path');
require('dotenv').config({ path: path.resolve(__dirname, '../.env') })
const mailer = require('nodemailer');
const from_email = process.env.email;
const from_email_pass = process.env.emailPass;
const default_email = process.env.defaultEmail;
const email_service = process.env.emailService;
const email_host = process.env.emailHost;
const email_port = process.env.emailPort;
const email_secure = process.env.emailSecure;
const email_tls = process.env.emailTls;
const app = require('../server/server.js');


module.exports = {
    /**
     * Sends email to users
     * @param {string[]} emails - array of email
     * @param {object} data - additional data. {subject, text, html}
     * @param {boolean} defaultEmail - use default admin email
     */
    sendEmail: function (emails, { subject, text, html }, defaultEmail) {
        //console.log('emails', emails)
        return new Promise((resolve, reject) => {
            let toEmail = (defaultEmail) ? [default_email] : emails
            if (toEmail.length > 0) {
                const options = {
                    host: email_host,
                    port: email_port,
                    secure: email_secure,
                    service: email_service,
                    tls: email_tls,
                    auth: {
                        user: from_email,
                        pass: from_email_pass,
                    }
                }
                //console.log("options", options)

                var transporter = mailer.createTransport(options);
                const mailOptions = {
                    from: from_email,
                    to: toEmail,
                    subject: subject,
                    text: text,
                    html: html,
                    //context: message.context,
                    //generateTextFromHTML: message.generateTextFromHTML,
                    //attachments: message.attachments,
                }
                //console.log("mailOptions", mailOptions)        

                // send mail with defined transport object
                //console.log(`mailOptions_email`, mailOptions);
                transporter.sendMail(mailOptions, function (error, info) {
                    if (error) {
                        reject(error);
                    }
                    console.log('Message sent: %s', info.messageId);
                    resolve(info)
                });
            } else {
                resolve({ emails: true })
            }
        })
    },

    //to check
    sendEmailToUser: function (userIds, data) {
        console.log('sendPushToUser', userIds)
        return new Promise((resolve, reject) => {
            if (userIds?.length > 0) { //console.log('app.models', await app.models, app.models.user)
                app.models.user.find({ where: { id: { inq: userIds }, email: { nin: [undefined, null, ''] } } }, function (err, users) {
                    if (err) throw err;
                    //console.log('user', user, user.pushId)
                    const emails = users?.map(user => user.email) || []
                    if (emails.length > 0) {
                        resolve(sendEmail(emails, data, null))
                    } else {
                        resolve({ noemails: true })
                    }
                })
            } else {
                resolve({ noUserId: true })
            }
        })
    }
}