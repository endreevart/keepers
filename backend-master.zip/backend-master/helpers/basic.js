'use strict';
var moment = require('moment');
var momentTz = require('moment-timezone');
const app = require('../server/server.js');


module.exports = {
    /**получить время в заданном часовом поясе
     * 
     * @param {moment} date 
     * @param {string} timezone 
     * @returns {moment} date
     */
    getTZdate: function (date, timezone) {
        const currDate = date.utc()//new moment(date.format('YYYY-MM-DDTHH:mm:ss:SSS'), "YYYY-MM-DDTHH:mm:ss:SSS").utc()
        const timezoneOffset = currDate.valueOf() - new moment.utc(momentTz.tz(currDate, timezone)
            .format('YYYY-MM-DDTHH:mm:ss:SSS'), "YYYY-MM-DDTHH:mm:ss:SSS").valueOf();
        const currTimeUtc = new moment.utc([currDate.year(), currDate.month(), currDate.date(), currDate.hour(), currDate.minute(), currDate.second()])
        return moment(moment(currTimeUtc).valueOf() + timezoneOffset)
    }
}