'use strict';
// const path = require('path');
// require('dotenv').config({ path: path.resolve(__dirname, '../.env') })
const app = require('../server/server.js');


module.exports = {
    /**
     * Change connection of related models - hasAndBelongsToMany
     * @param {string} model1 - 
     * @param {string} relation -  
     * @param {string} modelId -
     * @param {string[]} newIds - 
     */
    hasAndBelongsToManyChange: function (model1, relation, modelId, newFKIds) {
        return new Promise((resolve, reject) => {
            app.models[model1].findById(modelId, { include: relation }, function (err, modelInst) {
                if (err) throw err
                if (!modelInst) {
                    var err = new Error("not_found");
                    err.statusCode = 404;
                    reject(err)
                } else {
                    const oldRelations = JSON.parse(JSON.stringify(modelInst))[relation]

                    const promises = []
                    const oldRelationIds = oldRelations.map(item => item.id)
                    oldRelations.forEach(item => {
                        if (!newFKIds.includes(item.id)) {
                            promises.push(
                                modelInst[relation].remove(item.id)
                            )
                        }
                    })
                    newFKIds.forEach(itemId => {
                        if (!oldRelationIds.includes(itemId))
                            promises.push(
                                modelInst[relation].add(itemId)
                            )
                    })
                    Promise.all(promises).then(res => {
                        resolve(res)
                    }, err => { throw err; })
                }
            })
        })
    },

    hasAndBelongsToManyChangeR: function (model1, relation, modelId, newFKIds) {
        return new Promise((resolve, reject) => {
            app.models[model1].findById(modelId, { include: relation }, function (err, modelInst) {
                if (err) throw err
                if (!modelInst) {
                    var err = new Error("not_found");
                    err.statusCode = 404;
                    reject(err)
                } else {
                    modelInst[relation].destroyAll(function (err, removed) {
                        if (err) throw err

                        const promises = []
                        promises.push(
                            modelInst[relation].destroyAll()
                        )
                        newFKIds.forEach(itemId => {
                            promises.push(
                                modelInst[relation].add(itemId)
                            )
                        })
                        Promise.all(promises).then(res => {
                            resolve(res)
                        }, err => { throw err; })
                    })
                }
            })
        })
    },
}