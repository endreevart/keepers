'use strict';
var admin = require("firebase-admin");
const app = require('../server/server.js');

const nullifyToken = {
    'messaging/invalid-registration-token': true,
    'messaging/registration-token-not-registered': true,//after delete app
}

module.exports = {
    //https://firebase.google.com/docs/cloud-messaging/send-message#admin  error codes

    /**
     * Sends push to users
     * @param {string[]} registrationTokens - array of push id
     * @param {object} data - additional data for push, e.g. {ticketId: ticket.id}
     */
    sendPush: function (registrationTokens, data, data2) {
        console.log('sendPush', registrationTokens)
        //console.log('data1', data)
        return new Promise((resolve, reject) => {

            if (registrationTokens.length > 0) {
                const message = {
                    notification: data,
                    data: data2,
                    tokens: registrationTokens,
                    apns: {
                        headers: {
                            'apns-push-type': 'alert',
                        },
                        payload: {
                            aps: {
                                badge: 1,
                                sound: 'default',
                            },
                        },
                    },
                };
                admin.messaging().sendMulticast(message)
                    .then((response) => {
                        //есть пуши с ошибкой отправки
                        if (response.failureCount) {
                            const usersToDelete = []
                            response.responses.forEach((item, i) => {
                                if ((item.success === false)
                                    && ((item.error?.errorInfo?.code == 'messaging/invalid-argument'
                                        && item.error?.errorInfo?.message == 'The registration token is not a valid FCM registration token')
                                        || nullifyToken[item.error?.errorInfo?.code]))
                                    usersToDelete.push(registrationTokens[i])

                                console.log('pushId err', item.error)//item.error?.errorInfo?.code)
                            })
                            app.models.user.updateAll({ pushId: { inq: usersToDelete } }, { pushId: null })
                        }
                        resolve(response);
                    }, err => {
                        // console.log('errorcode', err.errorInfo?.code)
                        // if (err.errorInfo?.code == 'messaging/invalid-argument')
                        console.log('err1', err)
                        reject(err)
                    });

            } else {
                resolve({ noPushIds: true })
            }
        })
    },

    /**
     * Sends push to one user
     * @param {string} registrationToken - push id
     * @param {object} data - additional data for push, e.g. {ticketId: ticket.id}
     */
    sendOnePush: function (registrationToken, data, data2) {
        console.log('sendOnePush', registrationToken)
        return new Promise((resolve, reject) => {

            if (registrationToken) {
                const message = {
                    notification: data,
                    data: data2,
                    token: registrationToken,
                    apns: {
                        headers: {
                            'apns-push-type': 'alert',
                        },
                        payload: {
                            aps: {
                                badge: 1,
                                sound: 'default',
                            },
                        },
                    },
                };
                admin.messaging().send(message)
                    .then((response) => {
                        //response projects/keepers-dev-f3ce5/messages/0:1633691770181852%854aab08f9fd7ecd
                        resolve(response);
                    }, err => {
                        //если токен не валидный - удаляем его, в приложении отправится запрос на новый
                        if ((err.errorInfo?.code == 'messaging/invalid-argument'
                            && err.errorInfo?.message == 'The registration token is not a valid FCM registration token')
                            || nullifyToken[err.errorInfo?.code])
                            app.models.user.updateAll({ pushId: registrationToken }, { pushId: null })

                        console.log('sendOnePush err', err)
                        reject(err)
                    });

            } else {
                resolve({ noPushIds: true })
            }
        })
    },
    /**
 * Sends push to user by id
 * @param {string} userId
 * @param {object} data - additional data for push, e.g. {ticketId: ticket.id}
 */
    sendPushToUser: function (userId, data, data2) {
        console.log('sendPushToUser', userId)
        return new Promise((resolve, reject) => {
            if (userId) { //console.log('app.models', await app.models, app.models.user)
                app.models.user.findById(userId, function (err, user) {
                    if (err) throw err;
                    //console.log('user', user, user.pushId)
                    if (user?.pushId) {
                        const message = {
                            notification: data,
                            data: data2,
                            token: user?.pushId,
                            apns: {
                                headers: {
                                    'apns-push-type': 'alert',
                                },
                                payload: {
                                    aps: {
                                        badge: 1,
                                        sound: 'default',
                                    },
                                },
                            },
                        };
                        admin.messaging().send(message)
                            .then((response) => {
                                resolve(response);
                            }, err => {
                                if ((err.errorInfo?.code == 'messaging/invalid-argument'
                                    && err.errorInfo?.message == 'The registration token is not a valid FCM registration token')
                                    || nullifyToken[err.errorInfo?.code])
                                    user.updateAttribute("pushId", null)
                                console.log('sendPushToUser err', err)
                                reject(err)
                            });
                    } else {
                        resolve({ noPushId: true })
                    }
                })
            } else {
                resolve({ noUserId: true })
            }
        })
    },
    
    sendPushToAll: function (data, data2) {
        console.log('sendPushToAll')
        return new Promise((resolve, reject) => {
            app.models.user.find({where: {pushId: {nin: [null, undefined, ""]}}}, function (err, users) {
                if (err) throw err;
                let pushIds = users?.map(user => user.pushId) || []
                resolve(module.exports.sendPush(pushIds, data, data2))
            })
        })
    }
}