'use strict';
const path = require('path');
require('dotenv').config({path: path.resolve(__dirname, '../.env')})
const APP_ID = process.env.agoraAppId;
const APP_CERTIFICATE  = process.env.agoraCertificate;
const { RtcTokenBuilder, RtcRole } = require('agora-access-token');

module.exports = {
    nocache: (req, resp, next) => {
        resp.header('Cache-Control', 'private, no-cache, no-store, must-revalidate');
        resp.header('Expires', '-1');
        resp.set('Pragma', 'no-cache');
        return
    },
    appId: APP_ID,
    //1.5hours
    generateAccessToken: function (channelName, uid, roleString, expireTime = 2*24*60*60/*req, resp*/) /*=/*& gt;*/ {

        if (!channelName) {
            //return resp.status(500).json({ 'error': 'channel is required' });
            throw Error("channel is required")
        }

        //let uid = req.accessToken.userId;//req.query.uid;
        // if (!uid || uid == '') {//wildcard - only TEST
        //     uid = 0;
        // }
        // get role
        let role = RtcRole.SUBSCRIBER;
        if (roleString == 'publisher') {
            role = RtcRole.PUBLISHER;
        }
        // get the expire time
        // let expireTime = expireTime;
        // if (!expireTime || expireTime == '') {
        //     expireTime = 3600;//1 hour for
        // } else {
        //     expireTime = parseInt(expireTime, 10);
        // }
        // calculate privilege expire time
        const currentTime = Math.floor(Date.now() / 1000);
        const privilegeExpireTime = currentTime + expireTime;
        const token = RtcTokenBuilder.buildTokenWithUid(APP_ID, APP_CERTIFICATE, channelName, uid, role, privilegeExpireTime);

        return token///resp.json({ 'token': token });
    },
}