'use strict';
const path = require('path');
require('dotenv').config({ path: path.resolve(__dirname, '../.env') })

let moment = require('moment');
let smsc_login = process.env.smsc_login;
let smsc_pass = process.env.smsc_pass;
let istest = process.env.test;
const app = require('../server/server.js');


module.exports = {
    /**79991058175
     * Sends sms to users
     */
    sendSMS: function (phone, text) {console.log('sendSMS', phone, text)
    console.log('istest', istest, !!istest, typeof istest)
        return new Promise((resolve, reject) => {
            if (smsc_login && smsc_pass && istest != "true") {
				//sms send here
				const https = require('https');

				const options = {
					hostname: 'smsc.ru',
					port: 443,
					path: `/sys/send.php?login=${smsc_login}&psw=${smsc_pass}&phones=${phone}&mes=${encodeURI(text)}`,//&cost=1
					method: 'POST',
					headers: {
						'Content-Type': 'application/json'
					},
				}

				const httpRequest = https.request(options, (res) => {
					res.on('data', (d) => {console.log('sendSMS2) d', d)
						try {
							const answ = d.toString('utf8')
							console.log('answ', answ)
							if (res.statusCode == 200)
								resolve()
							else {
								const err = new Error('sms_error')
								err.statusCode = res.statusCode;
								reject(err)
							}
						} catch (e) {
							throw e
						}
					})
				})

				httpRequest.on('error', (err) => {
					console.error(err);
					reject(err)
				})

				httpRequest.end();
			} else if (istest == "true") {
                resolve()
            } else {
				const err = new Error('sms_error')
				err.statusCode = 500;
				reject(err)
			}
        })
    },

    //to check
    /*sendEmailToUser: function (userIds, data) {
        console.log('sendPushToUser', userIds)
        return new Promise((resolve, reject) => {
            if (userIds?.length > 0) { //console.log('app.models', await app.models, app.models.user)
                app.models.user.find({ where: { id: { inq: userIds }, email: { nin: [undefined, null, ''] } } }, function (err, users) {
                    if (err) throw err;
                    //console.log('user', user, user.pushId)
                    const emails = users?.map(user => user.email) || []
                    if (emails.length > 0) {
                        resolve(sendEmail(emails, data, null))
                    } else {
                        resolve({ noemails: true })
                    }
                })
            } else {
                resolve({ noUserId: true })
            }
        })
    }*/
}