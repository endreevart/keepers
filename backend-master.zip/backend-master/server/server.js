'use strict';

var loopback     = require('loopback');
var boot         = require('loopback-boot');
//var bunyanMongoDbLogger = require('bunyan-mongodb-logger');
//var log = bunyanMongoDbLogger({
//  name: 'AYA',
//  streams: ['mongodb'],
//  url: 'mongodb://localhost:27017/logs',
//});
//require('loopback-audit-logger')(log);

var app = module.exports = loopback();
var multer = require('multer');
app.use(multer().any());

// configure view handler
app.set('view engine', 'ejs');
var path = require('path');
app.set('views', path.join(__dirname, 'views'));
app.set('rootStatic', path.join(__dirname, '../static'));
app.set('rootfolder', path.join(__dirname, '../'));

// configure body parser
//var bodyParser = require('body-parser');
//app.use(bodyParser.urlencoded({extended: true}));

app.start = function() {
  // start the web server
  var server = app.listen(function() {
    app.emit('started', server);
    var baseUrl = app.get('url').replace(/\/$/, '');
    console.log('Web server listening at: %s', baseUrl);
    if (app.get('loopback-component-explorer')) {
      var explorerPath = app.get('loopback-component-explorer').mountPath;
      console.log('Browse your REST API at %s%s', baseUrl, explorerPath);
    }
  });
  return server;
};

// Bootstrap the application, configure models, datasources and middleware.
// Sub-apps like REST API are mounted via boot scripts.
boot(app, __dirname, function(err) {
  if (err) throw err;

  // start the server if `$ node server.js`
  if (require.main === module)
    app.start();
});

app.use(loopback.token());
//refresh token
app.use(function(req, res, next) {
  var token = req.accessToken;
  if (!token) {
      return next();
  }
  var now = new Date();
  if ( now.getTime() - token.created.getTime() < 1000 ) {
      return next();
  } else if (now.getTime() - token.created.getTime() > 60 * 60 * 1000) {//больше часа с последнего обновления токена
    req.accessToken.created = now;
    app.models.AccessToken.upsertWithWhere({id: req.accessToken.id}, {created: now})
  }
  //req.accessToken.created = now;
  //req.accessToken.ttl     = 1209600; //2 week
  //req.accessToken.save(next);
  next()
});