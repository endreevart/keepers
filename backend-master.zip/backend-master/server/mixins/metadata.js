'use strict';

module.exports = function (Model, options) {

  Model.defineProperty('created', {
    type: Date,
    defaultFn: "now",
    required: false
  })

  Model.defineProperty('createdBy', {
    type: String,
    default: false
  })

  Model.observe('before save', function createMetadata(ctx, next) {
    if (ctx.isNewInstance) {
      ctx.instance.createdBy = ctx.options?.accessToken?.userId;
    } //else {
    //   ctx.data.updated = new Date();
    // }
    next();
  });

}