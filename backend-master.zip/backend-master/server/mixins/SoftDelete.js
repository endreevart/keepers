'use strict';

module.exports = function (Model, options) {

  Model.defineProperty('deletedAt', {
    type: Date,
    required: false
  })

  Model.defineProperty('isDeleted', {
    type: Boolean,
    default: false
  })

  let app;
  Model.once('attached', (a) => {
    app = a;
    const deleteById = Model.deleteById;
    Model.deleteById = (id, options, cb) => {
      Model.updateAll({ id: id }, {
        deletedAt: new Date(),
        isDeleted: true,
      });
      cb(null, 'deleted')
    };
  });

}