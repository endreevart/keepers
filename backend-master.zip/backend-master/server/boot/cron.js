'use strict';
const { CronJob } = require('cron');
var moment = require('moment');
const pushNotification = require('../../helpers/pushNotification');

module.exports = function (app) {

  const AT_5 = '0 0 5 * * *';//в 5 часов ночи каждый день
  const EVERY_10 = '*/10 * * * * *';//каждые 10 сек
  const EVERY_MIN = '0 * * * * *';//каждую минуту
  const EVERY_halfMIN = '*/30 * * * * *';//каждую 30c
  const EVERY_15 = '*/15 * * * * *';//каждую 15c
  const EVERY_10_MIN = '*/10 * * * *';//каждые 10 минут
  const EVERY_5MIN = '0 */5 * * * *';//каждые 5 мин

  // var job = new CronJob(EVERY_10, function() {
  //   console.log('You will see this message every second');
  // }, null, true);
  // job.start();

  //скрижаль дня
  var job = new CronJob(EVERY_MIN, async function () {


    let n = 2//1
    //db.getCollection('tablet').find({date: {$gt: ISODate("2021-08-18T00:09:02.959Z"), $lt: ISODate("2021-08-19T00:09:02.959Z")}})
    const now = new moment(/*[2021, 7, 19, 11, 42, 30]*/).startOf('minute')
    const end = new moment("2020-01-01T" + now.format("HH:mm:ss"))
    const start = end.clone().subtract(1, 'minute')
    const startDate = start.toDate(); //console.log('startDate', startDate)
    const endDate = end.toDate(); //console.log('endDate', endDate)

    const start2 = now.clone().subtract(1, 'days').toDate()
    const end2 = now.toDate()

    app.models.tablet.createTotalTablet(startDate, endDate, start2, end2, undefined)
    tabletNotifications(now, end, start, end2, start2)
    eventNotifications(now)
    taskNotifications(now)
    changeEventStatus(now)
    checkUserTaskStatus(now)

  }, null, true);
  job.start();


  /**
   * 
   * @param {moment} now 
   * @param {moment} endMinute 
   * @param {moment} startMinute 
   * @param {date} endDay 
   * @param {date} startDay 
   */
  //отправка уведомления о создании скрижалей
  async function tabletNotifications(now, endMinute, startMinute, endDay, startDay) {
    // console.log('endMinute', startMinute, endMinute)
    // console.log('startDay', startDay, endDay)
    /*
    вывод уведомлений, если не записана скрижаль
    let mongoConnector = app.dataSources.mongodb.connector;
    let tabletNotifications = await mongoConnector.collection("TabletNotification").aggregate([
      { $match: { date: { $gte: startMinute.toDate(), $lt: endMinute.toDate() }, notificate: true } },
      {
        $lookup:
        {
          from: "tablet",
          let: { userId: "$userId", tabletTypeId: "$tabletTypeId" },
          pipeline: [
            { $match: { "$expr": { $and: [{ "$gte": ["$date", startDay] }, { "$lt": ["$date", endDay] }, { "$eq": ["$userId", "$$userId"] }, { "$eq": ["$tabletTypeId", "$$tabletTypeId"] }] } } },
            {
              $limit: 1
            },
            { $project: { _id: 1} }
          ],
          as: "tablet"
        }
      },
      { $unwind: { path: "$tablet", preserveNullAndEmptyArrays: true } },
      {
        $lookup:
        {
          from: "user",
          let: { userId: "$userId" },
          pipeline: [
            { $match: { "$expr": { "$eq": ["$_id", "$$userId"] } } },
            {
              $limit: 1
            },
            { $project: { _id: 1, pushId: 1 } }
          ],
          as: "user"
        }
      },
      { $unwind: { path: "$user", preserveNullAndEmptyArrays: true } },
      // { $project: { _id: 1,notificate: 1,
      //   tabletTypeId: 1, user: "$user", tablet: "$tablet" } },
      //  { $addFields: { "user": "$user" } },
    ]).toArray()
    console.log('tabletNotifications', tabletNotifications)
    const pushIds = {};
    for (let notif of tabletNotifications) {console.log('notif', notif)
      if (!notif.tablet && notif.user?.pushId) {
        if (pushIds[notif.tabletTypeId])
          pushIds[notif.tabletTypeId].push(notif.user?.pushId)
        else
          pushIds[notif.tabletTypeId] = [notif.user?.pushId]
      }
    }
    for (let pushIdArray in pushIds)
      pushNotification.sendPush(pushIds[pushIdArray], {'title': 'remember'})
      */
    let tabletNotifications = await app.models.TabletNotification.find({
      where: { date: { between: [startMinute.add(1, 'ms'), endMinute] }, notificate: true },
      include: { relation: 'user', scope: { fields: ['id', 'pushId'] } }
    })
    tabletNotifications = JSON.parse(JSON.stringify(tabletNotifications))
    //console.log('tabletNotifications', tabletNotifications)
    const pushIds = {}
    //уведомления по категориям для разных текстов
    for (let notif of tabletNotifications) {
      if (notif.user?.pushId) {
        if (pushIds[notif.tabletTypeId])
          pushIds[notif.tabletTypeId].push(notif.user?.pushId)
        else
          pushIds[notif.tabletTypeId] = [notif.user?.pushId]
      }
    }

    try {
      for (let pushIdArray in pushIds) {
        if (pushIds[pushIdArray].length > 0)
        pushNotification.sendPush(
          pushIds[pushIdArray], 
          { 'title': 'Напоминание', 'body':'Предлагаем добавить скрижаль' },
          { "type": "tablet", "action": "notify"/*, "itemId": null*/ }
          )
      }
    } catch (e) {
      
    }
  }
  
  /**
   * отправка уведомлений по событиям
   */
  function eventNotifications(now){
    app.models.Event.find({where: {pushDate: {lte: now.toDate()}}, 
    include: [{relation: 'userTask', scope:{include: {relation: 'user', scope: {fields: 'pushId'}}, fields: ['id', 'userId']}}, 
    {relation: 'userConsultation', scope:{include: 'user', fields: ['id', 'userId']}}, ]}, function(err, eventInstances) {
      if (err) throw err;
      const events = JSON.parse(JSON.stringify(eventInstances))
      let pushConsultationIds = []
      let pushTaskIds = []

      events.forEach((event, i) => {
        switch(event.eventTypeId) {
          case 'consultation': {
            if (event.userConsultation?.user?.pushId)
              pushConsultationIds.push(event.userConsultation?.user?.pushId)
            break;
          }
          case 'task': {
            if (event.userConsultation?.user?.pushId)
              pushTaskIds.push(event.userConsultation?.user?.pushId)
            break;
          }
        }
        eventInstances[i].updateAttribute("pushDate", null)
      })

      // pushNotification.sendPush(pushTaskIds, { 'title': 'Срок сдачи задания подходит к концу' })
      // pushNotification.sendPush(pushConsultationIds, { 'title': 'Через пять минут начнется консультация' })
    })
  }
  /**
   * смена статусов событий
   */
  function changeEventStatus(now){
    app.models.Event.updateAll({//eventupdate
      dateCompleted: {lte: now.toDate()},
      status: 'created'
    }, {
      status: 'complete'
    }, function(err, events) {
      if (err) throw err
    })
  }

  //отправка уведомлений по заданиям
  //за 3ч до окончания
  function taskNotifications(now){
    const start = now.add(3, 'hours')
    const end = now.clone().add(1, "minutes").subtract(1, "ms").toDate()
    app.models.UserTask.find({where: {endDate: {between: [start.toDate(), end]}},
    include: {relation: 'user', scope: {fields: 'pushId'}}, fields: ['id', 'userId']}, 
      function(err, tasks) {
        if (err) throw err
        tasks = JSON.parse(JSON.stringify(tasks))
        //const pushIds = []
        tasks.forEach(task => {
          if (task.user?.pushId) //pushIds.push(task.user?.pushId)
            pushNotification.sendOnePush(task.user?.pushId, 
              { 'title': 'Завершение задания', 'body':'Срок сдачи задания заканчивается, осталось 3 часа'  },
              { "type": "userTask", "action": "notify", "itemId": task.id }
              )
        })
        //pushNotification.sendPush(pushIds, { 'title': 'Завершение задания', 'body':'Срок сдачи задания заканчивается, осталось 3 часа'  })
    })
  }
  /**
   * Если время endDate <= now - изменять статус на overdue (просрочено)
   * @param {moment} now 
   */
  function checkUserTaskStatus(now){
    app.models.UserTask.updateAll({endDate: {lt: now}, status: {nin: ['completed', 'overdue', 'await', 'cancelled', 'declined']}}, {status: 'overdue'},
      function(err, tasks) {
        if (err) throw err
    })
  }


  var everyDay = new CronJob(EVERY_MIN, async function () {
    const now = new moment(/*[2021, 7, 19, 11, 42, 30]*/).startOf('minute')
    deleteOldWorkSlots(now)
  })

  function deleteOldWorkSlots(now) {
    // app.models.WorkSlot.deleteAll({endDate: {lt: now}},
    //   function(err, slots) {
    //     if (err) throw err
    // })
    app.models.WorkSlot.find({ where: { endDate: { lt: now.toDate() } } },//workslotfind
      function (err, slots) {
        if (err) throw err
        let promises = slots.map(slot => {
          if (slot.userConsultationId) {
            return app.models.WorkSlot.find({ where: { userConsultationId: slot.userConsultationId, endDate: { gt: now.toDate() } }, limit: 1 }).then((workSlots) => {//workslotfind
              //консультация не закончилась
              if (workSlots.length > 0) {
                return slot.delete().then(() => { })//workslotdelete
              } else {
                //закончилась
                return app.models.UserConsultation.upsertWithWhere({ id: slot.userConsultationId }, { "status": "completed" }).then(us => {//workslotupdate
                  return slot.delete().then(() => { })
                }, err => { throw err })
              }
            }, err => { throw err })
          }
          else {
            return slot.delete()//workslotdelete
          }
        })
        Promise.all(promises).then(() => {
        })
      })
  }

  /**
   * проверка дел
   * @param {moment} now 
   */
  function checkCases(now) {
    const yesterday = now.clone().subtract(1, 'days');
    app.models.Case.find({where: {gameDayDate: {lt: yesterday}, caseStatusId: {nin: ["cancelled", "completed"]}}}, function(err, cases){
      let promises = cases.map(caseItem => caseItem.updateAttributes({
        "postponed": true, "gameDayDate": moment(caseItem.gameDayDate).add(1, "day")
      })) || []
      Promise.all(promises).then((res) => {}, err => {console.log('checkCases err', err)})
    })
  }

  //проверка времени на отправку кода
  var checkActivationTime = new CronJob(EVERY_5MIN, async function () {
    //удаление всех пользователей без активации
    app.models.user.deleteAll({activation_phone: false, activation_time: {lt: new Date()}}, function(err, res) {
      if (err) throw err
    })
    //очистка кодов для восстановления пароля
    app.models.user.updateAll(
      {activation_phone: true, activation_time: {lt: new Date()}, activation_code: {nin: [undefined, null, ""]}}, 
      {activation_code: null, activation_time: null}, function(err, res) {
      if (err) throw err
    })
  }, null, true);
  checkActivationTime.start();

  //каждые 10 мин
  var every10min = new CronJob(EVERY_10_MIN, async function () {

    const now = new moment().startOf('minute')

    checkCases(now)

  }, null, true);

  every10min.start();
  everyDay.start();
};

