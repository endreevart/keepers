'use strict';
var admin = require("firebase-admin");
var serviceAccount = require("../../config/serviceAccountKey.json");

module.exports = function (app) {
    //инициализация firebase messaging
    admin.initializeApp({
        credential: admin.credential.cert(serviceAccount)
    });
}