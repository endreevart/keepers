'use strict';

module.exports = function(server) {
  // Install a `/` route that returns server status
  var router = server.loopback.Router();
  
  router.use('/api/info', server.loopback.status());
  //router.get('/', server.loopback.status());

  //verified
  router.use('/api/verified', function(req, res) {
    console.log('verified')
    res.render('verified');
  });

  server.use(router);
};
