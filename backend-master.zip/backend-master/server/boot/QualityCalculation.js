'use strict';

module.exports = function (app, cb) {//без контракта, но со статусом "Отложено"
  /*
   * The `app` object provides access to a variety of LoopBack resources such as
   * models (e.g. `app.models.YourModelName`) or data sources (e.g.
   * `app.datasources.YourDataSource`). See
   * https://loopback.io/doc/en/lb3/Working-with-LoopBack-objects.html
   * for more info.
   */
  // app.models.user.find({},function(err, users){
  //   users.forEach(user => {
  //     user.blockList.create({})
  //   });
  // })

  var timerId = setInterval(function () {
    /*app.models.Settings.findOne({
      where: {
        name: 'statusesWithStoppedTimer'
      }
    }, function (err, settings) {
      app.models.ticket.find({ where: { ticketStatusId: { nin: settings.data.statuses } } }, function (err, tickets) {//выбираем обращения, с идущим временем
        if (err) {
          console.log(err);
        }
        tickets.forEach();
      });

      

    });*/
    console.log('next second');
    //next();
  }, 20000);//60000

  process.nextTick(cb); // Remove if you pass `cb` to an async function yourself

};
