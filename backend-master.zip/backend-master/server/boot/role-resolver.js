/* eslint comma-dangle: ["error", "never"] */
'use strict';

module.exports = function(app) {
  var Role = app.models.Role;

  Role.registerResolver('customer', function(role, context, cb) {console.log('1');
    function reject() {console.log('2');
      process.nextTick(function() {console.log('3');
        cb(null, false);
      });
    }

    // do not allow anonymous users
    var userId = context.accessToken.userId;
    if (!userId){console.log('4');
      return reject();}
      console.log('5');
    // ...
    switch (context.modelName) {
      case 'company':{console.log('6');
        app.models.user.count({
          id: userId,
          companyId: context.modelId
        }, function(err, count) {console.log('7',count);
          if (err) return cb(err);
          return cb(null, count > 0);
        });
        break;}
      default:{console.log('8');
        return reject();}
    }
  });
};
